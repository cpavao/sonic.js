# -*- coding: utf-8 -*-
"""Demonstrate high quality docstrings."""
import os
import sys
import xbmcaddon

__addon__ = xbmcaddon.Addon()
__addonpath__ = __addon__.getAddonInfo('path').decode('utf-8')

if os.path.exists('/usr/local/bin/qbus'):
    sys.path.insert(0, u'{}/lib'.format(__addonpath__))

from lib import g
from lib.utils.player import HDPlayer
from lib.core.handler.main import mainHandler

def main():
    u"""Main function."""
    g().init()
    g().set('player', HDPlayer())

    w = mainHandler('win_main.xml', __addonpath__, "Default")
    w.doModal()
    del w

    return True

if __name__ == '__main__':
    main()
