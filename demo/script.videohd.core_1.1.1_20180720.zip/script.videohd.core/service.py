# -*- coding: utf-8 -*-
"""Demonstrate high quality docstrings."""
import os
import sys

import xbmc
import xbmcaddon

__addon__ = xbmcaddon.Addon()
__addonpath__ = __addon__.getAddonInfo('path').decode('utf-8')

from lib.core.handler.main import mainHandler

def main():
    u"""Main function."""
    w = mainHandler('win_main.xml', __addonpath__, "Default")
    w.doModal()
    del w

if __name__ == '__main__':
    main()
