# -*- coding: utf-8 -*-
import threading

class Repeater:
    def __init__(self, interval, action, arguments = []):
        self.interval = interval
        self.action = action
        self.arguments = arguments
        self.event = None

    def start(self):
        if self.event:
            return

        self.event = threading.Event()
        self.thread = threading.Thread(
            target=Repeater.repeat if self.interval is not None else Repeater.repeatOnce,
            args=(self.event, self.interval, self.action, self.arguments)
        )
        self.thread.start()

    def stop(self):
        if not self.event:
            return
        self.event.set()
        self.thread.join()
        self.event = None

    @classmethod
    def repeat(cls, event, interval, action, arguments=[]):
        while True:
            event.wait(interval)
            if event.isSet():
                break
            action(*arguments)

    @classmethod
    def repeatOnce(cls, event, interval, action, arguments=[]):
        if event.isSet():
            return

        action(*arguments)
