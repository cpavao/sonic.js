# -*- coding: utf-8 -*-
from threading import Thread
import random

import xbmc
import xbmcgui
import xbmcaddon

from lib import g
from lib.static import *

from lib.api.background import BackgroundHandler
from lib.api.videostation import VideoStationAPI
api = VideoStationAPI()

__addon__ = xbmcaddon.Addon()
__addonpath__ = __addon__.getAddonInfo('path').decode('utf-8')
__language__ = __addon__.getLocalizedString


class HDPlayList(xbmc.PlayList):
    _instance = None

    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            cls._instance = super(HDPlayList, cls).__new__(cls, *args, **kwargs)

        return cls._instance


class HDPlayer(xbmc.Player):

    VIDEO_SUPPORT = xbmc.getSupportedMedia('video').split('|')
    MUSIC_SUPPORT = xbmc.getSupportedMedia('music').split('|')

    _instance = None

    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            cls._instance = super(HDPlayer, cls).__new__(cls, *args, **kwargs)
            cls._instance.state = 'stop'
            cls._instance.listitems = None
            cls._instance.playlist = HDPlayList(xbmc.PLAYLIST_VIDEO)

            cls._instance.tvshowTitle = None

        return cls._instance

    def __init__(self):
        xbmc.Player.__init__(self)

        # Init volume configuration.

        self._getCurrentVolume()

        g.saveThread(Thread(target=self._remainingTimer))

    def init(self):
        return 'init'

    # def _genPlayList(self, listitems, item=None):

    def _genPlayList(self, listitems):
        # self.listitems = listitems
        self.playlist.clear()

        if type(listitems) in (list, ):
            g().set('current.playlist', listitems)
            for listitem in listitems:
                filepath = g.fullPath(listitem)
                self.playlist.add(filepath, listitem)
        else:
            g().set('current.playlist', [listitems])
            # filePath = '{0}/{1}'.format(listitems.getProperty('prefix'), listitems.getProperty('filename'))
            self.playlist.add(g.fullPath(listitems), listitems)

    def _callPlayer(self, select=None):
        from lib.core.dialog.playercontrol import PlayerControlDialog

        w = PlayerControlDialog('dlg_playercontrol.xml', __addonpath__, "Default", select=select)
        w.doModal()
        del w

    def _updateCurrentPlayProgress(self, item, onlySubtitle=False):
        resp = api.getPlayProgress(item.getProperty('id'))
        if not resp:
            return

        if not onlySubtitle:
            if resp.get('offset'):
                offset_pure = g.ensureUTF8(resp.get('offset'))
                s_time = g.showTime(g.timeTransfer(resp.get('offset')))
            else:
                s_time = g.showTime(g.timeTransfer())
                offset_pure = '0'

            item.setProperty('offset', s_time)
            item.setProperty('offset_pure', offset_pure)

        g.setHomeProperty('Player.Subtitle', resp.get('subtitle'))

        g().get('bgTask').clear_task_result('player.subtitle')
        g().get('bgTask').add_task('player.subtitle', BackgroundHandler().subtitleBackgroundData, item.getProperty('id'))

    def _remainingTimer(self):
        """check playback remain time."""
        randomHit = random.randint(GLOBAL_RAND_MIN_SEC, GLOBAL_RAND_MAX_SEC)
        randomCount = 0

        while (not xbmc.abortRequested):
            if g().get('BreakThread'):
                break

            try:
                g.log_debug(msg='===== _remainingTimer INFO =====')
                g.log_debug(msg='current state: {}'.format(self.getState()))
                if self.getState() in ('playing', ):
                    remainTime = int(self.getTotalTime() - self.getTime())
                    g.log_debug(msg='remainTime: {}'.format(remainTime))
                    if remainTime <= REMAIN_TIME_COUNT:
                        if len(g().get('current.playlist')) in (1, ) or not self.getNextPlayItem():
                            g.clearHomeProperty('Player.NextNotify')
                        else:
                            if not g.getHomeProperty('Player.NextNotify'):
                                g.setHomeProperty('Player.NextNotify', 'show')

                            g.setHomeProperty('Player.RemainTime', str(remainTime))
                    else:
                        g.clearHomeProperty('Player.NextNotify')
                        g.clearHomeProperty('Player.RemainTime')
            except Exception, err:
                g.log_debug(msg='Exception: {}'.format(err))

            g.log_debug(msg='===== _remainingTimer INFO End =====')
            xbmc.sleep(1000)

    def _checkSubtitle(self):
        if g.getHomeProperty('Player.Subtitle'):
            g.setDownloadSubtitleFile(g.getHomeProperty('Player.Subtitle'))

    def play(self, listitem=None, startpos=0):
        item = listitem[startpos]

        self._updateCurrentPlayProgress(item)
        if item.getProperty('offset_pure') in ('0', ) or item.getProperty('offset_pure') in (item.getProperty('duration'), ):
            g.clearHomeProperty('Player.ResumeCheck')
        else:
            g.setHomeProperty('Player.ResumeCheck', item.getProperty('offset'))

        self.state = 'playing'
        self._genPlayList(listitem)

        # Init NextNotify before play.
        g.setHomeProperty('Player.NextNotify', 'hide')

        g.saveThread(Thread(target=self._callPlayer, args=(item, )))
        super(HDPlayer, self).play(item=self.playlist, windowed=False, startpos=startpos)

        self._checkSubtitle()

    def pause(self):
        self.state = 'playing' if self.state in ('pause', ) else 'pause'
        super(HDPlayer, self).pause()

    def stop(self):
        if self.state in ('stop', ):
            return

        self.state = 'stop'
        mediaId = self.getCurrentPlayItem().getProperty('id')

        try:
            offset = int(self.getTime())

            g.log_debug(msg=offset)
            g.log_debug(msg=mediaId)

            if mediaId and not g.getHomeProperty('Player.ResumeCheck'):
                duration = float(self.getCurrentPlayItem().getProperty('duration'))
                watched = int(round(offset / duration * 100))

                '''97% and 3%'''
                if watched >= 97:
                    updateOffset = eval(self.getCurrentPlayItem().getProperty('duration'))
                    s_time = g.showTime(g.timeTransfer(updateOffset))
                    lengthOffset = __language__(60021)
                elif watched <= 3:
                    updateOffset = 0
                    s_time = g.showTime(g.timeTransfer())
                    lengthOffset = g.showTime(g.timeTransfer())
                else:
                    updateOffset = offset
                    s_time = g.showTime(g.timeTransfer(updateOffset))
                    lengthOffset = '{0} / {1}'.format(s_time, self.getCurrentPlayItem().getProperty('length'))

                api.setPlayProgress(mediaId, updateOffset)

                self.getCurrentPlayItem().setProperty('offset_pure', g.ensureUTF8(updateOffset))
                self.getCurrentPlayItem().setProperty('offset', s_time)
                self.getCurrentPlayItem().setProperty('length.display', lengthOffset)
        except:
            pass

        g.clearHomeProperty('Player.NextNotify')

        super(HDPlayer, self).stop()

    def _getCurrentVolume(self):
        currentVolume = int(float(xbmc.getInfoLabel('Player.Volume').split(' ')[0]) / 60.0 * 100) + 100

        if xbmc.getCondVisibility('Window.IsVisible(Mutebug)'):
            g.setHomeProperty('Global.Volume.State', 'Mute')
        else:
            if currentVolume > 66:
                g.setHomeProperty('Global.Volume.State', 'Large')
            elif currentVolume < 33:
                g.setHomeProperty('Global.Volume.State', 'Small')
            else:
                g.setHomeProperty('Global.Volume.State', 'Medium')

        return currentVolume

    def _playerEventPlay(self, item):
        if item:
            '''
            name, ext = os.path.splitext(item)
            if ext.lower() not in self.support():
                return

            if ext.lower() in ('.rm', ):
                new_item = '{0}/{1}.rmvb'.format(__tmp__, uuid.uuid4().hex)
                os.symlink(item, new_item)
                item = new_item
            '''
            listitem = xbmcgui.ListItem()
            listitem.setProperty('filename', '/{}'.format(item.split('/')[-1]))
            p = item.split('/')[:-1]
            p.remove('share')
            p.remove('')
            prefix = '/'.join(p)
            listitem.setProperty('prefix', prefix)

            self.stop()
            xbmc.sleep(1000)
            # xbmc.Player().play(item, listitem, False)
            self.play(listitem, False)
            # self.play(item, listitem, False)
        else:
            self.pause()

    def _playerEventPause(self):
        self.pause()

    def _playerEventStop(self):
        self.stop()

    def _playerEventSearch(self, offset):
        if offset:
            self.seekTime(offset)

    def _playEventSelected(self, position):
        self.playselected(position)

        g.clearHomeProperty('Player.NextNotify')

    def _playerEventVolume(self, percentage):
        if percentage:
            xbmc.executebuiltin('xbmc.SetVolume({0})'.format(percentage))

    def _playerEventMute(self):
        xbmc.executebuiltin('XBMC.Mute()')

    def playerEvent(self, message, *args):
        self.data = message.get('data')
        g.log_debug(msg='Receive player event :')
        g.log_debug(msg=self.data)

        if self.data.get('action') in ('play', ):
            self._playerEventPlay(self.data.get('item'))
        elif self.data.get('action') in ('pause', ):
            self._playerEventPause()
        elif self.data.get('action') in ('stop', ):
            self._playerEventStop()
        elif self.data.get('action') in ('search', ):
            self._playerEventSearch(self.data.get('offset'))
        elif self.data.get('action') in ('volume', ):
            self._playerEventVolume(self.data.get('percentage'))
        elif self.data.get('action') in ('mute', ):
            self._playerEventMute()

    @classmethod
    def getPlayList(cls):
        return cls._instance.listitems

    @classmethod
    def setTvshowTitle(cls, tvshowTitle):
        cls._instance.tvshowTitle = tvshowTitle

    @classmethod
    def getTvshowTitle(cls):
        return g.ensureUnicode(cls._instance.tvshowTitle)

    @classmethod
    def getCurrentPlayItem(cls):
        posIdx = cls._instance.playlist.getposition()
        return cls._instance.playlist[posIdx]

    @classmethod
    def getCurrentPlayItemPosition(cls):
        return cls._instance.playlist.getposition()

    @classmethod
    def getNextPlayItem(cls):
        posIdx = cls._instance.playlist.getposition()

        if (posIdx + 1) < cls._instance.playlist.size():
            return cls._instance.playlist[posIdx + 1]

        return None

    @classmethod
    def setState(cls, state):
        cls._instance.state = state

    @classmethod
    def getState(cls):
        return cls._instance.state

    @classmethod
    def isPlayListEnded(cls):
        if cls._instance.playlist.size() == 1:
            return True

        if cls._instance.playlist.getposition() < 0:
            return True

        if cls._instance.playlist.size() - 1 == cls._instance.playlist.getposition():
            return True

        return False

    def onPlayBackStarted(self):
        xbmc.log("##### onPlayBackStarted")
        self.state = 'playing'

        self._updateCurrentPlayProgress(self.getCurrentPlayItem(), True)
        self._checkSubtitle()

        g().set('UpdatePlayercontrolExitLabel', True)
        # g().set('UpdatePauseFocusPosition', True)

        if g.getHomeProperty('Player.ResumeCheck'):
            self.pause()

    def onPlayBackEnded(self):
        xbmc.log("##### onPlayBackEnded")
        if self.isPlayListEnded():
            self.onPlayBackStopped()

            mediaId = self.getCurrentPlayItem().getProperty('id')
            theEndOffset = eval(self.getCurrentPlayItem().getProperty('duration'))
            t_transfer = g.timeTransfer(theEndOffset)
            s_time = g.showTime(t_transfer)
            lengthOffset = __language__(60021)
            api.setPlayProgress(mediaId, theEndOffset)
            self.getCurrentPlayItem().setProperty('offset_pure', g.ensureUTF8(theEndOffset))
            self.getCurrentPlayItem().setProperty('offset', s_time)
            self.getCurrentPlayItem().setProperty('length.display', lengthOffset)

        g.clearHomeProperty('Player.NextNotify')

    def onPlayBackStopped(self):
        xbmc.log("##### onPlayBackStopped")
        g.setHomeProperty('Playercontrol.Closed', 'close')
        self.state = 'stop'

    def onPlayBackPaused(self):
        xbmc.log("##### onPlayBackPaused")
        self.state = 'pause'

        g().set('reloadPlaylist', True)

        if xbmc.getCondVisibility('Window.IsVisible(screencalibration)'):
            while (not xbmc.abortRequested):
                if g().get('BreakThread'):
                    break

                if not xbmc.getCondVisibility('Window.IsVisible(screencalibration)'):
                    '''Thread(target=self._callPlayer).start()'''
                    g.saveThread(Thread(target=self._callPlayer))
                    self.pause()
                    break
                xbmc.sleep(100)

    def onPlayBackResumed(self):
        xbmc.log("##### onPlayBackResumed")
        self.state = 'playing'

    def onPlayBackSpeedChanged(self, speed):
        xbmc.log("##### onPlayBackSpeedChanged")

    def onPlayBackSeek(self, time, seekOffset):
        xbmc.log("##### onPlayBackSeek")

    def onVolumeChanged(self):
        xbmc.log("##### onVolumeChanged")
        self._getCurrentVolume()
                                                                      
     
                                                   
     
     
     
 
