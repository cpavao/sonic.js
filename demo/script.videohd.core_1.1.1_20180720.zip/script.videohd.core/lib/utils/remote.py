# -*- coding: utf-8 -*-
import xbmcaddon

from lib import g

__addon__ = xbmcaddon.Addon()
__language__ = __addon__.getLocalizedString


class remote(object):
    buttonMapping = {
        'KEY_POWER': 323731,
        'KEY_HOME': 251,
    }

    @classmethod
    def key(cls, targetId):
        for key, value in cls.keymapping.items():
            if targetId in (value, ):
                return key

    @classmethod
    def val(cls, text):
        if text in cls.buttonMapping:
            return cls.buttonMapping[text]
        else:
            return None

    @classmethod
    def execute(cls, action):
        '''
            How to get button code?
                - action.getButtonCode() in onAction(self, action)
        '''
        buttonCode = action.getButtonCode()

        if buttonCode in (cls.val('KEY_POWER'), ):
            g.setWaitingMask(state='on', msg=__language__(63003))
            g.stopVideoHD()
