# -*- coding: utf-8 -*-
import json
import requests
import traceback

import xbmcaddon

from lib import g

__addon__ = xbmcaddon.Addon()
__addonpath__ = __addon__.getAddonInfo('path').decode('utf-8')


class HTTPRequest(object):
    _execute = {
        'GET': requests.get,
        'POST': requests.post,
        'PUT': requests.put,
        'DELETE': requests.delete
    }

    def request(self, method, url, data=None, params=None, action='noAction'):

        if 'https' in url:
            verify = False
        else:
            verify = True

        if action in ('sslCheck', ):
            verify = True

        try:
            if method in ('POST', ):
                data['sid'] = g().get('sid')
                data['json'] = 1
            else:
                if action not in ('loginCheck', ):
                    params['sid'] = g().get('sid')
                else:
                    params['sid'] = None

                params['json'] = 1

            r = self._execute[method](url, data=data, params=params, verify=verify)
        except requests.ConnectionError:
            g.refresh()
            return self._execute[method](url, data=data, params=params)
        except Exception:
            g.log_error(traceback.format_exc())
            if action in ('sslCheck', ):
                raise

            return None

        g.log_debug(msg=r.url)

        if method in ('GET', ):
            g.log_debug(msg=params)
        elif method in ('POST', ):
            g.log_debug(msg=data)

        if r.ok:
            if action in ('pure_content', ):
                return r.content
            resp = r.json()

            try:
                if method in ('GET', ):
                    if 'thumb.php' in r.url:
                        return {'r': True}

                    if params.get('a') in ('login', ) or action in ('login', ):
                        return {'r': True, 'd': resp}

                    stat = str(resp.get('status'))
                    if stat in ('0', ):
                        return {'r': True, 'd': resp}
                    elif stat in ('98', ):
                        ret = g.loginCheck(skipHit=True)
                        if ret.get('result'):
                            params.pop('sid', None)
                            return self.request(method, url, data, params)
                        else:
                            errMsg = ret.get('msg')
                            g.log_error(errMsg)
                    else:
                        errMsg = resp.get('msg') if 'msg' in resp else resp.get('error')
                else:
                    return {'r': True}
            except ValueError:
                errMsg = u'ValueError'
                g.log_error(traceback.format_exc())
        else:
            errMsg = u'API Error'
            g.log_error(u'API Error: ({0}) {1}'.format(r.status_code, r.text))

        return {'r': False, 'e': errMsg, 'httpcode': r.status_code}

    def get(self, url, params):
        try:
            if 'sid' not in params:
                params['sid'] = g().get('sid')

            params['json'] = 1
            r = requests.get(url, params=params, cookies=g().get('cookies'), verify=False)
            g.log_debug(type(self).__name__, g.getFuncName(), r.url)

            if r.ok:
                resp = json.loads(r.text)

                if eval(resp['status']) == 0:
                    return {'r': True, 'd': resp}
                else:
                    errMsg = resp['msg'] if 'msg' in resp else resp['error']
            else:
                errMsg = 'HTTP error'
        except requests.exceptions.ConnectionError:
            g.refresh()
            return self.get(url, params)
        except Exception, e:
            raise
            errMsg = str(e)

        return {'r': False, 'e': errMsg}

    def post(self, url, params=dict()):
        try:
            r = requests.post(url, data=params)
            g.debug(type(self).__name__, g.getFuncName(), r.url)

            if r.ok:
                resp = json.loads(r.text)
                return resp
            else:
                errMsg = 'HTTP error'
        except requests.exceptions.ConnectionError:
            g.refresh()
            return self.get(url, params)
        except Exception, e:
            errMsg = str(e)

        return {'r': False, 'e': errMsg}
