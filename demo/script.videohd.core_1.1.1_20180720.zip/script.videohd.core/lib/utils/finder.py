"""A Simple UDP class."""
import time
import socket
import threading
from threading import Thread

from lib import g

FINDER_REQ_HEADER = '\x00\x00\x00\x00\x00\x00\x43\x6c\x00\x00\x01\x00\x00\x00\x25\x04'
FINDER_UDP_PORT = 8097
RECV_MAX_LEN = 4096

MAC_ADDRESS_START_IDX = 0
MAC_ADDRESS_END_IDX = 6
DATA_TAG_START_IDX = 16

class UDP(object):
    """Socket UDP framework."""

    def __init__(self, port, broadcast=None):
        if broadcast is None:
            broadcast = '255.255.255.255'

        self.broadcast = broadcast
        self.port = port
        self.handle = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

        # Ask operating system to let us do broadcasts from socket
        self.handle.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

        try:
            self.handle.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
        except Exception, e:
            g.log_debug(msg=str(e))

        self.handle.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)

        # Bind UDP socket to local port so we can receive pings
        self.handle.bind(('', port))

    def send(self, buf):
        self.handle.sendto(buf, (self.broadcast, self.port))

    def recv(self, n=RECV_MAX_LEN):
        # return buf, addrinfo
        return self.handle.recvfrom(n)

    def close(self):
        self.handle.close()

class TagConverter(object):
    """Tag Transfer."""

    tag_mapping = {
        1: 'server_name', # TAG_SERVER_NAME
        53 :'web_port', # TAG_PORT_NUMBER
        202: 'extension', # TAG_EXTENSION
        40: 'model_name', # TAG_MODEL_NAME
        73: 'display_model_name' # TAG_NAS_DISPLAY_MODEL_NAME
    }

    tag_extetnsion_mapping = {
        621 : 'enable_force_ssl', # TAG_EXT_ENABLE_FORCE_SSL
        263 : 'ssl_port' # TAG_EXT_SECURE_ADMINPORT_NUMBER
    }

    def __init__(self, tag_type='builtin'):
        self.tag_type = tag_type

    def key(self, tag_id):
        if self.tag_type in ('builtin', ):
            if tag_id not in self.tag_mapping:
                return ''

            return self.tag_mapping.get(tag_id)
        else:
            if tag_id not in self.tag_extetnsion_mapping:
                return ''

            return self.tag_extetnsion_mapping.get(tag_id)

class Finder(threading.Thread):
    def __init__(self):
        threading.Thread.__init__(self)
        self.u = UDP(FINDER_UDP_PORT)
        self.nas_list = dict()
        self.receiver = ''
        self.event = threading.Event()

        self.boardcast_finder_req()
        self.start()

    def run(self):
        while not self.event.is_set():
            data, (ip, port) = self.u.recv()
            if port in (FINDER_UDP_PORT, ) and (data[6] in ('S', ) and data[7] in ('e', )):
                if ip not in self.nas_list:
                    self.nas_list[ip] = dict()

                    self._extract_mac_address(ip, list(data[MAC_ADDRESS_START_IDX:MAC_ADDRESS_END_IDX]))
                    self._extract_data_tag(ip, list(data[DATA_TAG_START_IDX:]))

            time.sleep(0.05)

    def _extract_mac_address(self, ip, raw_data):
        nas_dict = self.nas_list[ip]
        mac_list = [hex(ord(r)).lstrip('0x').zfill(2) for r in raw_data]

        self.nas_list[ip]['mac_address'] = ':'.join(mac_list)

    def byte_to_int(self, data):
        return int(''.join([hex(ord(r)).lstrip('0x').zfill(2) for r in data[::-1]]), 16)

    def byte_to_str(self, data):
        return ''.join(data).rstrip('\n').rstrip('\x00')

    def _extract_ext_data_tag(self, ip, raw_ext_data):
        nas_dict = self.nas_list[ip]

        ext_tag_data = dict()
        ext_tag_id = self.byte_to_int(raw_ext_data[:4])

        if TagConverter('extension').key(ext_tag_id) in ('enable_force_ssl', 'ssl_port', ):
            ext_tag_len = ord(raw_ext_data[4])
            ext_tag_data = raw_ext_data[-ext_tag_len:]
            nas_dict[TagConverter('extension').key(ext_tag_id)] = self.byte_to_int(ext_tag_data)

        return ext_tag_data

    def _extract_data_tag(self, ip, raw_data):
        nas_dict = self.nas_list[ip]

        tag_len = len(raw_data)
        data_tag = dict()

        while raw_data and not self.event.is_set():
            tag_id = ord(raw_data.pop(0))
            tag_len = ord(raw_data.pop(0))
            tag_data = raw_data[:tag_len]

            if TagConverter().key(tag_id) in ('extension', ):
                self._extract_ext_data_tag(ip, tag_data)
            elif TagConverter().key(tag_id) in ('web_port', ):
                nas_dict[TagConverter().key(tag_id)] = self.byte_to_int(tag_data[:4])
            elif TagConverter().key(tag_id) in ('server_name', 'model_name', 'display_model_name', ):
                nas_dict[TagConverter().key(tag_id)] = self.byte_to_str(tag_data)

            raw_data = raw_data[tag_len:]

    def boardcast_finder_req(self):
        for i in range(3):
            self.u.send(FINDER_REQ_HEADER)
            time.sleep(0.001)

    def list_current_nas(self):
        return self.nas_list

    def total_current_nas(self):
        return len(self.nas_list)

    def reset_current_nas(self):
        self.nas_list = dict()
        self.boardcast_finder_req()

    def stop_finder(self):
        self.event.set()
        self.u.close()

def main():
    fd = Finder()
    while True:
        try:
            cmd = raw_input("[VideoHD Finder]: ")

            if cmd in ('bye', ):
                fd.stop_finder()
                break
            elif cmd in ('list.nas', ):
                print fd.list_current_nas()
            elif cmd in ('list.total', ):
                print fd.total_current_nas()
            elif cmd in ('list.reset', ):
                fd.reset_current_nas()
        except KeyboardInterrupt:
            fd.stop_finder()
            break

if __name__ == "__main__":
    main()
