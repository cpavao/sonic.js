import time
import Queue
import traceback
import threading

import xbmc

class ResultPool(object):
    _instance = None

    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            cls._instance = super(ResultPool, cls).__new__(cls, *args, **kwargs)
            cls._instance.pool = {}

        return cls._instance

    @classmethod
    def list(cls):
        return cls._instance.pool

    @classmethod
    def get(cls, key):
        if key in cls._instance.pool:
            return cls._instance.pool[key]

        return None

    @classmethod
    def keys(cls):
        return cls._instance.pool.keys()

    @classmethod
    def set(cls, key, val):
        cls._instance.pool[key] = {'result': val, 'timestamp': time.time()}

    @classmethod
    def save(cls, key, val):
        if key in cls._instance.pool:
            cls._instance.pool[key]['result'] = val

    @classmethod
    def clear(cls):
        cls._instance.pool = {}

    @classmethod
    def pop(cls, key):
        return cls._instance.pool.pop(key, None)


class Worker(threading.Thread):
    def __init__(self, taskQueue):
        threading.Thread.__init__(self)
        self.setDaemon(True)
        self.taskQueue = taskQueue
        self.result = ResultPool()
        self.start()

    def run(self):
        while True:
            command, task_name, callback, args, kwds = self.taskQueue.get()

            try:
                if command == 'stop':
                    break
                if command != 'process':
                    raise ValueError('Unknown command %r' % command)

                self.result.save(task_name, callback(*args, **kwds))
            except:
                self.result.save(task_name, {'err': traceback.format_exc()})

    def dismiss(self):
        self.taskQueue.put(('stop', None, None, None, None))


class BackgroundTask():
    maxThread = 32

    def __init__(self, numThread, poolSize=0):
        self.numThread = BackgroundTask.maxThread \
            if numThread > BackgroundTask.maxThread \
            else numThread
        self.taskQueue = Queue.Queue(poolSize)
        self.result = ResultPool()

        self.initWorker()

    def initWorker(self):
        self.workers = {}

        for i in range(self.numThread):
            worker = Worker(self.taskQueue)
            self.workers[i] = worker

    def restart(self):
        self.destroy()
        self.initWorker()

    def add_task(self, task_name, callback, *args, **kwds):
        command = 'process'
        task = self.result.get(task_name)

        if not task:
            self.result.set(task_name, 'init')

        self.taskQueue.put((command, task_name, callback, args, kwds))

    def get_task_result(self, task_name):
        task = self.result.get(task_name)
        if task:
            return task.get('result')

        return None

    def get_task_timestamp(self, task_name):
        task = self.result.get(task_name)
        if task:
            return task.get('timestamp')

        return -1

    def get_all_task_result(self):
        return self.result.list()

    def get_all_task_name(self):
        return self.result.keys()

    def clear_keywords_task_result(self, keywords):
        for task_name in self.get_all_task_name():
            if keywords in task_name:
                self.result.set(task_name, 'init')

    def clear_task_result(self, task_name):
        self.result.set(task_name, 'init')

    def clear_all_task_result(self):
        self.result.clear()

    def destroy(self):
        if hasattr(self, 'workers'):
            self.result.clear()

            for i in self.workers:
                self.workers[i].dismiss()

            for i in self.workers:
                self.workers[i].join()

            xbmc.log('BgTask {0} workers destroy.'.format(len(self.workers)))
            del self.workers
