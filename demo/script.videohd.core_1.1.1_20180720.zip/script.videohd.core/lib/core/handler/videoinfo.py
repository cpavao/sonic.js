# -*- coding: utf-8 -*-
"""VideoHD Video information page."""
import xbmc
import xbmcgui
import xbmcaddon

from lib import g
from lib import ID, ACTION
from lib.static import *
from lib.api.videostation import VideoStationAPI

__addon__ = xbmcaddon.Addon()
__language__ = __addon__.getLocalizedString
__addonpath__ = __addon__.getAddonInfo('path').decode('utf-8')


class VideoInfoHandler(xbmcgui.WindowXML):

    """Video Information Handler."""

    def __init__(self, strXMLname, strFallbackPath, strDefaultName, forceFallback=0, selectItem=0, selectPos=0):
        """Init function."""
        self.initOK = False
        self.item = selectItem
        self.pos = selectPos

    def onInit(self):
        """onInit function."""
        g.setWaitingMask(self, state='init')
        if not self.initOK:
            self.getControl(ID.val('VideoInfo.BackTitle.Label')).setLabel(g.getCurrenViewLanguageMapping())

            self._initVideoInfo()
            self.initOK = True

        self._updatePlayButtonLabel()

    def _updatePlayButtonLabel(self):
        currentItem = self.item[self.pos]

        if currentItem.getProperty('offset_pure') in ('0', ):
            self.getControl(ID.val('VideoInfo.Play.Label')).setLabel(__language__(60032))
        else:
            self.getControl(ID.val('VideoInfo.Play.Label')).setLabel(__language__(60054))

    def _updateSelectedProgress(self):
        resp = VideoStationAPI().getPlayProgress(self.item[0].getProperty('id'))
        if not resp:
            return

        if resp.get('offset'):
            offset_pure = g.ensureUTF8(resp.get('offset'))
            s_time = g.showTime(g.timeTransfer(resp.get('offset')))
        else:
            s_time = g.showTime(g.timeTransfer())
            offset_pure = '0'

        self.item[0].setProperty('offset', s_time)
        self.item[0].setProperty('offset_pure', offset_pure)

    def _initVideoInfo(self):
        subtypeResp = self._getBgSubtypeData().get('classificationMapping')
        getSubtype = subtypeResp.get(self.item[0].getProperty('videoinfomask'))['subtypeName']
        self.item[0].setProperty('classification', getSubtype)

        self.getControl(ID.val('VideoInfo.Videolist.Panel')).addItems(self.item)
        self.getControl(ID.val('VideoInfo.Color.Image')).setImage('video_label_0{}.png'.format(int(self.item[0].getProperty('colorlevel')) + 1))
        self.getControl(ID.val('VideoInfo.Rating.Image')).setImage('video_rating_{}.png'.format(self.item[0].getProperty('rating')))

        self._setTagInfo()

    def _setTagInfo(self):
        if self.item[0].getProperty('videotag') in ("", 'None', None, ):
            return

        listitems = list()
        panel = self.getControl(ID.val('VideoInfo.Tag.Panel'))

        for tag in self.item[0].getProperty('videotag').split(';'):
            p = xbmcgui.ListItem(tag)
            listitems.append(p)

        panel.reset()
        panel.addItems(items=listitems)

    def _getBgSubtypeData(self):
         while g().get('bgTask').get_task_result('classify.subtype') in ('init', ):
            xbmc.sleep(100)
         resp = g().get('bgTask').get_task_result('classify.subtype')
         if not resp:
             return None

         return resp

    def onAction(self, action):
        """Action function."""
        if action in (ACTION.val('PREVIOUS_MENU'), ACTION.val('BACK'), ):
            self.close()

    def onClick(self, controlID):
        """Click trigger function."""
        if controlID in (ID.val('VideoInfo.Play.Button'), ):
            g().get('player').play(listitem=self.item)

        if controlID in (ID.val('VideoInfo.Back.Button'), ):
            self.close()
