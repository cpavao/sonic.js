# -*- coding: utf-8 -*-
"""VideoHD Movies information page."""
from threading import Thread

import xbmc
import xbmcgui
import xbmcaddon

from lib import g
from lib import ID, ACTION
from lib.static import *

from lib.api.background import BackgroundHandler
from lib.core.dialog.description import DescriptionDialog
from lib.api.videostation import VideoStationAPI

__addon__ = xbmcaddon.Addon()
__language__ = __addon__.getLocalizedString
__addonpath__ = __addon__.getAddonInfo('path').decode('utf-8')


class MovieInfoHandler(xbmcgui.WindowXML):

    """Movies Information Handler."""

    def __init__(self, strXMLname, strFallbackPath, strDefaultName, forceFallback=0, selectItem=0):
        """Init function."""
        self.initOK = False
        self.focusItem = selectItem

        '''
        Appending director and actor is slow in usual.
        So have to create another method to solve it.
        '''
        self.appendItems = list()

    def onInit(self):
        """onInit function."""
        g.setWaitingMask(self, state='init')

        self.movieinfoFixedList = self.getControl(ID.val('Movieinfo.Playlist.Fixedlist'))

        if not self.initOK:
            g.setWaitingMask(self, state='on')
            self._initMovieInfoFixedList()
            self.movieinfoFixedList.selectItem(self.focusItem)
            xbmc.sleep(100)
            self.setFocusId(ID.val('Movieinfo.Play.Button'))
            g.setWaitingMask(state='off')
            self.initOK = True
        else:
            self._updateSelectedProgress()

        self._updatePlayButtonLabel()

    def _updatePlayButtonLabel(self):
        currentItem = self.movieinfoFixedList.getSelectedItem()

        if currentItem.getProperty('offset_pure') in ('0', ):
            self.getControl(ID.val('Movieinfo.Play.Label')).setLabel(__language__(60032))
        else:
            self.getControl(ID.val('Movieinfo.Play.Label')).setLabel(__language__(60054))

    def _updateSelectedProgress(self):
        selectItem = self.movieinfoFixedList.getSelectedItem()
        resp = VideoStationAPI().getPlayProgress(selectItem.getProperty('id'))

        if not resp:
            return

        if resp.get('offset'):
            offset_pure = g.ensureUTF8(resp.get('offset'))
            s_time = g.showTime(g.timeTransfer(resp.get('offset')))
        else:
            s_time = g.showTime(g.timeTransfer())
            offset_pure = '0'

        g.getCurrentStatus('Movie').get('items')[self.movieinfoFixedList.getSelectedPosition()].setProperty('offset', s_time)
        g.getCurrentStatus('Movie').get('items')[self.movieinfoFixedList.getSelectedPosition()].setProperty('offset_pure', offset_pure)

    def _initMovieInfoFixedList(self):
        '''Thread(target=self._directorActor).start()'''
        g.saveThread(Thread(target=self._directorActor))

        self.movieinfoFixedList.reset()
        self.movieinfoFixedList.addItems(items=g.getCurrentStatus('Movie').get('items'))

    def _directorActor(self):
        tmp = list()
        listitems = list()

        aItems = self.appendItems if self.appendItems else g.getCurrentStatus('Movie').get('items')

        for item in aItems:
            resp = VideoStationAPI().getIMDBInfo({'fileId': item.getProperty('id')})
            if not resp:
                continue

            item.setProperty('director', resp.get('Director') if resp.get('Director') else '--')
            item.setProperty('actors', resp.get('Actor') if resp.get('Actor') else '--')
            listitems.append(item)
            xbmc.sleep(500)

        if self.appendItems:
            tmp = g.getCurrentStatus('Movie', 'items')
            tmp[-len(listitems):] = listitems

        g.saveCurrentStatus('Movie', {'Movie': {'items': tmp if tmp else listitems}}, 'items')

    def _updateMovieInfoFixedList(self):
        self._initMovieInfoFixedList()

    def _paging(self):
        total = g.getCurrentStatus('Movie').get('totalItem')
        browsePos = self.movieinfoFixedList.getSelectedPosition()
        movieinfoFixedListSize = self.movieinfoFixedList.size()

        if browsePos in ((movieinfoFixedListSize - 1), ) and movieinfoFixedListSize < int(total):
            resp = self._getBgData()
            items = list() if not resp else resp.get('items')

            # updating and storing the movie items and page
            updateMovieItem = g.getCurrentStatus('Movie')['items'] + items
            updateMoviePage = g.getCurrentStatus('Movie')['page'] + 1
            updateData = {'Movie': {'items': updateMovieItem, 'page': updateMoviePage}}
            g.saveCurrentStatus('Movie', updateData, ['items', 'page'])

            # updating movieinfo panel
            self.appendItems = items
            self._updateMovieInfoFixedList()

            # focusing paging point
            self.movieinfoFixedList.selectItem(browsePos)

            # preparing next page
            self._addBgTask()

    def _addBgTask(self):
        subtypeId = g.getCurrentStatus('Movie').get('subtypeId')
        page = g.getCurrentStatus('Movie').get('page')
        sortBy = g.getCurrentStatus('Movie').get('sortBy')
        orderBy = g.getCurrentStatus('Movie').get('orderBy')
        preparePayload = {'subtypeId': subtypeId, 'videoType': subtypeId, 'pages': page + 1, 'counts': MOVIEINFO_VIDEO_COUNT,
                          'sortBy': sortBy, 'orderBy': orderBy}
        handler = BackgroundHandler().classificationBackgroundData
        g().get('bgTask').add_task('browse.classify.1', handler, preparePayload)

    def _getBgData(self):
        # Movie's video type = 1
        while g().get('bgTask').get_task_result('browse.classify.1') in ('init', ):
            xbmc.sleep(100)
        resp = g().get('bgTask').get_task_result('browse.classify.1')
        if not resp:
            return None

        return resp

    def onAction(self, action):
        """Action function."""
        if action in (ACTION.val('RIGHT'), ACTION.val('LEFT'), ACTION.val('MOUSE_WHEEL_UP'), ACTION.val('MOUSE_WHEEL_DOWN'), ):
            if self.getFocusId() in (ID.val('Movieinfo.Playlist.Fixedlist'), ):
                self._updatePlayButtonLabel()

        if action in (ACTION.val('RIGHT'), ):
            if self.getFocusId() in (ID.val('Movieinfo.Playlist.Fixedlist'), ):
                total = g.getCurrentStatus('Movie').get('totalItem')
                if int(total) <= MOVIEINFO_VIDEO_COUNT:
                    return None

                self._paging()

        if action in (ACTION.val('PREVIOUS_MENU'), ACTION.val('BACK'), ):
            lastFocus = self.movieinfoFixedList.getSelectedPosition()
            g.saveCurrentStatus('Movie', {'Movie': {'lastFocus': lastFocus}}, 'lastFocus')
            self.close()

    def onClick(self, controlID):
        """Click trigger function."""
        if controlID in (ID.val('Movieinfo.Back.Button'), ):
            lastFocus = self.movieinfoFixedList.getSelectedPosition()
            g.saveCurrentStatus('Movie', {'Movie': {'lastFocus': lastFocus}}, 'lastFocus')
            self.close()
            return

        if controlID in (ID.val('Movieinfo.Playlist.Fixedlist'), ID.val('Movieinfo.Play.Button'), ):
            g().get('player').play(listitem=[self.movieinfoFixedList.getSelectedItem()])

        if controlID in (ID.val('Movieinfo.Description.Button'), ):
            item = self.getControl(ID.val('Movieinfo.Playlist.Fixedlist')).getSelectedItem()
            w = DescriptionDialog('dlg_description.xml', __addonpath__, "Default", item=item)
            w.doModal()
            del w
