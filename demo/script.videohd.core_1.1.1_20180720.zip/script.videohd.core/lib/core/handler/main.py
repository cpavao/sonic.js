# -*- coding: utf-8 -*-
"""VideoHD main page."""
from threading import Thread

import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin

from lib.static import *
from lib import g, ID, ACTION

from lib.api.background import BackgroundHandler

from lib.core.handler.browse import browseHandler
from lib.core.dialog.help import HelpDialog
from lib.core.dialog.login import LoginDialog
from lib.core.handler.tvshowinfo import TVShowInfoHandler

# from lib.utils.remote import remote

__addon__ = xbmcaddon.Addon()
__addonpath__ = __addon__.getAddonInfo('path').decode('utf-8')
__language__ = __addon__.getLocalizedString


class mainHandler(xbmcgui.WindowXML):

    """Main Handler."""

    def __init__(self, strXMLname, strFallbackPath, strDefaultName, forceFallback=0):
        """Init function."""
        self.initOK = False
        self.vtContainer = list()
        self.count = 1
        self.currentSubtypes = dict()
        self.classifyButton = {'0': {'ButtonName': 'Uncategory'},
                               '1': {'ButtonName': 'Movie'},
                               '2': {'ButtonName': 'TvShow'},
                               '3': {'ButtonName': 'MusicVideo'},
                               '4': {'ButtonName': 'HomeVideo'},
                               '5': {'ButtonName': 'KTV'}}
        self.classifyPos = 0
        self.currentPosIdx = -1
        self.otherVideoType = ['RecentlyImported', 'RecentlyWatched', 'ShareVideo', 'Folder', 'VideoCollection', 'SmartCollection']

        self.subtypeIdContainer = list()

        self.manageIcons = {
            'home_watched': {'label': __language__(60004), 'view_tag': 'RecentlyWatched'},
            'home_imported': {'label': __language__(60005), 'view_tag': 'RecentlyImported'},
            'home_shared_video': {'label': __language__(60006), 'view_tag': 'ShareVideo'},
            'home_folder': {'label': __language__(60007), 'view_tag': 'Folder'}
        }

        self.collectIcons = {
            'home_collection': {'label': __language__(60008), 'view_tag': 'VideoCollection'},
            'home_smart_collection': {'label': __language__(60009), 'view_tag': 'SmartCollection'}
        }

        self.loginCheck = g.loginCheck()

        if g.getHomeProperty('Global.LoginRequire'):
            w = LoginDialog('dlg_login.xml', __addonpath__, "Default")
            w.doModal()
            del w

    def _addInitTask(self):
        g().get('bgTask').add_task('main.classify.1', BackgroundHandler().classificationBackgroundData,
                                   {'subtypeId': 1, 'videoType': '1',
                                    'pages': 1, 'counts': MAIN_VIDEO_COUNT,
                                    'sortBy': 'dbtime', 'orderBy': 'DESC'})

    def _updateSubtype(self):
        while (not xbmc.abortRequested):
            if g().get('BreakThread'):
                break

            if xbmc.getGlobalIdleTime() < GLOBAL_IDLE_SEC_TIME and not g.getHomeProperty('Global.LoginRequire'):
                g().get('bgTask').add_task('classify.subtype', BackgroundHandler().classificationSubtype)

                resp = self._getBgData('classify.subtype', True)
                if not resp:
                    return

                if self.currentSubtypes != resp.get('pure_items'):
                    if xbmcgui.getCurrentWindowId() in (self.windowId, ):
                        self._initSubtype('init')

                        self.setFocusId(ID.val('Home.Classification.Fixedlist'))
                        xbmc.sleep(100)
                        self._updateClassification()

            xbmc.sleep(5000)

    def onInit(self, forceInit=False):
        """onInit function."""
        self.windowId = xbmcgui.getCurrentWindowId()

        g.setWaitingMask(self, state='init')
        g.clearHomeProperty('Main.ShowEmptyMessage')

        if not forceInit:
            g.saveThread(Thread(target=self._updateSubtype))

        self._initManagementIcon()
        self._initCollectionIcon()

        if g.getHomeProperty('Global.LoginRequire'):
            self._handlerFocus()
            return

        self._initSubtype()
        # Delay for Home.Classification.Fixedlist position ready.
        xbmc.sleep(300)

        self._updateClassification()

        if not self.initOK:
            self._handlerFocus()
            self.initOK = True

    def _handlerFocus(self):
        if g.getHomeProperty('Global.LoginRequire'):
            self.setFocusId(ID.val('Home.Login.Button'))
            return

        if g.getHomeProperty('Main.ShowEmptyMessage'):
            self.setFocusId(ID.val('Home.Classification.Button'))
            return

        selectClassify = self.getControl(ID.val('Home.Classification.Fixedlist')).getSelectedItem()
        videoType = selectClassify.getProperty('vt') if selectClassify else DEFAULT_CLASSIFICATION_TYPE

        if videoType:
            if str(videoType) in ('1', '2', ):
                self.setFocusId(ID.val('Home.Poster.Wraplist'))
            else:
                self.setFocusId(ID.val('Home.Thumbnail.Wraplist'))
        else:
            self.setFocusId(ID.val('Home.Classification.Button'))

    def _initManagementIcon(self):
        listitems = list()

        panel = self.getControl(ID.val('Home.Management.Panel'))
        panel.reset()

        for icon in self.manageIcons.keys():
            p = xbmcgui.ListItem(self.manageIcons[icon].get('label'), '', '', '{}.png'.format(icon))
            p.setProperty('focus.thumb', '{}_focus.png'.format(icon))
            p.setProperty('view_tag', self.manageIcons[icon].get('view_tag'))
            listitems.append(p)

        panel.addItems(items=listitems)

    def _initCollectionIcon(self):
        listitems = list()

        panel = self.getControl(ID.val('Home.Collection.Panel'))
        panel.reset()

        for icon in self.collectIcons.keys():
            p = xbmcgui.ListItem(self.collectIcons[icon].get('label'), '', '', '{}.png'.format(icon))
            p.setProperty('focus.thumb', '{}_focus.png'.format(icon))
            p.setProperty('view_tag', self.collectIcons[icon].get('view_tag'))
            listitems.append(p)

        panel.addItems(items=listitems)

    def _initSubtype(self, action='init'):
        # 0(Uncategorized), 1(Movies), 2(TV Shows), 3(Music Videos), 4(Home Videos), 5(KTV)
        fixedlist = self.getControl(ID.val('Home.Classification.Fixedlist'))
        position = fixedlist.getSelectedPosition() if action in ('update', ) else 0

        if action in ('init', ):
            self.count = 1
            self.classifyButton = {'0': {'ButtonName': 'Uncategory'},
                                   '1': {'ButtonName': 'Movie'},
                                   '2': {'ButtonName': 'TvShow'},
                                   '3': {'ButtonName': 'MusicVideo'},
                                   '4': {'ButtonName': 'HomeVideo'},
                                   '5': {'ButtonName': 'KTV'}}

        resp = self._getBgData('classify.subtype', True)
        if not resp or resp.get('err'):
            print resp
            return

        self.currentSubtypes = resp.get('pure_items')

        fixedlist.reset()
        fixedlist.addItems(items=resp.get('items'))
        fixedlist.selectItem(position)

        if action in ('update', ):
            return

        for subtype in resp.get('items'):
            self._initCurrentStatus(subtype.getProperty('vt'))
            self.subtypeIdContainer.append(subtype.getProperty('vt'))

        # Load customize subtype order/sort method.
        g.initSort()
        g.initSortMap()

        fixedlist.selectItem(self.classifyPos)

    def _initCurrentStatus(self, videoType):
        data = {'subtypeId': videoType, 'page': 1, 'items': list(), 'totalItem': 0, 'lastFocus': 0, 'sortBy': None, 'orderBy': None}

        if int(videoType) > 5:  # builtin video type: 0 ~ 5
            g.updateSortList('Other{}'.format(self.count))
            g.initSortFile()

            g.initCurrentStatus('Other{}'.format(self.count), data)

            self.classifyButton[videoType] = {'ButtonName': 'Other{}'.format(self.count)}

            self.count += 1
            return

        if int(videoType) < 6:  # there are 6 types in the other video type so far
            if self.otherVideoType[int(videoType)] in ('Folder', ):
                g.initCurrentStatus(self.otherVideoType[int(videoType)], {'layer1': dict(), 'layerStack': 1, 'currentPrefix': None})
            else:
                if self.otherVideoType[int(videoType)] in ('RecentlyImported', 'RecentlyWatched', ):
                    otherData = {'page': 1, 'items': list(), 'totalItem': 0, 'lastFocus': 0}
                else:
                    otherData = {'page': 1, 'items': list(), 'totalItem': 0, 'lastFocus': 0, 'sortBy': None, 'orderBy': None}

                    if self.otherVideoType[int(videoType)] in ('SmartCollection', 'VideoCollection', ):
                        collectionInfo = '{}Videos'.format(self.otherVideoType[int(videoType)])
                        g.initCurrentStatus(collectionInfo, dict())

                g.initCurrentStatus(self.otherVideoType[int(videoType)], otherData)

        if self.classifyButton[videoType]['ButtonName'] in ('Movie', 'TvShow', ):
            data.update({'year': None, 'genre': None})

        g.initCurrentStatus(self.classifyButton[videoType]['ButtonName'], data)

    def _updateClassification(self, vt=None):
        try:
            videoType = vt if vt else self.getControl(ID.val('Home.Classification.Fixedlist')).getSelectedItem().getProperty('vt')

            self._addBgTask(videoType)

            wraplist_thumb = self.getControl(ID.val('Home.Thumbnail.Wraplist'))
            wraplist_poster = self.getControl(ID.val('Home.Poster.Wraplist'))

            wraplist_thumb.setVisible(False)
            wraplist_poster.setVisible(False)

            wraplist_thumb.reset()
            wraplist_poster.reset()

            self._addBgTask(videoType)
            resp = self._getBgData('main.classify.{}'.format(videoType))
            if not resp:
                return None

            if videoType in ('1', '2', ):
                wraplist_poster.setVisible(True)
                wraplist_poster.addItems(items=resp.get('items'))

                if hasattr(self, 'last_position'):
                    wraplist_poster.selectItem(self.last_position)
                    del self.last_position
            else:
                wraplist_thumb.setVisible(True)
                wraplist_thumb.addItems(items=resp.get('items'))

                if hasattr(self, 'last_position'):
                    wraplist_thumb.selectItem(self.last_position)
                    del self.last_position

            '''avoid the other view overlapping'''
            vtcheck = self.getControl(ID.val('Home.Classification.Fixedlist')).getSelectedItem().getProperty('vt')
            taskName = 'main.classify.{}'.format(vtcheck)

            wraplist_thumb.setVisible(False)
            wraplist_poster.setVisible(False)

            wraplist_thumb.reset()
            wraplist_poster.reset()

            resp = self._getBgData('{}'.format(taskName))
            if not resp:
                return None

            if vtcheck in ('1', '2', ):
                wraplist_poster.setVisible(True)
                wraplist_poster.addItems(items=resp.get('items'))
            else:
                wraplist_thumb.setVisible(True)
                wraplist_thumb.addItems(items=resp.get('items'))

            if taskName in g().get('bgTask').get_all_task_name():
                g.clearHomeProperty('Main.ShowEmptyMessage')
        except Exception as e:
            g.log_error('_updateClassification: {}'.format(str(e)))

    def _addBgTask(self, videoType):
        g().get('bgTask').add_task('main.classify.{}'.format(videoType), BackgroundHandler().classificationBackgroundData,
                                   {'subtypeId': videoType, 'videoType': videoType,
                                    'pages': 1, 'counts': MAIN_VIDEO_COUNT,
                                    'sortBy': 'dbtime', 'orderBy': 'DESC'})

    def _getBgData(self, taskName, skipSetEmptyMessage=False):
        while g().get('bgTask').get_task_result(taskName) in ('init', ):
            xbmc.sleep(100)
        resp = g().get('bgTask').get_task_result(taskName)

        if not skipSetEmptyMessage:
            if not resp:
                g.setHomeProperty('Main.ShowEmptyMessage', 'true')
            else:
                g.clearHomeProperty('Main.ShowEmptyMessage')

        return resp

    def _initBackgroundTask(self):
        # view(w) = 1 => watching, view(w) = 2 => watched, view(w) = 0 => not watch ; to judge the video was viewed or not
        g().get('bgTask').add_task('history', BackgroundHandler().historyBackgroundData, {'pages': '1', 'counts': HISTORY_COUNT, 'view': '1'})
        g().get('bgTask').add_task('recently', BackgroundHandler().recentlyBackgroundData, {'pages': '1', 'counts': RECENTLY_COUNT})

        g().get('bgTask').add_task('collect.albums', BackgroundHandler().collectionBackgroundData,
                                   {'albumType': 'albums', 'pages': None, 'counts': None})
        g().get('bgTask').add_task('collect.smartalbums', BackgroundHandler().collectionBackgroundData,
                                   {'albumType': 'smartAlbums', 'pages': None, 'counts': None})

        while g().get('bgTask').get_task_result('classify.subtype') in ('init', ):
            xbmc.sleep(100)
        resp = g().get('bgTask').get_task_result('classify.subtype')
        if not resp:
            return

        if resp:
            # vt(videoType): 0(Uncategorized), 1(Movies), 2(TV Shows), 3(Music Videos), 4(Home Videos), 5(KTV)
            for subtype in resp.get('items'):
                subtypeId = subtype.getProperty('vt')
                subtypeName = subtype.getProperty('subtypeName')
                if not g.getSort(subtypeName):
                    g.setSort(subtypeName, 'name', 'DESC')

                g().get('bgTask').add_task('classify.{}'.format(subtypeId), BackgroundHandler().classificationBackgroundData,
                                           {'subtypeId': subtypeId, 'videoType': subtypeId, 'pages': 1, 'counts': CLASSIFICATION_COUNT,
                                            'sortBy': g.getSort(subtypeName)['sortValue'], 'orderBy': g.getSort(subtypeName)['orderValue']})

    def onAction(self, action):
        """Action function."""
        if not self.getFocusId() and action not in ACTION.groupID('MOUSE_'):
            self._handlerFocus()
            return

        if action in (ACTION.val('LEFT'), ACTION.val('RIGHT'),
                      ACTION.val('MOUSE_MOVE'), ACTION.val('MOUSE_WHEEL_UP'), ACTION.val('MOUSE_WHEEL_DOWN'), ):
            if self.getFocusId() in (ID.val('Home.Classification.Fixedlist'), ):
                g.clearHomeProperty('Main.ShowEmptyMessage')

                if action in (ACTION.val('MOUSE_MOVE'), ACTION.val('MOUSE_WHEEL_UP'), ACTION.val('MOUSE_WHEEL_DOWN'), ):
                    browsePos = self.getControl(ID.val('Home.Classification.Fixedlist')).getSelectedPosition()
                    if self.currentPosIdx != browsePos:
                        self.currentPosIdx = browsePos
                    else:
                        return

                    if g.getHomeProperty('reload') in ('reloading', ):
                        return

                    g.setHomeProperty('reload', 'reloading')

                    self._updateClassification()

                    g.clearHomeProperty('reload')
                    return

                self.getControl(ID.val('Home.Thumbnail.Wraplist')).reset()
                self.getControl(ID.val('Home.Poster.Wraplist')).reset()

                vt = self.getControl(ID.val('Home.Classification.Fixedlist')).getSelectedItem().getProperty('vt')
                self.vtContainer.append(vt)
                xbmc.sleep(150)
                if not self.vtContainer:
                    return
                self._updateClassification(self.vtContainer[-1:][0])
                self.vtContainer = list()

        '''if action in (ACTION.val('UNIVERSAL'), ):
            remote.execute(action)
            return'''

        if action in (ACTION.val('PREVIOUS_MENU'), ACTION.val('BACK'), ):
            if g.getHomeProperty('Main.ShowSettingsControl'):
                g.clearHomeProperty('Main.ShowSettingsControl')
                self.setFocusId(ID.val('Home.Toolbar.Grouplist'))
                return

            leave = g.showDialog('yesno', {'line1': __language__(62002)}, {'yes': __language__(60073), 'no': __language__(60072)})
            '''leave = 0(no/back action.), leave = 1(yes)'''
            if not leave:
                return

            # g.setWaitingMask(state='on', msg=__language__(63003))
            self.close()

    def playDirect(self):
        url = 'http://172.17.40.58:8080/video/api/video.php?a=display&f=jSuojr&sid=92163236fac07da8134ace9450b9e4c2&s=&ac=&ss='
        play_item = xbmcgui.ListItem('title', 'subtitle')
        play_item.setMimeType(mimetype='video/x-matroska')
        play_item.setContentLookup(False)

        playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playlist.add(url, play_item)
        xbmcplugin.setResolvedUrl(13000, True, play_item)
        xbmc.Player().play(item=playlist)


    def onClick(self, controlID):
        # self.playDirect()
        # return

        """Click trigger function."""
        if controlID in (ID.val('Home.SettingsMask.Button'), ):
            g.clearHomeProperty('Main.ShowSettingsControl')
            return

        if controlID in (ID.val('Home.Settings.Button'), ):
            # g.setHomeProperty('Main.ShowSettingsControl', 'show')
            # xbmc.sleep(100)
            # self.setFocusId(ID.val('Home.Settings.Grouplist'))

            g.setHomeProperty('Run.Settings', 'true')
            self.close(False)
            return

        '''if controlID in (ID.val('Home.PlayerSetting.Button'), ):
            return

        if controlID in (ID.val('Home.InterfaceSetting.Button'), ):
            g.setHomeProperty('Run.Settings', 'true')
            self.close(False)
            return'''

        if controlID in (ID.val('Home.Management.Panel'), ID.val('Home.Collection.Panel'), ) and g.getHomeProperty('Global.LoginRequire'):
            return

        if controlID in (ID.val('Home.Exit.Button'), ):
            leave = g.showDialog('yesno', {'line1': __language__(62002)}, {'yes': __language__(60073), 'no': __language__(60072)})
            '''leave = 0(no/back action.), leave = 1(yes)'''
            if not leave:
                return

            self.close()
            return

        if controlID in (ID.val('Home.Login.Button'), ID.val('Home.Account.Button'), ):
            w = LoginDialog('dlg_login.xml', __addonpath__, "Default")
            w.doModal()

            if not w.loginCancel:
                g().get('bgTask').clear_all_task_result()
                self.onInit(True)

            del w

            return

        videoType = self.getControl(ID.val('Home.Classification.Fixedlist')).getSelectedItem().getProperty('vt')
        wraplist = self.getControl(ID.val('Home.Poster.Wraplist')) if videoType in ('1', ) else self.getControl(ID.val('Home.Thumbnail.Wraplist'))
        self.last_position = wraplist.getSelectedPosition()

        if controlID in (ID.val('Home.Help.Button'), ):
            w = HelpDialog('dlg_help.xml', __addonpath__, "Default")
            w.doModal()
            del w
            return

        if controlID in (ID.val('Home.Poster.Wraplist'), ID.val('Home.Thumbnail.Wraplist'), ):
            if videoType in ('2', ):
                select = self.getControl(controlID).getSelectedItem()
                w = TVShowInfoHandler('win_tvshowinfo.xml', __addonpath__, "Default", selectItem=select)
                w.doModal()
                del w
                return

            g().get('player').play(listitem=[wraplist.getSelectedItem()])
            return

        if controlID in (ID.val('Home.Management.Panel'), ):
            selectItem = self.getControl(ID.val('Home.Management.Panel')).getSelectedItem()
            g.setHomeProperty('Browse.CurrentView', selectItem.getProperty('view_tag'))
        elif controlID in (ID.val('Home.Collection.Panel'), ):
            selectItem = self.getControl(ID.val('Home.Collection.Panel')).getSelectedItem()
            g.setHomeProperty('Browse.CurrentView', selectItem.getProperty('view_tag'))
        else:
            videoType = self.getControl(ID.val('Home.Classification.Fixedlist')).getSelectedItem().getProperty('vt')
            selectVideoType = self.classifyButton[videoType]['ButtonName']
            g.setHomeProperty('Browse.CurrentView', selectVideoType)
            g.setHomeProperty('Browse.Classification.Movie.Selected', selectVideoType)

        self.classifyPos = self.getControl(ID.val('Home.Classification.Fixedlist')).getSelectedPosition()

        g().get('bgTask').clear_keywords_task_result('main.classify.')
        w = browseHandler('win_browse.xml', __addonpath__, "Default")
        w.doModal()
        del w

    def close(self, shutdown=True):
        g.setWaitingMask(self, state='on')
        g.stopVideoHD(shutdown)

        super(mainHandler, self).close()
   
