# -*- coding: utf-8 -*-
"""VideoHD browse page."""
from threading import Thread

import xbmc
import xbmcgui
import xbmcaddon

from lib import g, ID, ACTION
from lib.static import *

from lib.core.dialog.sidemenu import SidemenuDialog
from lib.core.dialog.sorting import SortingDialog
from lib.core.dialog.filter import FilterDialog
# from lib.core.dialog.help import HelpDialog
from lib.core.handler.movieinfo import MovieInfoHandler
from lib.core.handler.tvshowinfo import TVShowInfoHandler
from lib.core.handler.videoinfo import VideoInfoHandler

from lib.api.background import BackgroundHandler
from lib.api.videostation import VideoStationAPI

__addon__ = xbmcaddon.Addon()
__addonpath__ = __addon__.getAddonInfo('path').decode('utf-8')
__language__ = __addon__.getLocalizedString


class browseHandler(xbmcgui.WindowXML):

    """Browse Handler."""

    def __init__(self, strXMLname, strFallbackPath, strDefaultName, forceFallback=0, entryPoint=None):
        """Init function."""
        self.initOK = False
        self.entryPoint = entryPoint

        self.currentPosIdx = -1
        self.currentStatus = dict()

        self.avoidOnactionAgain = 0

        self.updateCollection = dict()

        self.refreshClick = False

        self.pagingStatus = False

        self.otherVideoType = {'RecentlyImported': dict(), 'RecentlyWatched': {'view': 1}, 'ShareVideo': dict(),
                               'VideoCollection': {'albumType': 'albums'}, 'SmartCollection': {'albumType': 'smartAlbums'},
                               'VideoCollectionVideos': {'albumId': None}, 'SmartCollectionVideos': {'albumId': None}}

        self.builtinButton = {0: {'ButtonName': 'Uncategory', 'lang': __language__(60015)},
                              1: {'ButtonName': 'Movie', 'lang': __language__(60010)},
                              2: {'ButtonName': 'TvShow', 'lang': __language__(60011)},
                              3: {'ButtonName': 'MusicVideo', 'lang': __language__(60012)},
                              4: {'ButtonName': 'HomeVideo', 'lang': __language__(60013)},
                              5: {'ButtonName': 'KTV', 'lang': __language__(60014)}}

        self.bgTaskName = {'RecentlyWatched': BackgroundHandler().historyBackgroundData,
                           'RecentlyImported': BackgroundHandler().recentlyBackgroundData,
                           'ShareVideo': BackgroundHandler().shareVideoBackgroundData,
                           'VideoCollection': BackgroundHandler().collectionBackgroundData,
                           'SmartCollection': BackgroundHandler().collectionBackgroundData,
                           'Classify': BackgroundHandler().classificationBackgroundData,
                           'VideoCollectionVideos': BackgroundHandler().collectioninfoBackgroundData,
                           'SmartCollectionVideos': BackgroundHandler().collectioninfoBackgroundData}

    def _refreshFocus(self, action=None):
        currentView = g.getHomeProperty('Browse.CurrentView')
        if action in ('noFocus', ):
            self.setFocusId(ID.val('Browse.Sidemenu.Button'))
            return

        if g.getViewType(currentView) in ('Classification', ):
            self.setFocusId(ID.val('Browse.Classification.{}.Button'.format(currentView)))

        if currentView in ('Movie', 'TvShow', ):
            panel = ID.val('Browse.Poster.Panel')
        elif currentView in ('Folder', ):
            panel = ID.val('Browse.Folder.Panel')
        elif currentView in ('VideoCollection', 'SmartCollection', ):
            panel = ID.val('Browse.Collection.Panel')
        else:
            panel = ID.val('Browse.Thumbnail.Panel')

        if self.getControl(panel).size() > 0:
            self.setFocusId(panel)
        else:
            # Panel empty process.
            if g.getHomeProperty('Browse.CurrentView') in ('Folder', ):
                self.setFocusId(ID.val('Browse.PreviousFolder.Button'))
            elif g.getHomeProperty('Browse.CurrentView') in ('Movie', 'TvShow', ) and action in ('filter', ):
                self.setFocusId(ID.val('Browse.ResetFilterStatus.Button'))
            else:
                self.setFocusId(ID.val('Browse.Sidemenu.Button'))
            return

        if currentView in ('Folder', ):
            layer = 'layer{}'.format(self.currentStatus[currentView]['layerStack'])
            lastFocus = self.currentStatus[currentView][layer]['lastFocus']
            total = self.currentStatus[currentView][layer]['totalItem']
        else:
            if g.getViewType(currentView) in ('CollectionInfo', ):
                albumId = self.currentStatus[currentView]['currentAlbumId']
                lastFocus = self.currentStatus[currentView][albumId]['lastFocus']
                total = self.currentStatus[currentView][albumId]['totalItem']
            else:
                lastFocus = self.currentStatus[currentView]['lastFocus']
                total = self.currentStatus[currentView]['totalItem']

        if not lastFocus:
            self._updateTotalCount('1', total)

            if not action:
                xbmc.sleep(100)
                self.setFocusId(panel)
            return

        self.getControl(panel).selectItem(lastFocus)
        self._updateTotalCount(lastFocus + 1, total)

        if not action:
            xbmc.sleep(100)
            self.setFocusId(panel)

    def _reloadItem(self):
        """Prepare data here."""
        currentView = g.getHomeProperty('Browse.CurrentView')

        if g.getViewType(currentView) in ('Classification', 'Collection', ):
            if not self.currentStatus[currentView]['items']:
                # g.setWaitingMask(self, state='on')
                self._refreshVideo()
                # g.setWaitingMask(self, state='off')
        elif g.getViewType(currentView) in ('Management', ):
            if currentView in ('ShareVideo', 'RecentlyWatched', 'RecentlyImported', ):
                if not self.currentStatus[currentView]['items']:
                    g.setWaitingMask(self, state='on')
                    self._refreshVideo()
                    g.setWaitingMask(self, state='off')
            if currentView in ('Folder', ):
                if self.currentStatus['Folder']['layerStack'] in (1, ):
                    if not self.currentStatus['Folder']['layer1'] or not self.currentStatus['Folder']['layer1']['items']:
                        g.setWaitingMask(self, state='on')
                        self._loadFolderData('init')
                        self._folderPath()
                        self._initFolderPanel()
                        g.setWaitingMask(self, state='off')
                    else:
                        self._initFolderPanel()

                    return

                layer = 'layer{}'.format(self.currentStatus[currentView]['layerStack'])
                if not self.currentStatus['Folder'][layer]['items']:
                    g.setWaitingMask(self, state='on')
                    self._loadFolderData('sorting', self.currentStatus['Folder']['currentPrefix'], page=1)
                    self._initFolderPanel()
                    g.setWaitingMask(self, state='off')

                self._initFolderPanel()

    def _refreshVideo(self):
        currentView = g.getHomeProperty('Browse.CurrentView')

        if g.getHomeProperty('Sorting.Sort.Method') and g.getHomeProperty('Sorting.Order.Method'):
            sortBy = g.getHomeProperty('Sorting.Sort.Method')
            orderBy = g.getHomeProperty('Sorting.Order.Method')

            if currentView in ('Folder', ):
                self.currentStatus['Folder']['sortBy'] = sortBy
                self.currentStatus['Folder']['orderBy'] = orderBy
                self._loadFolderData('sorting', self.currentStatus['Folder']['currentPrefix'], page=1)
                self._initFolderPanel()
                return

            if g.getViewType(currentView) in ('CollectionInfo', ):
                albumId = self.currentStatus[currentView]['currentAlbumId']
                self.currentStatus[currentView][albumId]['sortBy'] = sortBy
                self.currentStatus[currentView][albumId]['orderBy'] = orderBy
            else:
                self.currentStatus[currentView]['sortBy'] = sortBy
                self.currentStatus[currentView]['orderBy'] = orderBy

        if g.getViewType(currentView) in ('Classification', ):
            subtypeId = self.currentStatus[currentView]['subtypeId']
            taskName = 'browse.classify.{}'.format(subtypeId)
        elif g.getViewType(currentView) in ('Management', 'Collection', ):
            if currentView in ('Folder', ):
                layer = 'layer{}'.format(self.currentStatus[currentView]['layerStack'])
                prefix = self.currentStatus[currentView]['currentPrefix']
                itemName = self.currentStatus[currentView][layer]['layerName']
                self.currentStatus[currentView]['layerStack'] -= 1

                self._loadFolderData(prefix=prefix, layerName=itemName)
                self._initFolderPanel()
                return

            taskName = 'browse.{}'.format(currentView)
        elif g.getViewType(currentView) in ('CollectionInfo', ):
            albumId = self.currentStatus[currentView]['currentAlbumId']
            taskName = 'browse.{0}.{1}'.format(currentView, albumId)

        g().get('bgTask').clear_task_result(taskName)
        self._addBgTask(action='refresh')

        self._storageLocalData(action='refresh')

        self._addBgTask()

    def _updateVideoHDFile(self, updateItems):
        sortBy = updateItems.get('sortBy')
        orderBy = updateItems.get('orderBy')

        for item in updateItems.get('items'):
            g.setSort(item, sortBy, orderBy)

    def onInit(self):
        """onInit function."""
        g.setWaitingMask(self, state='init')
        if not self.initOK:  # use this, because of xbmcgui.WindowXML and xbmcgui.WindowXMLDialog
            self.currentStatus = g.getCurrentStatus()
            g.setHomeProperty('Browse.Video.Loading', 'true')

            if g.getViewType(g.getHomeProperty('Browse.CurrentView')) in ('Classification', ):
                self._initSubtype()

            self._reloadItem()

            if g.getHomeProperty('Browse.CurrentView') not in ('Folder', ):
                self._initPanel()

            self._refreshFocus()
            self.initOK = True
            g.clearHomeProperty('Browse.Video.Loading')
        else:
            if g.getHomeProperty('Browse.CurrentView') in ('RecentlyWatched', ):
                g.setWaitingMask(self, state='on')
                self._refreshVideo()
                self._updatePanel()
                g.setWaitingMask(self, state='off')
                self._refreshFocus()

    def _countLayer(self, prefix):
        layerSplit = prefix.split('/')
        if '' in layerSplit:
            layerSplit.remove('')

        clearLayer = layerSplit
        countLayer = len(clearLayer)

        return countLayer

    def _loadFolderData(self, action=None, prefix=None, layerName=None, page=None):
        listitems = list()
        currentView = g.getHomeProperty('Browse.CurrentView')

        if action in ('init', ):
            folderMsg = {'pages': 1, 'counts': BROWSE_VIDEO_COUNT, 'dir': prefix}
            whichLayer = 1
        elif action in ('paging', 'sorting', ):
            if self.currentStatus[currentView]['layerStack'] in (1, ):
                prefix = None
            folderMsg = {'dir': prefix, 'pages': page, 'counts': BROWSE_VIDEO_COUNT}
            whichLayer = self.currentStatus[currentView]['layerStack']
        else:
            if self.currentStatus[currentView]['layerStack'] < 1:
                prefix = None

            # next layer
            folderMsg = {'dir': prefix, 'pages': 1, 'counts': BROWSE_VIDEO_COUNT}
            whichLayer = self.currentStatus[currentView]['layerStack'] + 1

        layer = 'layer{}'.format(whichLayer)

        if whichLayer > 1:
            folderMsg.update({'sortBy': self.currentStatus['Folder']['sortBy'], 'orderBy': self.currentStatus['Folder']['orderBy']})

        if layerName in ('home', ):
            folderMsg['home'] = 1
            folderMsg['dir'] = None
        elif layerName in ('.Qsync', ):
            folderMsg['home'] = 2
            folderMsg['dir'] = None

        resp = VideoStationAPI().getFolderItems(folderMsg)
        if not resp.get('datas'):
            g.setHomeProperty('browse.Folder.totalItem', 'zero')
            self.currentStatus[currentView][layer] = {'page': 0, 'items': list(), 'totalItem': 0,
                                                      'totalPage': 0, 'lastFocus': 0, 'layerName': layerName}
            self.currentStatus[currentView]['layerStack'] = whichLayer
            g.saveCurrentStatus(currentView, self.currentStatus, layer=layer)

            self._folderPath()
            self._initFolderPanel()
            return

        folders = resp.get('datas')
        for folderItem in folders:
            propertyContainer = dict()
            folder = folderItem['FileItem']

            propertyContainer['title'] = folder.get('cPictureTitle')

            propertyContainer['id'] = folder.get('id')
            propertyContainer['MediaType'] = folder.get('MediaType')
            propertyContainer['prefix'] = g.ensureUnicode(folder.get('prefix'))
            propertyContainer['isMediafolder'] = folder.get('isMediafolder')

            if folder['MediaType'] in ('folder', ):
                propertyContainer['thumbnail'] = 'icon_folder.png'
            else:
                propertyContainer['thumbnail'] = g.getImageLocalPath('median', folder.get('id'), folder.get('PosterPath'))
                propertyContainer['filename'] = g.ensureUnicode(folder.get('cFilename'))

                if not folder.get('rating') or folder.get('rating') in ('0', ):
                    rating = '0'
                else:
                    rating = str(int(folder.get('rating')) / 20)
                propertyContainer['ratingInfo'] = rating

                resp_showTime = g.showTime(g.timeTransfer(eval(folder.get('Duration'))))
                propertyContainer['length'] = resp_showTime if resp_showTime else '0'
                propertyContainer['duration'] = folder.get('Duration')
                propertyContainer['videoinfomask'] = folder.get('mask')
                propertyContainer['colorLevelInfo'] = folder.get('ColorLevel')
                propertyContainer['tagInfo'] = folder.get('keywords')
                propertyContainer['filesizeInfo'] = g.countFileSize(folder.get('iFileSize'))
                propertyContainer['dimensionsInfo'] = folder.get('Dimensions')
                propertyContainer['videocodec'] = folder.get('vcodec')
                propertyContainer['audiocodec'] = folder.get('acodec')
                propertyContainer['typeInfo'] = folder.get('mime')
                propertyContainer['pathInfo'] = '{0}{1}'.format(g.ensureUTF8(folder.get('prefix')), g.ensureUTF8(folder.get('cFilename')))
                propertyContainer['description'] = folder.get('extOutline')

            listitems.append(g.settingProperty(propertyContainer, 'folder'))

        if action in ('paging', ):
            self.currentStatus[currentView][layer]['items'] += listitems
            self.currentStatus[currentView][layer]['page'] += 1
            g.saveCurrentStatus(currentView, self.currentStatus, ['items', 'page'], layer=layer)
        elif action in ('sorting', ):
            totalPage = g.paginateInfo(BROWSE_VIDEO_COUNT, resp.get('counts'))
            self.currentStatus[currentView][layer] = {'page': 1, 'items': listitems, 'totalItem': resp.get('counts'), 'totalPage': totalPage, 'lastFocus': 0, 'layerName': self.currentStatus[currentView][layer]['layerName']}
            g.saveCurrentStatus(currentView, self.currentStatus, layer=layer)
            g.setSort('Folder', self.currentStatus['Folder']['sortBy'], self.currentStatus['Folder']['orderBy'])
        else:
            totalPage = g.paginateInfo(BROWSE_VIDEO_COUNT, resp.get('counts'))
            self.currentStatus[currentView][layer] = {'page': 1, 'items': listitems, 'totalItem': resp.get('counts'), 'totalPage': totalPage, 'lastFocus': 0,
                                                      'layerName': 'Folder' if whichLayer in (1, ) else layerName}
            self.currentStatus[currentView]['layerStack'] = whichLayer
            if layerName not in ('home', '.Qsync', ):
                self.currentStatus[currentView]['currentPrefix'] = prefix
            else:
                self.currentStatus[currentView]['currentPrefix'] = None
            g.saveCurrentStatus(currentView, self.currentStatus, layer=layer)

    def _adjustFolderCurrentPrefix(self):
        getPrefix = self.currentStatus['Folder']['currentPrefix']
        if not getPrefix:
            return

        splitPrefix = getPrefix.split('/')
        splitPrefix.pop()
        splitPrefix.pop()

        if not splitPrefix:
            self.currentStatus['Folder']['currentPrefix'] = None
            return

        setPrefix = '/'.join(splitPrefix)
        self.currentStatus['Folder']['currentPrefix'] = setPrefix + '/'

    def _adjustFolderPath(self, c_view, w_layer):
        g.setHomeProperty('Browse.Path.1', 'Folder')
        g.setHomeProperty('Browse.Path.2', '...')
        for idx, level in enumerate(range(6, 2, -1)):
            layer = 'layer{}'.format(w_layer - idx)
            layerName = self.currentStatus[c_view][layer]['layerName']
            g.setHomeProperty('Browse.Path.{}'.format(level), layerName)

    def _folderPath(self):
        currentView = g.getHomeProperty('Browse.CurrentView')
        whichLayer = self.currentStatus[currentView]['layerStack']

        if whichLayer < LAYER7:
            for idx in range(FOLDER_LAYER_COUNT):
                layer = 'layer{}'.format(idx + 1)
                if self.currentStatus[currentView].get(layer):
                    g.setHomeProperty('Browse.Path.{}'.format(idx + 1), self.currentStatus[currentView][layer]['layerName'])
                else:
                    g.clearHomeProperty('Browse.Path.{}'.format(idx + 1))

            xbmc.sleep(100)
            self.setFocusId(ID.val('Folder.Layer{}.Button'.format(whichLayer)))
        else:
            self._adjustFolderPath(currentView, whichLayer)

            xbmc.sleep(100)
            self.setFocusId(ID.val('Folder.Layer6.Button'))

    def _initFolderPanel(self):
        currentView = g.getHomeProperty('Browse.CurrentView')
        panel = self.getControl(ID.val('Browse.Folder.Panel'))
        panel.reset()
        layer = 'layer{}'.format(self.currentStatus[currentView]['layerStack'])
        panel.addItems(items=self.currentStatus[currentView][layer]['items'])

        if str(self.currentStatus[currentView][layer]['totalItem']) in ('0', ):
            g.setHomeProperty('Browse.ShowEmptyMessage', 'true')
        else:
            g.clearHomeProperty('Browse.ShowEmptyMessage')

    def _handlePreviousFolder(self):
        currentView = g.getHomeProperty('Browse.CurrentView')

        if not (self.currentStatus[currentView]['layerStack'] - 1):
            g.initCurrentStatus(currentView, self.currentStatus[currentView])
            self.close()
            return

        delLayer = 'layer{}'.format(self.currentStatus['Folder']['layerStack'])
        del self.currentStatus['Folder'][delLayer]

        self.currentStatus[currentView]['layerStack'] -= 1
        self._adjustFolderCurrentPrefix()
        self._folderPath()
        self._reloadItem()
        self._refreshFocus()

        g.initCurrentStatus(currentView, self.currentStatus[currentView])

    def _initSubtype(self):
        count = 1

        for idx in range(GLOBAL_TOTAL_CUSTOM_SUBTYPE):
            g.clearHomeProperty('Browse.Classification.Other{}'.format(idx + 1))

        resp = self._getBgData('classify.subtype')
        if not resp:
            return None

        subtypeAmount = len(resp['classificationMapping'].keys())
        if subtypeAmount > BUILTIN_BUTTON:  # builtinButton has 6
            otherButtonId = sorted(map(int, resp['classificationMapping'].keys()))[6:]

        for subtype in range(subtypeAmount):
            if subtype > BUILTIN_BUTTON_AMOUNT:
                subtypeName = 'Other{}'.format(count)
                subtypeName_t = resp['classificationMapping'][str(otherButtonId[0])]['subtypeName']
                subtypeFormat = '[COLOR $VAR[Browse.Classification.Other{0}.TextColor]]{1}[/COLOR]'.format(count, subtypeName_t)
                self.getControl(ID.val('Browse.Classification.{}.Button'.format(subtypeName))).setLabel(label=subtypeFormat, focusedColor='0xFFFFFFFF')
                g.setHomeProperty('Browse.Classification.{}'.format(subtypeName), subtypeName_t)

                otherButtonId.pop(0)
                count += 1
            else:
                subtypeName = self.builtinButton[subtype]['ButtonName']
                subtypeFormat = '[COLOR $VAR[Browse.Classification.{0}.TextColor]]{1}[/COLOR]'.format(subtypeName, g.ensureUTF8(self.builtinButton[subtype]['lang']))
                self.getControl(ID.val('Browse.Classification.{}.Button'.format(subtypeName))).setLabel(label=subtypeFormat, focusedColor='0xFFFFFFFF')

    def _initPanel(self):
        if not g.getHomeProperty('Browse.Video.Loading'):
            g.setHomeProperty('Browse.Video.Loading', 'true')

        currentView = g.getHomeProperty('Browse.CurrentView')
        if g.getViewType(currentView) in ('Classification', ):
            panel = self.getControl(ID.val('Browse.Poster.Panel')) if currentView in ('Movie', 'TvShow', ) else self.getControl(ID.val('Browse.Thumbnail.Panel'))
            items = self.currentStatus[currentView]['items']
            total = self.currentStatus[currentView]['totalItem']
        else:
            if g.getViewType(currentView) in ('Collection', ):
                panel = self.getControl(ID.val('Browse.Collection.Panel'))
                items = self.currentStatus[currentView]['items']
                total = self.currentStatus[currentView]['totalItem']
            elif g.getViewType(currentView) in ('CollectionInfo', ):
                panel = self.getControl(ID.val('Browse.Thumbnail.Panel'))
                albumId = self.currentStatus[currentView]['currentAlbumId']

                items = self.currentStatus[currentView][albumId]['items']
                total = self.currentStatus[currentView][albumId]['totalItem']
            else:
                panel = self.getControl(ID.val('Browse.Thumbnail.Panel'))
                items = self.currentStatus[currentView]['items']
                total = self.currentStatus[currentView]['totalItem']

        panel.reset()
        panel.addItems(items=items)

        g.clearHomeProperty('Browse.Video.Loading')
        if str(total) in ('0', ):
            g.setHomeProperty('Browse.ShowEmptyMessage', 'true')
        else:
            g.clearHomeProperty('Browse.ShowEmptyMessage')

    def _updatePanel(self):
        self._initPanel()

        currentView = g.getHomeProperty('Browse.CurrentView')
        if g.getViewType(currentView) in ('Classification', ):
            self._updateTotalCount('1', self.currentStatus[currentView]['totalItem'])
        elif g.getViewType(currentView) in ('CollectionInfo', ):
            albumId = self.currentStatus[currentView]['currentAlbumId']
            self._updateTotalCount('1', self.currentStatus[currentView][albumId]['totalItem'])

    def _storageLocalData(self, which=None, action=None):
        currentView = which if which else g.getHomeProperty('Browse.CurrentView')

        if g.getViewType(currentView) in ('Classification', ):
            taskName = 'browse.classify.{}'.format(self.currentStatus[currentView]['subtypeId'])
        else:
            taskName = 'browse.{}'.format(currentView)

            if g.getViewType(currentView) in ('CollectionInfo', ):
                albumId = self.currentStatus[currentView]['currentAlbumId']
                taskName = '{0}.{1}'.format(taskName, albumId)

        resp = self._getBgData(taskName)
        items, total = (list(), None) if not resp else (resp.get('items'), resp.get('total'))

        # Fixed recently/history total counts
        if currentView in ('RecentlyImported', 'RecentlyWatched', ):
            if len(items) > BROWSE_STATIC_COUNT:
                total = BROWSE_STATIC_COUNT
            else:
                total = len(items)

        if not total or not items:
            propertyName = '{}.totalItem'.format(taskName)
            g.setHomeProperty(propertyName, 'zero')

            if action:
                self.currentStatus[currentView]['items'] = items
                self.currentStatus[currentView]['totalItem'] = 0

                g.saveCurrentStatus(currentView, self.currentStatus)

            if g.getViewType(currentView) in ('CollectionInfo', ):
                g().get('bgTask').clear_task_result(taskName)

            return None

        if g.getViewType(currentView) in ('CollectionInfo', ):
            if action:
                self.currentStatus[currentView][albumId]['items'] = items
                self.currentStatus[currentView][albumId]['page'] = 1
                self.currentStatus[currentView][albumId]['lastFocus'] = 0
            else:
                self.currentStatus[currentView][albumId]['items'] += items

            self.currentStatus[currentView][albumId]['totalItem'] = total if total else 0

            g.saveCurrentStatus(currentView, self.currentStatus, albumId=albumId)

            return

        if action:
            self.currentStatus[currentView]['items'] = items
            self.currentStatus[currentView]['page'] = 1
            self.currentStatus[currentView]['lastFocus'] = 0
        else:
            self.currentStatus[currentView]['items'] += items

        self.currentStatus[currentView]['totalItem'] = total if total else 0

        g.saveCurrentStatus(currentView, self.currentStatus)

    def _updateTotalCount(self, current, total):
        itemLabel = self.getControl(ID.val('Browse.Item.Label'))
        if total in (0, '0', ):
            itemLabel.setVisible(False)
        else:
            itemLabel.setVisible(True)
            itemLabel.setLabel('{0} / {1}'.format(current, total))

    def _updateFocusPosition(self):
        currentView = g.getHomeProperty('Browse.CurrentView')

        if self.getFocusId() not in (ID.val('Browse.Poster.Panel'), ID.val('Browse.Thumbnail.Panel'), ID.val('Browse.Collection.Panel'), ID.val('Browse.Folder.Panel'), ):
            return

        try:
            browsePos = self.getControl(self.getFocusId()).getSelectedPosition()
            if self.currentPosIdx != browsePos:
                self.currentPosIdx = browsePos
            else:
                return
        except:
            return

        if currentView in ('Folder', ):
            layer = 'layer{}'.format(self.currentStatus[currentView]['layerStack'])
            total = self.currentStatus[currentView][layer]['totalItem']

            self.currentStatus[currentView][layer]['lastFocus'] = browsePos
            g.saveCurrentStatus(currentView, self.currentStatus, 'lastFocus', layer)
        else:
            if g.getViewType(currentView) in ('CollectionInfo', ):
                albumId = self.currentStatus[currentView]['currentAlbumId']
                total = self.currentStatus[currentView][albumId]['totalItem']
                self.currentStatus[currentView][albumId]['lastFocus'] = browsePos
                g.saveCurrentStatus(currentView, self.currentStatus, 'lastFocus', albumId)
            else:
                total = self.currentStatus[currentView]['totalItem']
                self.currentStatus[currentView]['lastFocus'] = browsePos
                g.saveCurrentStatus(currentView, self.currentStatus, 'lastFocus')

        # Fixed panel has empty listitem focus issue.
        if browsePos + 1 > int(total):
            return

        self._updateTotalCount(browsePos + 1, total)

        if int(total) <= BROWSE_VIDEO_COUNT:
            return
        self._paging()

    def _adjustFolderPrefix(self, prefix):
        adjustedPrefix = prefix.split('/')
        adjustedPrefix.pop()
        adjustedPrefix.pop()
        return '/'.join(adjustedPrefix) + '/'

    def _paging(self):
        currentView = g.getHomeProperty('Browse.CurrentView')
        browsePos = self.getControl(self.getFocusId()).getSelectedPosition()

        if currentView in ('Folder', ):
            layer = 'layer{}'.format(self.currentStatus[currentView]['layerStack'])
            total = self.currentStatus[currentView][layer]['totalItem']
        else:
            if g.getViewType(currentView) in ('CollectionInfo', ):
                albumId = self.currentStatus[currentView]['currentAlbumId']
                total = self.currentStatus[currentView][albumId]['totalItem']
            else:
                total = self.currentStatus[currentView]['totalItem']

        panelSize = self.getControl(self.getFocusId()).size()

        if browsePos in ((panelSize - 1), (panelSize - 2), ) and panelSize < int(total):
            # self.pagingStatus = True

            if currentView in ('Folder', ):
                folderPanel = self.getControl(ID.val('Browse.Folder.Panel'))

                folderType = folderPanel.getSelectedItem().getProperty('folder.type')
                prefix = folderPanel.getSelectedItem().getProperty('prefix')

                if folderType in ('folder', ):
                    prefix = self._adjustFolderPrefix(prefix)

                self._loadFolderData('paging', prefix, page=self.currentStatus[currentView][layer]['page'] + 1)
                self._initFolderPanel()
                self.getControl(ID.val('Browse.Folder.Panel')).selectItem(browsePos)
                return

            # paging
            self._storageLocalData()
            self._updatePanel()

            # focusing paging point
            self.getControl(self.getFocusId()).selectItem(browsePos)

            # preparing next page for the video type
            if g.getViewType(currentView) in ('CollectionInfo', ):
                self.currentStatus[currentView][albumId]['page'] += 1
                g.saveCurrentStatus(currentView, self.currentStatus, 'page', albumId=albumId)
            else:
                self.currentStatus[currentView]['page'] += 1
                g.saveCurrentStatus(currentView, self.currentStatus, 'page')

            self._addBgTask()

            # self.pagingStatus = False

    def _addBgTask(self, which=None, action=None):
        currentView = which if which else g.getHomeProperty('Browse.CurrentView')

        if action:
            paging = 0
        else:
            if g.getViewType(currentView) in ('CollectionInfo', ):
                albumId = self.currentStatus[currentView]['currentAlbumId']
                paging = self.currentStatus[currentView][albumId]['page']
            else:
                paging = self.currentStatus[currentView]['page']

        if g.getViewType(currentView) in ('Classification', ):
            subtypeId = self.currentStatus[currentView]['subtypeId']
            taskName = 'browse.classify.{}'.format(subtypeId)
            payload = {'subtypeId': subtypeId, 'videoType': subtypeId, 'pages': paging + 1, 'counts': BROWSE_VIDEO_COUNT,
                       'sortBy': self.currentStatus[currentView]['sortBy'], 'orderBy': self.currentStatus[currentView]['orderBy']}
            if currentView in ('Movie', 'TvShow', ):
                payload.update({'genre': self.currentStatus[currentView]['genre'], 'year': self.currentStatus[currentView]['year']})
            handler = self.bgTaskName['Classify']
        else:
            taskName = 'browse.{}'.format(currentView)
            payload = {'pages': paging + 1, 'counts': BROWSE_VIDEO_COUNT}

            if currentView in ('VideoCollection', 'SmartCollection', ):
                payload.update({'albumType': self.otherVideoType[currentView]['albumType']})

            if currentView in ('RecentlyWatched', ):
                payload.update({'view': self.otherVideoType[currentView]['view']})

            if currentView not in ('RecentlyWatched', 'RecentlyImported', ):
                if g.getViewType(currentView) in ('CollectionInfo', ):
                    albumId = self.currentStatus[currentView]['currentAlbumId']
                    taskName = '{0}.{1}'.format(taskName, albumId)
                    payload.update({'albumId': albumId})
                    payload.update({'sortBy': self.currentStatus[currentView][albumId]['sortBy']})
                    payload.update({'orderBy': self.currentStatus[currentView][albumId]['orderBy']})
                else:
                    payload.update({'sortBy': self.currentStatus[currentView]['sortBy']})
                    payload.update({'orderBy': self.currentStatus[currentView]['orderBy']})

            handler = self.bgTaskName[currentView]

        g().get('bgTask').add_task(taskName, handler, payload)

    def _getBgData(self, taskName):
        while g().get('bgTask').get_task_result(taskName) in ('init', ):
            xbmc.sleep(100)
        resp = g().get('bgTask').get_task_result(taskName)
        if not resp:
            return None

        return resp

    def _clearFilterStatus(self, which=None):
        g.saveFilterStatus(which, 'year', list())
        g.saveFilterStatus(which, 'genre', list())
        g.clearHomeProperty('Browse.{}.Filter'.format(which))

    def _preClearEnv(self):
        # Show loading image.
        g.setHomeProperty('Browse.Video.Loading', 'true')

        # Reset empty message.
        g.clearHomeProperty('Browse.ShowEmptyMessage')

        if g.getHomeProperty('Browse.CurrentView') in ('Movie', 'TvShow', ):
            self.getControl(ID.val('Browse.Poster.Panel')).reset()
        else:
            self.getControl(ID.val('Browse.Thumbnail.Panel')).reset()

    def _setCurrentView(self):
        viewType = ID.key(self.getFocusId())
        if not viewType:
            return

        currentView = viewType.split('.')[2]
        g.setHomeProperty('Browse.CurrentView', currentView)

    def onAction(self, action):
        """Action function."""
        if not self.getFocusId() and action not in ACTION.groupID('MOUSE_'):
            self._refreshFocus('noFocus')
            return

        if action in (ACTION.val('INFO'), ACTION.val('MOUSE_WHEEL_CLICK'), ):
            if g.getHomeProperty('Browse.CurrentView') in ('TvShow', ) or self.getFocusId() not in (ID.val('Browse.Poster.Panel'), ID.val('Browse.Thumbnail.Panel'), ID.val('Browse.Folder.Panel')):
                return

            if self.getFocusId() in (ID.val('Browse.Folder.Panel'), ):
                select = self.getControl(ID.val('Browse.Folder.Panel')).getSelectedItem()
                if select.getProperty('folder.type') in ('folder', ):
                    return

            w = VideoInfoHandler('win_videoinfo.xml', __addonpath__, "Default", selectItem=[self.getControl(self.getFocusId()).getSelectedItem()])
            w.doModal()
            del w

        if action in (ACTION.val('LEFT'), ACTION.val('RIGHT'), ACTION.val('UP'), ACTION.val('DOWN'), ACTION.val('MOUSE_MOVE'), ):
            if g.getViewType(g.getHomeProperty('Browse.CurrentView')) in ('Classification', ):
                if action in (ACTION.val('LEFT'), ACTION.val('RIGHT'), ):
                    if self.getFocusId() in ID.groupID('Browse.Classification.'):
                        self._setCurrentView()
                        self._preClearEnv()
                        self._reloadItem()
                        self._updatePanel()
                        return

            self._updateFocusPosition()

        if action in (ACTION.val('MOUSE_LEFT_CLICK'), ):
            if self.getFocusId() not in (
                    ID.val('Browse.More.Button'), ID.val('Browse.More.Refresh.Button'),
                    ID.val('Browse.More.Sorting.Button'), ID.val('Browse.More.Filter.Button')):

                g.clearHomeProperty('Browse.ShowMore')
                self.setFocusId(ID.val('Browse.More.Button'))
                return

        if action in (ACTION.val('PREVIOUS_MENU'), ACTION.val('BACK'), ACTION.val('MOUSE_RIGHT_CLICK'), ):
            if g.getViewType(g.getHomeProperty('Browse.CurrentView')) in ('CollectionInfo', ):
                view = g.getHomeProperty('Browse.CurrentView')
                collectionType = view.split('Collection')[0]
                g.setHomeProperty('Browse.CurrentView', '{}Collection'.format(collectionType))
                self._reloadItem()
                self._updatePanel()
                self._refreshFocus()
                return

            if g.getHomeProperty('Browse.ShowMore'):
                g.clearHomeProperty('Browse.ShowMore')
                self.setFocusId(ID.val('Browse.More.Button'))
                return

            if g.getHomeProperty('Browse.CurrentView') in ('Folder', ):
                '''avoid onAction again'''
                self.avoidOnactionAgain += 1
                if self.avoidOnactionAgain > 1:
                    self.avoidOnactionAgain = 0
                    return

                self._handlePreviousFolder()

                '''avoid onAction again'''
                self.avoidOnactionAgain = 0
                return

            self.close()

    def onClick(self, controlID):
        """Click trigger function."""
        if controlID in (ID.val('Browse.Exit.Button'), ):
            leave = g.showDialog('yesno', {'line1': __language__(62002)}, {'yes': __language__(60073), 'no': __language__(60072)})
            '''leave = 0(no/back action.), leave = 1(yes)'''
            if not leave:
                return

            g.setWaitingMask(self, state='on')
            g.stopVideoHD()
            return

        if controlID in (ID.val('Browse.Home.Button'), ):
            currentView = g.getHomeProperty('Browse.CurrentView')
            if currentView in ('Folder', ):
                g.initCurrentStatus('Folder', {'layer1': dict(), 'layerStack': 1, 'currentPrefix': None,
                                               'sortBy': self.currentStatus[currentView].get('sortBy'),
                                               'orderBy': self.currentStatus[currentView].get('orderBy')})

            self.close()
            return

        if self.getFocusId() in ID.groupID('Browse.Classification.'):
            self._setCurrentView()
            currentView = g.getHomeProperty('Browse.CurrentView')

            self._preClearEnv()

            self._reloadItem()
            self._updatePanel()
            self._refreshFocus()

            return

        if controlID in (ID.val('Browse.ResetFilterStatus.Button'), ):
            currentView = g.getHomeProperty('Browse.CurrentView')

            self.currentStatus[currentView]['year'] = None
            self.currentStatus[currentView]['genre'] = None

            self._refreshVideo()
            self._updatePanel()
            self._refreshFocus()

            g.clearHomeProperty('update.state')

            self._clearFilterStatus(currentView)

        if controlID in (ID.val('Browse.Poster.Panel'), ):
            currentView = g.getHomeProperty('Browse.CurrentView')
            if currentView in ('Movie', ):
                select = self.getControl(controlID).getSelectedPosition()
                w = MovieInfoHandler('win_movieinfo.xml', __addonpath__, "Default", selectItem=select)
                w.doModal()
                del w

                self.currentStatus['Movie'] = g.getCurrentStatus('Movie')
            else:
                select = self.getControl(controlID).getSelectedItem()
                w = TVShowInfoHandler('win_tvshowinfo.xml', __addonpath__, "Default", selectItem=select)
                w.doModal()
                del w

            self._updatePanel()
            self._refreshFocus()

        if controlID in (ID.val('Browse.Thumbnail.Panel'), ):
            if g.getViewType(g.getHomeProperty('Browse.CurrentView')) in ('CollectionInfo', ):
                albumTitle = self.getControl(ID.val('Browse.Collection.Panel')).getSelectedItem().getProperty('albumTitle')
                g().set('CollectionInfoTitle', albumTitle)

            thumbnailPanel = self.getControl(ID.val('Browse.Thumbnail.Panel'))
            g().get('player').play(listitem=[thumbnailPanel.getSelectedItem()])

        if controlID in (ID.val('Browse.Collection.Panel'), ):
            self.getControl(ID.val('Browse.Thumbnail.Panel')).reset()
            albumId = self.getControl(ID.val('Browse.Collection.Panel')).getSelectedItem().getProperty('albumId')
            albumTitle = self.getControl(ID.val('Browse.Collection.Panel')).getSelectedItem().getProperty('albumTitle')
            currentView = g.getHomeProperty('Browse.CurrentView')
            collectVideo = '{}Videos'.format(currentView)
            collectTitle = '{}Title'.format(currentView)

            g.setHomeProperty('Browse.CurrentView', collectVideo)
            g.setHomeProperty('Browse.{}'.format(collectTitle), albumTitle)

            if not self.currentStatus[collectVideo].get(albumId):
                sort_order = g.getSort(collectVideo)
                collectData = {'page': 1, 'items': list(), 'totalItem': 0, 'lastFocus': 0,
                               'sortBy': sort_order['sortBy'], 'orderBy': sort_order['orderBy']}
                self.currentStatus[collectVideo].update({albumId: collectData})
                self.currentStatus[collectVideo].update({'currentAlbumId': albumId})

                g.setWaitingMask(self, state='on')
                g().get('bgTask').clear_task_result('browse.{0}.{1}'.format(collectVideo, albumId))
                self._addBgTask(action='init')
                self._storageLocalData()
                self._updatePanel()
                g.setWaitingMask(self, state='off')

                self._refreshFocus()

                self._addBgTask()
            else:
                self.currentStatus[collectVideo]['currentAlbumId'] = albumId

                self._updatePanel()
                self._refreshFocus()

        if controlID in (ID.val('Browse.More.Button'), ):
            g.setHomeProperty('Browse.ShowMore', 'show')

            if g.getHomeProperty('Browse.CurrentView') in ('Folder', ):
                g.setHomeProperty('Browse.Folder.Layer', str(self.currentStatus['Folder']['layerStack']))

            self.setFocusId(ID.val('Browse.More.Refresh.Button'))

        if controlID in (
                ID.val('Browse.More.Refresh.Button'), ID.val('Browse.More.Sorting.Button'), ID.val('Browse.More.Filter.Button')):

                if controlID in (ID.val('Browse.More.Refresh.Button'), ):
                    g.setWaitingMask(self, state='on')
                    self._initSubtype()
                    self._refreshVideo()
                    if g.getHomeProperty('Browse.CurrentView') not in ('Folder', ):
                        self._updatePanel()
                    g.setWaitingMask(self, state='off')
                    self._refreshFocus()

                g.clearHomeProperty('Browse.ShowMore')
                self.setFocusId(ID.val('Browse.More.Button'))

        if controlID in (ID.val('Browse.PreviousFolder.Button'), ):
            self._handlePreviousFolder()
            return

        if controlID in ID.groupID('Folder.Layer'):
            currentView = g.getHomeProperty('Browse.CurrentView')

            if controlID in (ID.val('Folder.Layer6.Button'), ):
                return

            if controlID in (ID.val('Folder.Layer1.Button'), ):
                for idx in range(2, self.currentStatus['Folder']['layerStack'] + 1):
                    delLayer = 'layer{}'.format(idx)
                    del self.currentStatus['Folder'][delLayer]

                self.currentStatus['Folder']['currentPrefix'] = None
                self.currentStatus['Folder']['layerStack'] = 1

                self._folderPath()
                self._reloadItem()

                g.initCurrentStatus(currentView, self.currentStatus[currentView])
                return

            layerStackOrig = self.currentStatus['Folder']['layerStack']
            splitPrefix = self.currentStatus['Folder']['currentPrefix'].split(g.ensureUTF8(self.getControl(controlID).getLabel()))[0]
            self.currentStatus['Folder']['currentPrefix'] = '{0}{1}/'.format(splitPrefix, g.ensureUTF8(self.getControl(controlID).getLabel()))
            self.currentStatus['Folder']['layerStack'] = len(self.currentStatus['Folder']['currentPrefix'].split('/'))

            if layerStackOrig > self.currentStatus['Folder']['layerStack']:
                for idx in range(layerStackOrig - self.currentStatus['Folder']['layerStack']):
                    delLayer = 'layer{}'.format(self.currentStatus['Folder']['layerStack'] + idx + 1)
                    del self.currentStatus['Folder'][delLayer]

            self._folderPath()
            self._reloadItem()

            g.initCurrentStatus(currentView, self.currentStatus[currentView])
            return

        if controlID in (ID.val('Browse.Folder.Panel'), ):
            item = self.getControl(ID.val('Browse.Folder.Panel')).getSelectedItem()

            if item.getProperty('folder.type') in ('folder', ):
                self._loadFolderData(prefix=item.getProperty('prefix'), layerName=item.getLabel())
                self._folderPath()
                self._initFolderPanel()
                self._refreshFocus()
            else:
                folderPanel = self.getControl(ID.val('Browse.Folder.Panel'))
                g().get('player').play(listitem=[folderPanel.getSelectedItem()])
                return

        if controlID in (ID.val('Browse.Sidemenu.Button'), ):
            w = SidemenuDialog('dlg_sidemenu.xml', __addonpath__, "Default")
            w.doModal()
            del w

            if g.getViewType(g.getHomeProperty('Browse.CurrentView')) in ('Classification', ):
                self._initSubtype()

            self._reloadItem()

            if g.getHomeProperty('Browse.CurrentView') not in ('Folder', ):
                self._updatePanel()

            self._refreshFocus()

        if controlID in (ID.val('Browse.More.Sorting.Button'), ):
            # State machine start here
            '''
            liveCheck = Thread(target=self._checkDataUpdate, args=('sorting', ))
            liveCheck.start()
            '''
            g.saveThread(Thread(target=self._checkDataUpdate, args=('sorting', )))

            w = SortingDialog('dlg_sorting.xml', __addonpath__, "Default")
            w.doModal()
            self.refreshClick = w.sortingClick
            updateVideoHDFile = w.updateVideoHDFile
            del w

            if updateVideoHDFile.get('items'):
                self._updateVideoHDFile(updateVideoHDFile)

            '''liveCheck.join()'''
            print 'finish'

        if controlID in (ID.val('Browse.More.Filter.Button'), ):
            # State machine start here
            '''
            liveCheck = Thread(target=self._checkDataUpdate, args=('filter', ))
            liveCheck.start()
            '''
            g.saveThread(Thread(target=self._checkDataUpdate, args=('filter', )))

            w = FilterDialog('dlg_filter.xml', __addonpath__, "Default")
            w.doModal()
            # self.refreshClick = w.filterClick
            del w

            '''liveCheck.join()'''
            print 'finish'

    def _checkDataUpdate(self, checkType):
        print 'start'
        while (not xbmc.abortRequested):
            print 'waiting ...'
            if g().get('BreakThread'):
                break

            if g.getHomeProperty('update.state') in ('update', ):
                g.setHomeProperty('update.state', 'updating')
                print 'update ...'

                # Update current sorting/filter method.
                if checkType in ('filter', ):
                    updateFrom = g.getHomeProperty('Browse.CurrentView')
                    self.currentStatus[updateFrom]['year'] = g.getCurrentStatus(updateFrom, 'year')
                    self.currentStatus[updateFrom]['genre'] = g.getCurrentStatus(updateFrom, 'genre')

                    self._refreshVideo()
                    self._updatePanel()

                    if self.currentStatus[updateFrom]['year'] or self.currentStatus[updateFrom]['genre']:
                        g.setHomeProperty('Browse.{}.Filter'.format(updateFrom), 'true')

                    if not self.currentStatus[updateFrom]['year'] and not self.currentStatus[updateFrom]['genre']:
                        # g.clearHomeProperty('Browse.{}.Filter'.format(updateFrom))
                        self._clearFilterStatus(updateFrom)

                    self._refreshFocus('filter')
                elif checkType in ('sorting', ):
                    self._refreshVideo()
                    if g.getHomeProperty('Browse.CurrentView') not in ('Folder', ):
                        self._updatePanel()

                g.clearHomeProperty('update.state')
            elif g.getHomeProperty('update.state') in ('exit', ):
                g.clearHomeProperty('update.state')

                if self.refreshClick:
                    '''
                    self.currentStatus = g.getCurrentStatus()

                    if checkType in ('filter', ):
                        pass
                    elif checkType in('sorting', ):
                    '''
                    self.currentStatus = g.getCurrentStatus()

                    if g.getViewType(g.getHomeProperty('Browse.CurrentView')) in ('CollectionInfo', ):
                        updateFrom = g.getHomeProperty('Browse.CurrentView')
                        albumId = self.currentStatus[updateFrom]['currentAlbumId']
                        self.updateCollection = {'sortBy': self.currentStatus[updateFrom][albumId]['sortBy'],
                                                 'orderBy': self.currentStatus[updateFrom][albumId]['orderBy'],
                                                 'updateFrom': updateFrom}

                    self.refreshClick = False

                break

            xbmc.sleep(300)

    def close(self):
        g.clearHomeProperty('Browse.CurrentView')
        g.clearHomeProperty('Browse.ShowEmptyMessage')

        g().get('bgTask').clear_keywords_task_result('browse.')

        if self.updateCollection:
            updateKey = self.updateCollection['updateFrom'].split('Collection')[0]
            updateTarget = '{}Collection'.format(updateKey)
            sortBy = self.updateCollection['sortBy']
            orderBy = self.updateCollection['orderBy']

            updateData = {updateTarget: {'sortBy': sortBy, 'orderBy': orderBy, 'items': list()}}
            g.saveCurrentStatus(updateTarget, updateData, ['sortBy', 'orderBy', 'items'])
            g.setSort(updateTarget, sortBy, orderBy)

            self.updateCollection = dict()

        for clearItem in ['Movie', 'TvShow']:
            if g.getHomeProperty('Browse.{}.Filter'.format(clearItem)):
                clearContent = {clearItem: {'items': list(), 'year': None, 'genre': None}}
                g.saveCurrentStatus(clearItem, clearContent, ['genre', 'year', 'items'])

            self._clearFilterStatus(clearItem)

        super(browseHandler, self).close()
                                                                                                         
