# -*- coding: utf-8 -*-
"""VideoHD TV Show information page."""
import random

import xbmc
import xbmcgui
import xbmcaddon

from lib import g
from lib import ID, ACTION
from lib.static import *

from lib.core.dialog.description import DescriptionDialog
from lib.api.background import BackgroundHandler
from lib.api.videostation import VideoStationAPI
from lib.core.handler.videoinfo import VideoInfoHandler

__addon__ = xbmcaddon.Addon()
__language__ = __addon__.getLocalizedString
__addonpath__ = __addon__.getAddonInfo('path').decode('utf-8')


class TVShowInfoHandler(xbmcgui.WindowXML):

    """TV Show Information Handler."""

    def __init__(self, strXMLname, strFallbackPath, strDefaultName, forceFallback=0, selectItem=None):
        """Init function."""
        self.initOK = False

        self.selectItem = selectItem
        self.startPosition = 0
        self.whichSeason = None

    def onInit(self):
        """onInit function."""
        g.setWaitingMask(self, state='init')

        if not self.initOK:
            self.info = self.getControl(ID.val('TVShowInfo.Info.Fixedlist'))
            self.seasonlist = self.getControl(ID.val('TVShowInfo.Seasonlist.Fixedlist'))
            self.seasons = self.selectItem.getProperty('seasons').split(',')
            self.tvshowlist = self.getControl(ID.val('TVShowInfo.TVShowlist.Panel'))

            # For record current tvshow season data.
            self.currentSeason = -1
            self.seasonData = dict()

            self._loadTVShow()
            self._initSeasonList()
            self._setPlayButtonLabel()
            self._initTVShowInfo()
            self._playContinueItem()

            while not g.tvshowinfoBg():
                xbmc.sleep(100)

            self.selectItem.setArt({'thumb': random.choice(g.tvshowinfoBg())})
            g.tvshowinfoBg(action='clear')

            self.initOK = True
        else:
            if self.whichSeason:
                self.seasonlist.selectItem(self.seasons.index(self.whichSeason) + 1)
                self.whichSeason = None
            else:
                season = self.seasonlist.getSelectedItem().getProperty('season')
                self._updateTVShowInfoPanel(season)

                self._reloadContinueMsg()
                self._setPlayButtonLabel()

    def _reloadContinueMsg(self):
        resp = VideoStationAPI().getTVShows({'pages': 1, 'counts': 100})
        if not resp.get('videos'):
            return None

        for msg in resp.get('videos'):
            if msg['FileItem'].get('tv_id') in (self.selectItem.getProperty('id'), ):
                self.selectItem.setProperty('recently_play_id', msg['FileItem'].get('recently_play_id'))
                self.selectItem.setProperty('recently_play_progress', msg['FileItem'].get('recently_play_progress'))
                self.selectItem.setProperty('recently_play_season', msg['FileItem'].get('recently_play_season'))
                self.selectItem.setProperty('recently_play_season_order', msg['FileItem'].get('recently_play_season_order'))

                self.startPosition = self.startPosition = self._getVideoIdx(resp.get('items'), self.selectItem.getProperty('recently_play_id'))
                break

    def _setPlayButtonLabel(self):
        label = u'{} S{} E{}'.format(__language__(60032), self.selectItem.getProperty('recently_play_season'), self.selectItem.getProperty('recently_play_season_order'))
        self.getControl(ID.val('TVShowInfo.PlayButton.Label')).setLabel(label)

    def _initSeasonList(self):
        listitems = list()
        initItems = ['intro'] + self.seasons

        for season in initItems:
            if season in ('intro', ):
                seasonlist = xbmcgui.ListItem(__language__(60033))
                seasonlist.setProperty('type', 'intro')
            else:
                seasonlist = xbmcgui.ListItem(__language__(60030) % season)
                seasonlist.setProperty('season', season)  # season property by myself

            listitems.append(seasonlist)

        self.seasonlist.reset()
        self.seasonlist.addItems(items=listitems)

    def _initTVShowInfo(self):
        self.info.reset()
        self.info.addItems(items=[self.selectItem])

    def _loadTVShow(self):
        for season in self.seasons:
            g().get('bgTask').clear_task_result('tvshowinfo.season.{}'.format(season))
            g().get('bgTask').add_task('tvshowinfo.season.{}'.format(season), BackgroundHandler().tvshowinfoBackgroundData, {
                'tvId': self.selectItem.getProperty('id'), 'season': season, 'pages': 1})

    def _getVideoIdx(self, videos, videoId):
        defaultIdx = 0
        for idx, val in enumerate(videos):
            if val.getProperty('id') in (videoId, ):
                return idx

        return defaultIdx

    def _playContinueItem(self):
        resp = self._getBgData('tvshowinfo.season.{}'.format(self.selectItem.getProperty('recently_play_season')))
        if not resp:
            return None

        self.startPosition = self._getVideoIdx(resp.get('items'), self.selectItem.getProperty('recently_play_id'))

    def _paging(self, taskName):
        panelSize = self.tvshowlist.size()
        if panelSize < int(self.seasonData[taskName].get('total')):
            g().get('bgTask').clear_task_result(taskName)
            g().get('bgTask').add_task(taskName, BackgroundHandler().tvshowinfoBackgroundData, {
                'tvId': self.selectItem.getProperty('id'), 'season': self.currentSeason, 'pages': self.seasonData[taskName]['pages'] + 1})

    def _updateTVShowInfoPanel(self, season, paging=False):
        pos = self.tvshowlist.getSelectedPosition()
        taskName = 'tvshowinfo.season.{}'.format(season)
        self.currentSeason = int(season)

        if not self.seasonData.get(taskName):
            resp = self._getBgData(taskName)
            if not resp:
                return None

            self.seasonData[taskName] = resp

        if paging:
            resp = self._getBgData(taskName)
            if not resp:
                return None

            self.seasonData[taskName]['pages'] = resp.get('pages')
            self.seasonData[taskName]['items'] += resp.get('items')

        self.tvshowlist.reset()
        self.tvshowlist.addItems(items=self.seasonData[taskName].get('items'))

        self.tvshowlist.selectItem(pos)

        self._paging(taskName)

    def _getBgData(self, taskName):
        while g().get('bgTask').get_task_result(taskName) in ('init', ):
            xbmc.sleep(100)
        resp = g().get('bgTask').get_task_result(taskName)
        if not resp:
            return None

        return resp

    def onAction(self, action):
        """Action function."""
        if action in (ACTION.val('INFO'), ):
            self.whichSeason = self.seasonlist.getSelectedItem().getProperty('season')
            if self.seasonlist.getSelectedItem().getProperty('type') in ('intro', ) or self.getFocusId() in (ID.val('TVShowInfo.Seasonlist.Fixedlist'), ):
                return

            item = self.getControl(self.getFocusId()).getSelectedItem()
            w = VideoInfoHandler('win_videoinfo.xml', __addonpath__, "Default", selectItem=item)
            w.doModal()
            del w

        if action in (ACTION.val('LEFT'), ACTION.val('RIGHT'), ACTION.val('MOUSE_WHEEL_DOWN'), ACTION.val('MOUSE_WHEEL_UP'), ACTION.val('MOUSE_MOVE'), ):
            if self.getFocusId() in (ID.val('TVShowInfo.Seasonlist.Fixedlist'), ):
                season = self.seasonlist.getSelectedItem().getProperty('season')
                if season:
                    self._updateTVShowInfoPanel(season)
            elif self.getFocusId() in (ID.val('TVShowInfo.TVShowlist.Panel'), ):
                panelPos = self.tvshowlist.getSelectedPosition()
                panelSize = self.tvshowlist.size()
                taskName = 'tvshowinfo.season.{}'.format(self.currentSeason)

                if panelPos in ((panelSize - 1), (panelSize - 2), ) and panelSize < int(self.seasonData[taskName].get('total')):
                    self._updateTVShowInfoPanel(self.currentSeason, True)

        if action in (ACTION.val('PREVIOUS_MENU'), ACTION.val('BACK'), ):
            g.tvshowinfoBg(action='clear')
            self.close()

    def onClick(self, controlID):
        """Click trigger function."""
        if controlID in (ID.val('TVShowInfo.Back.Button'), ):
            g.tvshowinfoBg(action='clear')
            self.close()
            return

        if controlID in (ID.val('TVShowInfo.TVShowlist.Panel'), ):
            selectSeason = self.seasonlist.getSelectedItem().getProperty('season')
            startWith = self.tvshowlist.getSelectedPosition()

            resp = self._getBgData('tvshowinfo.season.{}'.format(selectSeason))
            if not resp:
                return None

            g().get('player').play(listitem=resp.get('items'), startpos=startWith)

        if controlID in (ID.val('TVShowInfo.Poster.Button'), ):
            resp = self._getBgData('tvshowinfo.season.{}'.format(self.selectItem.getProperty('recently_play_season')))
            if not resp:
                return None

            g().get('player').play(listitem=resp.get('items'), startpos=self.startPosition)

        if controlID in (ID.val('TVShowInfo.Description.Button'), ):
            w = DescriptionDialog('dlg_description.xml', __addonpath__, "Default", item=self.selectItem)
            w.doModal()
            del w
