# -*- coding: utf-8 -*-
"""VideoHD player control page."""
import xbmc
import xbmcgui
import xbmcaddon

from lib import g, ID, ACTION
from lib.core.dialog.bookmarks import BookmarksDialog
from lib.core.dialog.subtitles import SubtitlesDialog
from lib.api.videostation import VideoStationAPI

__addon__ = xbmcaddon.Addon()
__language__ = __addon__.getLocalizedString
__addonpath__ = __addon__.getAddonInfo('path').decode('utf-8')

class PlayerControlDialog(xbmcgui.WindowXMLDialog):

    """Player Control Handler."""

    def __init__(self, strXMLname, strFallbackPath, strDefaultName, forceFallback=0, select=None):
        """Init function."""
        self.select = select
        self.vplayer = g().get('player')

    def _loadPlaylist(self):
        self.getControl(ID.val('Playercontrol.Playlist.Fixedlist')).addItems(g().get('current.playlist'))

    def _genExitTitle(self):
        if g.getHomeProperty('Browse.CurrentView'):
            if g.getViewType(g.getHomeProperty('Browse.CurrentView')) in ('CollectionInfo', ):
                title = u'{0} : {1}'.format(g.ensureUnicode(g().get('CollectionInfoTitle')), g.ensureUnicode(self.vplayer.getCurrentPlayItem().getLabel()))
            else:
                title = u'{0} : {1}'.format(g.ensureUnicode(g.getCurrenViewLanguageMapping()), g.ensureUnicode(self.vplayer.getCurrentPlayItem().getLabel()))
        else:
            title = self.vplayer.getCurrentPlayItem().getLabel()

        return title

    def _checkBookmarks(self):
        videoId = self.vplayer.getCurrentPlayItem().getProperty('id')
        resp = VideoStationAPI().getBookmarks(videoId)
        if not resp.get('bookmarks'):
            self.getControl(ID.val('Playercontrol.Bookmarks.Button')).setVisible(False)
            return

        self.getControl(ID.val('Playercontrol.Bookmarks.Button')).setVisible(True)

    def onInit(self):
        """onInit function."""
        g.setWaitingMask(self, state='init')
        self.getControl(ID.val('Playercontrol.Exit.Label')).setLabel(self._genExitTitle())
        self._loadPlaylist()
        self._checkBookmarks()

        while (not xbmc.abortRequested):
            if g().get('BreakThread'):
                break

            if g.getHomeProperty('Player.NextNotify'):
                self.getControl(ID.val('Playercontrol.NextNotify.Count.Label')).setLabel(__language__(60026) % (g.getHomeProperty('Player.RemainTime')))

                if g.getHomeProperty('Player.ShowControl') in ('show', ):
                    self._controlPanelAction('hide')

            if g().get('UpdatePlayercontrolExitLabel'):
                self.getControl(ID.val('Playercontrol.Exit.Label')).setLabel(self._genExitTitle())
                g().set('UpdatePlayercontrolExitLabel', False)

            if self.vplayer.getState() in ('pause', ) and g().get('reloadPlaylist') and len(g().get('current.playlist')) > 1:
                g().set('reloadPlaylist', False)

                fixedlist = self.getControl(ID.val('Playercontrol.Playlist.Fixedlist'))
                fixedlist.reset()
                fixedlist.addItems(g().get('current.playlist'))
                fixedlist.selectItem(self.vplayer.getCurrentPlayItemPosition())

            if g.getHomeProperty('Playercontrol.Closed'):
                g.clearHomeProperty('Playercontrol.Closed')
                self.close()
                break
            else:
                if xbmc.getCondVisibility('Window.IsVisible(screencalibration)'):
                    self.close(True)
                    break
                xbmc.sleep(300)

    def _controlPanelAction(self, action, skipFocus=False):
        if action in ('show.panel', ):
            g.setHomeProperty('Player.ShowControl', 'show')
            if not skipFocus:
                self.setFocusId(ID.val('Playercontrol.PlayPause.Button'))
        elif action in ('show.settings', ):
            g.setHomeProperty('Player.ShowSettings', 'show')
            if not skipFocus:
                self.setFocusId(ID.val('Playercontrol.Settings.Panel'))
        elif action in ('update', ):
            if g.getHomeProperty('Player.ShowSettings'):
                self.setFocusId(ID.val('Playercontrol.Settings.Panel'))
            elif g.getHomeProperty('Player.ShowSubtitles'):
                self.setFocusId(ID.val('Playercontrol.Subtitles.Enable.Button'))
        else:
            if g.getHomeProperty('Player.ShowSettings'):
                # Hide setting
                g.clearHomeProperty('Player.ShowSettings')
                if not skipFocus:
                    self.setFocusId(ID.val('Playercontrol.Settings.Button'))
                return
            elif g.getHomeProperty('Player.ShowSubtitles'):
                # Hide subtitles
                g.clearHomeProperty('Player.ShowSubtitles')
                if not skipFocus:
                    self.setFocusId(ID.val('Playercontrol.ShowSubtitles.Button'))
                return

            # Hide playercontrol
            g.clearHomeProperty('Player.ShowControl')
            if not skipFocus:
                self.setFocusId(ID.val('Playercontrol.Mask.Button'))

    def setDefaultFocus(self):
        print '=', g.getHomeProperty('Player.NextNotify'), '-'
        if g.getHomeProperty('Player.ResumeCheck'):
            self.setFocusId(ID.val('Playercontrol.ResumeCheck.Grouplist'))
            return
        elif g.getHomeProperty('Player.NextNotify') in ('show', ):
            self.setFocusId(ID.val('Playercontrol.NextNotify.Grouplist'))
            return
        elif g.getHomeProperty('Player.NextNotify') in ('checked', ):
            self.setFocusId(ID.val('Playercontrol.Playlist.Fixedlist'))
            return
        else:
            self._controlPanelAction('show.panel')

    def onAction(self, action):
        """Action function."""
        if not self.getFocusId() or (not g.getHomeProperty('Player.NextNotify') and self.getFocusId() in ID.groupID('Playercontrol.NextNotify')):
            self.setDefaultFocus()
            return

        if action in (ACTION.val('UP'), ACTION.val('DOWN'), ACTION.val('LEFT'), ACTION.val('RIGHT'), ):
            if self.getFocusId() in (ID.val('Playercontrol.Mask.Button'), ):
                self.setDefaultFocus()
                return

            if g.getHomeProperty('Player.NextNotify') in ('show', ):
                if self.getFocusId() not in (ID.val('Playercontrol.Exit.Button'),
                                             ID.val('Playercontrol.NextNotify.Back.Button'),
                                             ID.val('Playercontrol.NextNotify.More.Button'), ):
                    self.setFocusId(ID.val('Playercontrol.NextNotify.Back.Button'))
                    return

            if self.getFocusId() not in ID.groupID('Playercontrol.Subtitles'):
                self._controlPanelAction('update')
                return

            if not self.getFocusId():
                self.setFocusId(ID.val('Playercontrol.PlayPause.Button'))
                return

        if action in (ACTION.val('MOUSE_MOVE'), ):
            if g.getHomeProperty('Player.ShowControl') not in ('show', ) and not g.getHomeProperty('Player.NextNotify'):
                self._controlPanelAction('show.panel')

        if action in (ACTION.val('MOUSE_LEFT_CLICK'), ):
            if g.getHomeProperty('Player.ShowControl') not in ('show', ):
                self._controlPanelAction('show.panel', True if self.getFocusId() in (ID.val('Playercontrol.Progress.Slider'), ) else False)

        if action in (ACTION.val('PREVIOUS_MENU'), ACTION.val('BACK'), ):
            if g.getHomeProperty('Player.ShowControl') in ('show', ):
                self._controlPanelAction('hide')
                return

            # g.setHomeProperty('Playercontrol.Closed', 'close')
            self.close()

        # super(PlayerControlDialog, self).onAction(action)

    def onClick(self, controlID):
        """Click trigger function."""
        if not self.getFocusId() or (not g.getHomeProperty('Player.NextNotify') and self.getFocusId() in ID.groupID('Playercontrol.NextNotify')):
            self.setDefaultFocus()
            return

        if controlID in (ID.val('Playercontrol.PlayPause.Button'), ID.val('Playercontrol.NextNotify.More.Button'), ):
            xbmc.executebuiltin('PlayerControl(Play)')

            if ID.key(controlID) in ('Playercontrol.NextNotify.More.Button', ):
                g.setHomeProperty('Player.NextNotify', 'checked')
                xbmc.sleep(300)
                self.setFocusId(ID.val('Playercontrol.Playlist.Fixedlist'))
            return

        if controlID in (ID.val('Playercontrol.NextNotify.Back.Button'), ):
            self.close()
            return

        if controlID in (ID.val('Playercontrol.FastForward.Button'), ):
            xbmc.executebuiltin('PlayerControl(Forward)')
            return

        if controlID in (ID.val('Playercontrol.Rewind.Button'), ):
            xbmc.executebuiltin('PlayerControl(Rewind)')
            return

        if controlID in (ID.val('Playercontrol.Mask.Button'), ):
            if g.getHomeProperty('Player.ShowControl') not in ('show', ):
                self._controlPanelAction('show.panel')

        if controlID in (ID.val('Playercontrol.Exit.Button'), ):
            # g.setHomeProperty('Playercontrol.Closed', 'close')
            self.close()
            return

        if controlID in (ID.val('Playercontrol.Resume.Button'), ):
            if self.vplayer.getState() not in ('pause', ):
                return

            resume = self.vplayer.getCurrentPlayItem().getProperty('offset_pure')
            self.vplayer._playerEventSearch(eval(resume))
            g.clearHomeProperty('Player.ResumeCheck')
            self.setFocusId(ID.val('Playercontrol.Mask.Button'))
            self.vplayer.pause()
            return

        if controlID in (ID.val('Playercontrol.Restart.Button'), ):
            if self.vplayer.getState() not in ('pause', ):
                return

            g.clearHomeProperty('Player.ResumeCheck')
            self.setFocusId(ID.val('Playercontrol.Mask.Button'))
            self.vplayer.pause()
            return

        if controlID in (ID.val('Playercontrol.Bookmarks.Button'), ):
            videoId = self.vplayer.getCurrentPlayItem().getProperty('id')
            self._controlPanelAction('hide', skipFocus=True)

            w = BookmarksDialog('dlg_bookmarks.xml', __addonpath__, "Default", videoId=videoId)
            w.doModal()
            del w
            self._controlPanelAction('show.panel', skipFocus=True)
            return

        if controlID in (ID.val('Playercontrol.ShowSubtitles.Button'), ):
            videoId = self.vplayer.getCurrentPlayItem().getProperty('id')
            self._controlPanelAction('hide')

            w = SubtitlesDialog('dlg_subtitles.xml', __addonpath__, "Default", videoId=videoId)
            w.doModal()
            del w
            return

        if controlID in (ID.val('Playercontrol.Settings.Button'), ):
            self._controlPanelAction('show.settings')
            '''delay for focusing the settings panel'''
            xbmc.sleep(100)

        if controlID in (ID.val('Playercontrol.Playlist.Fixedlist'), ):
            fixedlist = self.getControl(ID.val('Playercontrol.Playlist.Fixedlist'))
            startWith = fixedlist.getSelectedPosition()

            self.getControl(ID.val('Playercontrol.Exit.Label')).setLabel(self._genExitTitle())

            self.vplayer._playEventSelected(startWith)

            self.setFocusId(ID.val('Playercontrol.PlayPause.Button'))

        if controlID in (ID.val('Playercontrol.Subtitles.Import.Button'), ):
            subtitlePath = g.ensureUTF8(VideoStationAPI().genSubtitleUrl(self.vplayer.getCurrentPlayItem(), 'import'))
            self.vplayer.setSubtitles(subtitlePath)

        if controlID in (ID.val('Playercontrol.Subtitles.OnlineSubtitle.Button'), ):
            subtitlePath = g.ensureUTF8(VideoStationAPI().genSubtitleUrl(self.vplayer.getCurrentPlayItem(), 'download'))
            self.vplayer.setSubtitles(subtitlePath)

    def close(self, usePause=False):
        if usePause:
            self.vplayer.pause()
        else:
            self.vplayer.stop()
        '''
        if hasattr(self, 'r_timer'):
            self.r_timer.join()
        '''
        g.clearHomeProperty('Player.ShowControl')
        g.clearHomeProperty('Player.ShowSettings')
        g.clearHomeProperty('Player.ShowSubtitles')
        g.clearHomeProperty('Player.NextNotify')

        super(PlayerControlDialog, self).close()
                                                                                                                                                                                                                                                                                                                                                                                                        
