# -*- coding: utf-8 -*-
"""VideoHD Filter dialog."""
import xbmc
import xbmcgui
import xbmcaddon

from lib.static import *

from lib import g, ID, ACTION
from lib.api.videostation import VideoStationAPI

__addon__ = xbmcaddon.Addon()
__addonpath__ = __addon__.getAddonInfo('path').decode('utf-8')
__language__ = __addon__.getLocalizedString

class FilterDialog(xbmcgui.WindowXMLDialog):

    """Filter Dialog."""

    def __init__(self, strXMLname, strFallbackPath, strDefaultName, forceFallback=0, videoId=None):
        """Init function."""
        self.initOK = False
        self.videoId = videoId

        self.currentView = None
        self.resp = None
        self.selectYear = list()
        self.selectGenre = list()

        # self.filterClick = False

    def _initYear(self):
        years = list()
        selectYearItems = list()
        self.selectYear = g.getFilterStatus(self.currentView, 'year')

        yearPanel = self.getControl(ID.val('Filter.Year.Panel'))
        yearPanel.reset()

        for yearItem in self.resp.get('year'):
            year = yearItem.get('FileItem')
            l = xbmcgui.ListItem(year.get('name'))
            l.setProperty('id', year.get('id'))

            years.append(l)

            if year.get('id') in self.selectYear:
                selectYearItems.append(l)

        yearPanel.addItems(years)

        if selectYearItems:
            for item in selectYearItems:
                item.select(True)

    def _initGenre(self):
        genres = list()
        selectGenreItems = list()
        self.selectGenre = g.getFilterStatus(self.currentView, 'genre')

        genrePanel = self.getControl(ID.val('Filter.Genre.Panel'))
        genrePanel.reset()

        for genreItem in self.resp.get('genre'):
            genre = genreItem.get('FileItem')
            l = xbmcgui.ListItem(genre.get('name'))
            l.setProperty('id', genre.get('id'))

            genres.append(l)

            if genre.get('id') in self.selectGenre:
                selectGenreItems.append(l)

        genrePanel.addItems(genres)

        if selectGenreItems:
            for item in selectGenreItems:
                item.select(True)

    def onInit(self):
        """onInit function."""
        self.currentView = g.getHomeProperty('Browse.CurrentView')

        self._loadFilterItems()

        self._initYear()
        self._initGenre()

    def _loadFilterItems(self):
        # movies, TV-v: load filter items parameter
        filterParam = 'movies' if self.currentView in ('Movie', ) else 'TV-v'

        resp = VideoStationAPI().getFilterItems(filterParam)
        if not resp.get('filters'):
            return None

        self.resp = resp.get('filters')

        return self.resp

    def onAction(self, action):
        """Action function."""
        if action in (ACTION.val('PREVIOUS_MENU'), ACTION.val('BACK'), ACTION.val('MOUSE_RIGHT_CLICK'), ):
            self.close()

    def onClick(self, controlID):
        """Click trigger function."""
        if g.getHomeProperty('update.state') in ('updating', ):
            return

        # self.filterClick = True

        if controlID in (ID.val('Filter.Year.Panel'), ):
            listitem = self.getControl(controlID).getSelectedItem()

            if listitem.isSelected():
                listitem.select(False)
                self.selectYear.remove(listitem.getProperty('id'))
            else:
                listitem.select(True)
                self.selectYear.append(listitem.getProperty('id'))

            g.saveFilterStatus(self.currentView, 'year', self.selectYear)

            # Scan selected year
            year = ';'.join(self.selectYear) if self.selectYear else None
            updateYear = {self.currentView: {'year': year}}
            g.saveCurrentStatus(self.currentView, updateYear, 'year')

            g.setHomeProperty('update.state', 'update')

        if controlID in (ID.val('Filter.Genre.Panel'), ):
            listitem = self.getControl(controlID).getSelectedItem()

            if listitem.isSelected():
                listitem.select(False)
                self.selectGenre.remove(listitem.getProperty('id'))
            else:
                listitem.select(True)
                self.selectGenre.append(listitem.getProperty('id'))

            g.saveFilterStatus(self.currentView, 'genre', self.selectGenre)

            # Scan selected genre
            genre = ';'.join(self.selectGenre) if self.selectGenre else None
            updateGenre = {self.currentView: {'genre': genre}}
            g.saveCurrentStatus(self.currentView, updateGenre, 'genre')

            g.setHomeProperty('update.state', 'update')

    def close(self):
        """Close function."""
        g.setHomeProperty('update.state', 'exit')
        '''
        if self.filterClick:
            pass
        '''
        super(FilterDialog, self).close()
