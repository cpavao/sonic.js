# -*- coding: utf-8 -*-
"""VideoHD browse page."""
import collections

import xbmc
import xbmcgui
import xbmcaddon

from lib.static import *

from lib import g, ID, ACTION

__addon__ = xbmcaddon.Addon()
__addonpath__ = __addon__.getAddonInfo('path').decode('utf-8')
__language__ = __addon__.getLocalizedString

class SidemenuDialog(xbmcgui.WindowXMLDialog):

    """Browse Handler."""

    def __init__(self, strXMLname, strFallbackPath, strDefaultName, forceFallback=0):
        """Init function."""
        self.initOK = False

    def _getBgData(self, taskName):
        while g().get('bgTask').get_task_result(taskName) in ('init', ):
            xbmc.sleep(100)
        resp = g().get('bgTask').get_task_result(taskName)

        if not resp:
            g.setHomeProperty('Main.ShowEmptyMessage', 'true')
            return None
        else:
            g.clearHomeProperty('Main.ShowEmptyMessage')

        return resp

    def updateOtherSubtypes(self):
        otherId = 1
        resp = self._getBgData('classify.subtype')

        subtypes = collections.OrderedDict(sorted(resp.get('classificationMapping').items()))
        for k, v in subtypes.iteritems():
            if v.get('classificationType') in ('others', ) and v.get('subtypeName') not in ('Uncategorized', ):
                self.getControl(ID.val('Sidemenu.Other{}.Button'.format(otherId))).setLabel(v.get('string'))
                otherId += 1

    def onInit(self):
        """onInit function."""
        self.updateOtherSubtypes()

        if g.getHomeProperty('Browse.CurrentView') in ('VideoCollectionVideos', 'SmartCollectionVideos', ):
            focusType = g.getHomeProperty('Browse.CurrentView').rstrip('Videos')
        else:
            focusType = g.getHomeProperty('Browse.CurrentView')

        self.setFocusId(ID.val('Sidemenu.{}.Button'.format(focusType)))

    def onAction(self, action):
        """Action function."""
        if action in (ACTION.val('PREVIOUS_MENU'), ACTION.val('BACK'), ACTION.val('MOUSE_RIGHT_CLICK'), ):
            self.close()

    def onClick(self, controlID):
        """Click trigger function."""
        selectView = ID.key(controlID).split('.')[1]

        for clearItem in ['Movie', 'TvShow']:
            if g.getHomeProperty('Browse.{}.Filter'.format(clearItem)) and selectView not in (clearItem, ):
                clearContent = {clearItem: {'items': list(), 'year': None, 'genre': None}}
                g.saveCurrentStatus(clearItem, clearContent, ['genre', 'year', 'items'])

                g.saveFilterStatus(clearItem, 'year', list())
                g.saveFilterStatus(clearItem, 'genre', list())
                g.clearHomeProperty('Browse.{}.Filter'.format(clearItem))

        if g.getViewType(selectView) in ('Classification', ):
            g.setHomeProperty('Browse.Classification.{}.Selected'.format(selectView), 'True')

        g.clearHomeProperty('Browse.Folder.Layer')
        g.setHomeProperty('Browse.CurrentView', selectView)
        self.close()

    def close(self):
        super(SidemenuDialog, self).close()
