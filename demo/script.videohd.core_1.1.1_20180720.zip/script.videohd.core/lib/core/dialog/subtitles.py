# -*- coding: utf-8 -*-
"""VideoHD Subtitles dialog."""
import xbmc
import xbmcgui
import xbmcaddon

from lib.static import *

from lib import g, ID, ACTION
from lib.api.videostation import VideoStationAPI

__addon__ = xbmcaddon.Addon()
__addonpath__ = __addon__.getAddonInfo('path').decode('utf-8')
__language__ = __addon__.getLocalizedString

class SubtitlesDialog(xbmcgui.WindowXMLDialog):

    """Subtitles Dialog."""

    def __init__(self, strXMLname, strFallbackPath, strDefaultName, forceFallback=0, videoId=None):
        """Init function."""
        self.initOK = False
        self.vplayer = g().get('player')
        self.api = VideoStationAPI()

    def _loadSubtitles(self):
        subtitlePanel = self.getControl(ID.val('Subtitle.List.Panel'))

        while g().get('bgTask').get_task_result('player.subtitle') in ('init', ):
            xbmc.sleep(100)
        listitems = g().get('bgTask').get_task_result('player.subtitle')

        for listitem in listitems:
            if g.getHomeProperty('Player.Subtitle') in (listitem.getProperty('name'), ):
                listitem.select(True)
            else:
                listitem.select(False)

        subtitlePanel.addItems(listitems)

        if subtitlePanel.size() > 0:
            subtitlePanel.setVisible(True)
            # self.getControl(ID.val('Subtitle.List.Group')).setHeight(subtitlePanel.size() * 92)
            self.getControl(ID.val('Subtitle.List.Panel')).setHeight(subtitlePanel.size() * 92 if subtitlePanel.size() < 4 else 4 * 92)
        else:
            subtitlePanel.setVisible(False)

    def onInit(self):
        """onInit function."""
        g.setHomeProperty('Player.ShowSubtitles', 'show')
        self._loadSubtitles()
        self.setFocusId(ID.val('Subtitles.Enable.Button'))

    def onClick(self, controlID):
        """Click trigger function."""
        if controlID in (ID.val('Subtitles.Back.Button'), ):
            self.close()

        if controlID in (ID.val('Subtitle.List.Panel'), ):
            selectItem = self.getControl(ID.val('Subtitle.List.Panel')).getSelectedItem()
            g.setDownloadSubtitleFile(selectItem.getProperty('name'))
            self.close()

        if controlID in (ID.val('Subtitle.SearchResult.Panel'), ):
            selectItem = self.getControl(ID.val('Subtitle.SearchResult.Panel')).getSelectedItem()

            if VideoStationAPI().downloadSubtitle(self.vplayer.getCurrentPlayItem().getProperty('id'), selectItem):
                g.setDownloadSubtitleFile('download')

            self.close()

        if controlID in (ID.val('Subtitle.Search.Button'), ):
            g.clearHomeProperty('Subtitle.ShowEmpty')
            g.setHomeProperty('Subtitle.ShowLoading', 'show')
            searchResult = list()
            searchPanel = self.getControl(ID.val('Subtitle.SearchResult.Panel'))
            searchPanel.reset()
            resp = VideoStationAPI().getSubtitleSearchResult(self.vplayer.getCurrentPlayItem().getProperty('id'))

            if resp.get('captions'):
                for c in resp.get('captions'):
                    caption = c.get('caption')
                    l = xbmcgui.ListItem(caption.get('sub_name'))
                    l.setProperty('lang', caption.get('language'))
                    l.setProperty('url', caption.get('url'))
                    l.setProperty('sites', caption.get('sites'))
                    l.setProperty('movie_name', caption.get('movie_name'))
                    l.setProperty('type', caption.get('type'))
                    searchResult.append(l)

                searchPanel.addItems(searchResult)
                searchPanel.setHeight(searchPanel.size() * 92 if searchPanel.size() < 4 else 4 * 92)
            else:
                g.setHomeProperty('Subtitle.ShowEmpty', 'show')

            g.clearHomeProperty('Subtitle.ShowLoading')

    def onAction(self, action):
        """Action function."""
        if action in (ACTION.val('PREVIOUS_MENU'), ACTION.val('BACK'), ):
            self.close()

    def close(self):
        g.clearHomeProperty('Player.ShowSubtitles')
        super(SubtitlesDialog, self).close()
