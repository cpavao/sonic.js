# -*- coding: utf-8 -*-
"""VideoHD Finder dialog."""
import socket

import xbmc
import xbmcgui
import xbmcaddon

from lib.static import *
from lib.static.icon import Icon
from lib.utils.finder import Finder

from lib import g, ID, ACTION

__addon__ = xbmcaddon.Addon()
__addonpath__ = __addon__.getAddonInfo('path').decode('utf-8')
__language__ = __addon__.getLocalizedString


class FinderDialog(xbmcgui.WindowXMLDialog):

    """Finder Dialog."""

    def __init__(self, strXMLname, strFallbackPath, strDefaultName, forceFallback=0):
        """Init function."""
        self.selectedNas = dict()
        self.icon = Icon()
        g.setHomeProperty('Finder.Status', 'init')

    def onInit(self):
        """onInit function."""
        self._updateFinderData()
        return

    def _updateFinderData(self):
        tmp_total_nas = 0
        empty_count = 0
        nasList = list()
        panel = self.getControl(ID.val('Finder.NasList.Panel'))
        panel.reset()

        g.setHomeProperty('Finder.Status', 'searching')
        self.setFocusId(ID.val('Finder.Searching.Back.Button'))
        if not hasattr(self, 'fd'):
            while (not xbmc.abortRequested):
                if g().get('BreakThread'):
                    return

                try:
                    self.fd = Finder()
                    break
                except socket.error as e:
                    if e.errno in (48, 51, 101, ):
                        g.setHomeProperty('Finder.Status', 'empty')
                        self.setFocusId(ID.val('Finder.NotFound.Refresh.Button'))
                        return
                    else:
                        g.log_debug(msg=str(e))
                    xbmc.sleep(1000)
                else:
                    print 'else except'
                    xbmc.sleep(1000)
        else:
            self.fd.boardcast_finder_req()
            xbmc.sleep(3000)

        while (not xbmc.abortRequested):
            if g().get('BreakThread'):
                return

            if self.fd.total_current_nas() > 0:
                if tmp_total_nas != self.fd.total_current_nas():
                    tmp_total_nas = self.fd.total_current_nas()
                    xbmc.sleep(1000)
                else:
                    break
            else:
                empty_count += 1
                xbmc.sleep(1000)

                if empty_count > 5:
                    g.setHomeProperty('Finder.Status', 'empty')
                    self.setFocusId(ID.val('Finder.NotFound.Refresh.Button'))
                    return

        pureList = self.fd.list_current_nas()
        for ip in pureList.keys():
            item = xbmcgui.ListItem(pureList.get(ip).get('server_name'), ip)
            item.setProperty('web_port', str(pureList.get(ip).get('web_port')) if pureList.get(ip).get('web_port') else DEFAULT_HTTP_PORT)
            item.setProperty('enable_force_ssl', str(pureList.get(ip).get('enable_force_ssl')))
            item.setProperty('ssl_port', str(pureList.get(ip).get('ssl_port')) if pureList.get(ip).get('ssl_port') else DEFAULT_SSL_PORT)

            ic = self.icon.get_icon(pureList.get(ip).get('display_model_name'))
            print '{}: {}'.format(pureList.get(ip).get('display_model_name'), ic)
            item.setArt({'thumb': ic})
            item.setProperty('thumb.focus', ic)

            nasList.append(item)

        panel.addItems(nasList)

        g.setHomeProperty('Finder.Status', 'done')
        self.setFocusId(ID.val('Finder.NasList.Panel'))

    def _update_focus(self):
        if g.getHomeProperty('Finder.Status') in ('done', ):
            self.setFocusId(ID.val('Finder.NasList.Panel'))
        elif g.getHomeProperty('Finder.Status') in ('empty', ):
            self.setFocusId(ID.val('Finder.NotFound.Refresh.Button'))
        else:
            self.setFocusId(ID.val('Finder.Searching.Back.Button'))

    def onAction(self, action):
        """Action function."""
        if not self.getFocusId() and action not in (ACTION.val('PREVIOUS_MENU'), ACTION.val('BACK'), ACTION.val('MOUSE_RIGHT_CLICK'), ):
            self._update_focus()
            return

        if action in (ACTION.val('PREVIOUS_MENU'), ACTION.val('BACK'), ACTION.val('MOUSE_RIGHT_CLICK'), ):
            self.close()

    def onClick(self, controlID):
        """Click trigger function."""
        if controlID in (ID.val('Finder.NasList.Panel'), ):
            selectItem = self.getControl(ID.val('Finder.NasList.Panel')).getSelectedItem()
            self.selectedNas['ip'] = selectItem.getLabel2()
            self.selectedNas['web_port'] = eval(selectItem.getProperty('web_port'))
            self.selectedNas['enable_force_ssl'] = False if selectItem.getProperty('enable_force_ssl') in ('0', ) else True
            self.selectedNas['ssl_port'] = eval(selectItem.getProperty('ssl_port'))
            self.close()

        if controlID in (ID.val('Finder.Refresh.Button'), ID.val('Finder.NotFound.Refresh.Button'), ):
            self._updateFinderData()

        if controlID in (ID.val('Finder.NotFound.Back.Button'), ID.val('Finder.Searching.Back.Button'), ):
            self.close()

    def close(self):
        """Close function."""
        if hasattr(self, 'fd'):
            self.fd.stop_finder()

        super(FinderDialog, self).close()
