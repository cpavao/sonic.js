# -*- coding: utf-8 -*-
"""VideoHD Sorting dialog."""
import xbmc
import xbmcgui
import xbmcaddon

from lib.static import *

from lib import g, ID, ACTION

__addon__ = xbmcaddon.Addon()
__addonpath__ = __addon__.getAddonInfo('path').decode('utf-8')
__language__ = __addon__.getLocalizedString

class SortingDialog(xbmcgui.WindowXMLDialog):

    """Sorting Dialog."""

    def __init__(self, strXMLname, strFallbackPath, strDefaultName, forceFallback=0):
        """Init function."""
        self.initOK = False

        self.currentView = None

        self.albumId = None

        self.CurrentCISorted = dict()

        self.sortingClick = False

        self.updateVideoHDFile = {'items': list(), 'sortBy': None, 'orderBy': None}

        self.sortMapping = {'name': 0, 'dbtime': 1, 'watch': 2, 'air_date': 3, 'create': 4,'duration': 5,
                            'dimensions': 6, 'filesize': 7, 'color': 8, 'rating': 9, 'collect_create': 10, 'classification': 11}

    def onInit(self):
        """onInit function."""
        # Init sorting/order method.
        self.currentView = g.getHomeProperty('Browse.CurrentView')

        if g.getViewType(self.currentView) in ('CollectionInfo', ):
            self.albumId = g.getCurrentStatus(self.currentView, 'currentAlbumId')
            g.setHomeProperty('Sorting.Order.Method', g.getCurrentStatus(self.currentView, 'orderBy', albumId=self.albumId))
            g.setHomeProperty('Sorting.Sort.Method', g.getCurrentStatus(self.currentView, 'sortBy', albumId=self.albumId))
        else:
            g.setHomeProperty('Sorting.Order.Method', g.getCurrentStatus(self.currentView, 'orderBy'))
            g.setHomeProperty('Sorting.Sort.Method', g.getCurrentStatus(self.currentView, 'sortBy'))

    def onAction(self, action):
        """Action function."""
        if action in (ACTION.val('PREVIOUS_MENU'), ACTION.val('BACK'), ):
            if g.getHomeProperty('update.state') in ('updating', ):
                return

            self.close()

        if action in (ACTION.val('MOUSE_LEFT_CLICK'), ):
            if not self.getFocusId():
                self.close()

    def onClick(self, controlID):
        """Click trigger function."""
        if g.getHomeProperty('update.state') in ('updating', ):
            return

        self.sortingClick = True

        sortButton = ID.key(controlID)
        sortBy = sortButton.split('.')[1].lower()
        '''keyword: create, for collection'''
        if sortBy in ('createdate', ):
            sortBy = 'create'

        # Set current sorting/order method
        if g.getHomeProperty('Sorting.Sort.Method') in (sortBy, ):
            orderBy = 'ASC' if g.getHomeProperty('Sorting.Order.Method') in ('DESC', ) else 'DESC'
        else:
            orderBy = 'DESC'

        g.setHomeProperty('Sorting.Order.Method', orderBy)
        g.setHomeProperty('Sorting.Sort.Method', sortBy)

        # Update g.currentStatus -> orderBy/sortBy
        if g.getViewType(self.currentView) in ('CollectionInfo', ):
            sortOrderData = {self.currentView: {self.albumId: {'sortBy': sortBy, 'orderBy': orderBy}}}

            self.CurrentCISorted = {'currentView': self.currentView, 'currentAlbumId': self.albumId, 'currentCIData': None}
        else:
            sortOrderData = {self.currentView: {'sortBy': sortBy, 'orderBy': orderBy}}

        g.saveCurrentStatus(self.currentView, sortOrderData, ['sortBy', 'orderBy'], albumId=self.albumId)

        # Update videohd.conf -> orderBy/sortBy
        g.setSort(self.currentView, sortBy, orderBy)

        g.setHomeProperty('update.state', 'update')

    def _clearRelatedSortingItems(self):
        sortBy = g.getHomeProperty('Sorting.Sort.Method')
        orderBy = g.getHomeProperty('Sorting.Order.Method')
        if g.getViewType(self.currentView)in ('Collection', ):
            sortTargets = g.getSortItem(self.sortMapping['collect_create'])
        else:
            sortTargets = g.getSortItem(self.sortMapping[sortBy])

        self.updateVideoHDFile['sortBy'] = sortBy
        self.updateVideoHDFile['orderBy'] = orderBy

        if self.CurrentCISorted:
            '''
            collectionkey = self.CurrentCISorted['currentView'].split('Collection')[0]
            collection = '{}Collection'.format(collectionkey)
            sortTargets.remove(collection)
            '''
            CIData = g.getCurrentStatus(self.CurrentCISorted['currentView'],
                                        albumId=self.CurrentCISorted['currentAlbumId'])
            self.CurrentCISorted['currentCIData'] = CIData

        if 'VideoCollectionVideos' in sortTargets or 'SmartCollectionVideos' in sortTargets:
            self._clearCISortingContent(sortBy, orderBy)

            sortTargets.remove('VideoCollectionVideos')
            sortTargets.remove('SmartCollectionVideos')

        if self.currentView not in ('VideoCollectionVideos', 'SmartCollectionVideos', 'Folder', ):
            sortTargets.remove(self.currentView)

        for target in sortTargets:
            updateSortData = {target: {'sortBy': sortBy, 'orderBy': orderBy}}
            if target in ('Folder', ):
                if g.getCurrentStatus(target, 'layerStack') not in (1, ):
                    if self.currentView in ('Folder', ):
                        if g.getCurrentStatus(target, 'layerStack') > 2:
                            updateLayer = g.getCurrentStatus(target, 'layerStack')
                            self._clearFolderOtherLayerData(updateLayer)
                        else:
                            pass
                    else:
                        updateLayer = g.getCurrentStatus(target, 'layerStack') + 1
                        self._clearFolderOtherLayerData(updateLayer)

                g.saveCurrentStatus(target, updateSortData, ['sortBy', 'orderBy'])

                # g.setSort(target, sortBy, orderBy)
                self.updateVideoHDFile['items'].append(target)
                continue

            updateData = {target: {'items': list()}}
            g.saveCurrentStatus(target, updateData, 'items')
            g.saveCurrentStatus(target, updateSortData, ['sortBy', 'orderBy'])

            # g.setSort(target, sortBy, orderBy)
            self.updateVideoHDFile['items'].append(target)

        self.CurrentCISorted = dict()

    def _clearFolderOtherLayerData(self, clearLayer):
        for clearCount in range(2, clearLayer):
            layer = 'layer{}'.format(clearCount)
            updateLayerData = {'Folder': {layer: {'items': list()}}}
            g.saveCurrentStatus('Folder', updateLayerData, 'items', layer=layer)

    def _clearCISortingContent(self, sortBy, orderBy):
        g.initCurrentStatus('VideoCollectionVideos', dict())
        # g.setSort('VideoCollectionVideos', sortBy, orderBy)
        self.updateVideoHDFile['items'].append('VideoCollectionVideos')
        g.initCurrentStatus('SmartCollectionVideos', dict())
        # g.setSort('SmartCollectionVideos', sortBy, orderBy)
        self.updateVideoHDFile['items'].append('SmartCollectionVideos')

        if self.CurrentCISorted:
            recoverCIData = {self.CurrentCISorted['currentAlbumId']: self.CurrentCISorted['currentCIData'],
                             'currentAlbumId': self.CurrentCISorted['currentAlbumId']}
            g.initCurrentStatus(self.CurrentCISorted['currentView'], recoverCIData)

    def close(self):
        g.setHomeProperty('update.state', 'exit')

        if self.sortingClick:
            self._clearRelatedSortingItems()

            g.clearHomeProperty('Sorting.Order.Method')
            g.clearHomeProperty('Sorting.Sort.Method')

        super(SortingDialog, self).close()
                      
