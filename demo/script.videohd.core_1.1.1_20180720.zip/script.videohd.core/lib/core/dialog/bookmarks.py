# -*- coding: utf-8 -*-
"""VideoHD Bookmarks dialog."""
import xbmc
import xbmcgui
import xbmcaddon

from lib.static import *

from lib import g, ID, ACTION
from lib.api.videostation import VideoStationAPI

__addon__ = xbmcaddon.Addon()
__addonpath__ = __addon__.getAddonInfo('path').decode('utf-8')
__language__ = __addon__.getLocalizedString

class BookmarksDialog(xbmcgui.WindowXMLDialog):

    """Bookmarks Dialog."""

    def __init__(self, strXMLname, strFallbackPath, strDefaultName, forceFallback=0, videoId=None):
        """Init function."""
        self.initOK = False
        self.videoId = videoId
        self.vplayer = g().get('player')

    def onInit(self):
        """onInit function."""
        g.setHomeProperty('Player.ShowBookmarks', 'true')
        self.vplayer.pause()
        self._initBookMarks()

    def _initBookMarks(self):
        listitems = list()

        resp = VideoStationAPI().getBookmarks(self.videoId)
        if not resp.get('bookmarks'):
            return None

        for bookmark in resp.get('bookmarks'):
            mark = xbmcgui.ListItem(bookmark.get('bookmark')['MarkName'])
            t_transfer = g.timeTransfer(eval(bookmark.get('bookmark')['Position']))
            transferBookmarkOffset = g.showTime(t_transfer)
            mark.setProperty('bookmark.offset', transferBookmarkOffset)
            mark.setProperty('bookmark.pure.offset', bookmark.get('bookmark')['Position'])
            listitems.append(mark)

        g.setHomeProperty('Bookmarks.Counts', str(len(listitems)))

        self.getControl(ID.val('Bookmarks.Panel')).reset()
        self.getControl(ID.val('Bookmarks.Panel')).addItems(items=listitems)

        xbmc.sleep(100)
        self.setFocusId(ID.val('Bookmarks.Panel'))

    def onAction(self, action):
        """Action function."""
        if action in (ACTION.val('PREVIOUS_MENU'), ACTION.val('BACK'), ):
            self.close()

    def onClick(self, controlID):
        """Click trigger function."""
        if controlID in (ID.val('Bookmarks.Panel'), ):
            offset = self.getControl(ID.val('Bookmarks.Panel')).getSelectedItem().getProperty('bookmark.pure.offset')
            self.vplayer._playerEventSearch(eval(offset))

            if self.vplayer.getState() not in ('playing', ):
                self.vplayer.pause()

            self.close()

        if controlID in (ID.val('Bookmarks.Exit.Button'), ):
            self.close()

    def close(self):
        if self.vplayer.getState() not in ('playing', ):
            self.vplayer.pause()

        g.clearHomeProperty('Player.ShowBookmarks')
        super(BookmarksDialog, self).close()
