# -*- coding: utf-8 -*-
"""VideoHD Login dialog."""
import xbmc
import xbmcgui
import xbmcaddon

from lib.static import *

from lib import g, ID, ACTION
from lib.core.dialog.finder import FinderDialog

__addon__ = xbmcaddon.Addon()
__addonpath__ = __addon__.getAddonInfo('path').decode('utf-8')
__language__ = __addon__.getLocalizedString


class LoginDialog(xbmcgui.WindowXMLDialog):

    """Login Dialog."""

    def __init__(self, strXMLname, strFallbackPath, strDefaultName, forceFallback=0):
        """Init function."""
        self.loginCancel = False
        self.nextFocusButton = ['HostIP', 'User', 'Passwd', 'HostPort']
        self.rememberMsg = g.getVideoHDConfValue()

    def _genPasscode(self, passCode):
        return len(passCode) * PASSWORD_SYMBOL

    def _initLoginMsg(self):
        '''VideoHD first time'''
        for key in self.rememberMsg.keys():
            if self.rememberMsg.get(key):
                initButton = 'Login.{}.Button'.format(key)
                g.clearHomeProperty('Login.Empty.{}'.format(key))

                if key in ('RememberMe', 'EnableSSL', ):
                    initButton = 'Login.{}.Radiobutton'.format(key)
                    if self.rememberMsg.get(key):
                        self.getControl(ID.val(initButton)).setSelected(True)
                elif key in ('Passwd', ):
                    if self.rememberMsg.get(key) not in (' ', ):
                        self.getControl(ID.val(initButton)).setLabel(self._genPasscode(self.rememberMsg.get(key)))
                else:
                    self.getControl(ID.val(initButton)).setLabel(self.rememberMsg.get(key))
            else:
                # Set default parameter.
                if key in ('User', ):
                    self._updateLoginMsg('User', DEFAULT_USER)
                elif key in ('HostPort', ):
                    defaultPort = DEFAULT_SSL_PORT if self.rememberMsg.get('EnableSSL') else DEFAULT_HTTP_PORT
                    self._updateLoginMsg('HostPort', defaultPort)
                else:
                    g.setHomeProperty('Login.Empty.{}'.format(key), 'true')

    def onInit(self):
        """onInit function."""
        g.setWaitingMask(self, state='init')
        self._initLoginMsg()

    def _focusHandler(self, currentFocus):
        nextFocusIdx = self.nextFocusButton.index(currentFocus) + 1

        if nextFocusIdx in (len(self.nextFocusButton), ):
            return

        nextButton = self.nextFocusButton[nextFocusIdx]
        self.setFocusId(ID.val('Login.{}.Button'.format(nextButton)))

    def onAction(self, action):
        """Action function."""
        if action in (ACTION.val('PREVIOUS_MENU'), ACTION.val('BACK'), ACTION.val('MOUSE_RIGHT_CLICK'), ):
            self.loginCancel = True
            self.close()

    def _updateLoginMsg(self, key, val):
        g().set(key, val)
        if key in ('EnableSSL', 'RememberMe', ):
            self.rememberMsg[key] = val
            self.getControl(ID.val('Login.{}.Radiobutton'.format(key))).setSelected(val)
        else:
            self.rememberMsg[key] = str(val)
            control = self.getControl(ID.val('Login.{}.Button'.format(key)))

            if val in (' ', ):
                control.setLabel(val)
                g.setHomeProperty('Login.Empty.{}'.format(key), 'true')
            else:
                if key in ('Passwd', ):
                    control.setLabel(self._genPasscode(val))
                else:
                    control.setLabel(val)

                g.clearHomeProperty('Login.Empty.{}'.format(key))

    def onClick(self, controlID):
        """Click trigger function."""
        if controlID in (ID.val('Login.Search.Button'), ):
            w = FinderDialog('dlg_finder.xml', __addonpath__, "Default")
            w.doModal()

            if w.selectedNas:
                self._updateLoginMsg('HostIP', w.selectedNas.get('ip'))
                self._updateLoginMsg('User', DEFAULT_USER)

                if w.selectedNas.get('enable_force_ssl'):
                    self._updateLoginMsg('HostPort', w.selectedNas.get('ssl_port'))
                else:
                    self._updateLoginMsg('HostPort', w.selectedNas.get('web_port'))
                self._updateLoginMsg('EnableSSL', w.selectedNas.get('enable_force_ssl'))

                self._updateLoginMsg('Passwd', ' ')
            del w
            return

        if controlID in (ID.val('Login.RememberMe.Radiobutton'),
                         ID.val('Login.EnableSSL.Radiobutton'), ):
            changeKey = ID.key(controlID).split('.')[1]

            if self.getControl(controlID).isSelected():
                self._updateLoginMsg(changeKey, True)

                if changeKey in ('EnableSSL', ):
                    self._updateLoginMsg('HostPort', DEFAULT_SSL_PORT)
            else:
                self._updateLoginMsg(changeKey, False)

                if changeKey in ('EnableSSL', ):
                    self._updateLoginMsg('HostPort', DEFAULT_HTTP_PORT)
            return

        if controlID in (ID.val('Login.LoginCheck.Button'), ):
            g.setWaitingMask(self, state='on')
            check = g.loginCheck(self.rememberMsg)
            if check.get('result'):
                '''init Global Login Message for setting back to main page'''
                for key in self.rememberMsg.keys():
                    globalLoginProperty = 'Global.Login.{}'.format(key)
                    g.setHomeProperty(globalLoginProperty, g.ensureUTF8(self.rememberMsg.get(key)))

                '''update videohd.conf'''
                g.updateVideoHDConf(self.rememberMsg)

                '''check localhost or not here'''
                # g.checkLocalHost()
                self.close()
            else:
                '''clear Passwd videohd.conf'''
                for key in self.rememberMsg.keys():
                    globalLoginProperty = 'Global.Login.{}'.format(key)
                    g.clearHomeProperty(globalLoginProperty)

                self._updateLoginMsg('Passwd', ' ')
                self.setFocusId(ID.val('Login.Passwd.Button'))

                g.updateVideoHDConf(self.rememberMsg)

                g.setWaitingMask(self, state='off')
                if not check.get('msg'):
                    return

                if check.get('msg'):
                    g.showDialog('ok', check.get('msg'))

            return

        if controlID in (ID.val('Login.Cancel.Button'), ):
            self.loginCancel = True
            self.close()
            return

        if controlID in ID.groupID('Login.'):
            loginMsgName = ID.key(controlID).split('.')[1]
            control = self.getControl(controlID)

            hidden = True if loginMsgName in ('Passwd', ) else False

            rememberMe = eval(self.rememberMsg.get('RememberMe')) if type(self.rememberMsg.get('RememberMe')) in (str, ) else self.rememberMsg.get('RememberMe')
            # defaultValue = self.rememberMsg.get(loginMsgName) if rememberMe else ''
            defaultValue = self.rememberMsg.get(loginMsgName) if self.rememberMsg.get(loginMsgName) not in (' ', ) else None

            kb = xbmc.Keyboard(defaultValue,
                               u'Input your message',
                               hidden)
            kb.doModal()

            if kb.isConfirmed():
                kbText = kb.getText()
                self._updateLoginMsg(loginMsgName, kbText if kbText else ' ')
                '''if kbText:
                    g.clearHomeProperty('Login.Empty.{}'.format(loginMsgName))
                    if loginMsgName in ('Passwd', ):
                        control.setLabel(self._genPasscode(kbText))
                    else:
                        control.setLabel(kbText)
                else:
                    control.setLabel(' ')
                    g.setHomeProperty('Login.Empty.{}'.format(loginMsgName), 'true')

                self.rememberMsg[loginMsgName] = kbText
                '''
                self._focusHandler(loginMsgName)

    def close(self):
        """Close function."""
        g.setWaitingMask(self, state='off')
        for item in self.nextFocusButton:
            g.clearHomeProperty('Login.Empty.{}'.format(item))

        super(LoginDialog, self).close()
