# -*- coding: utf-8 -*-
"""VideoHD Help dialog."""
import xbmc
import xbmcgui
import xbmcaddon

from lib.static import *

from lib import g, ID, ACTION

__addon__ = xbmcaddon.Addon()
__addonpath__ = __addon__.getAddonInfo('path').decode('utf-8')
__language__ = __addon__.getLocalizedString

class HelpDialog(xbmcgui.WindowXMLDialog):

    """Help Dialog."""

    def __init__(self, strXMLname, strFallbackPath, strDefaultName, forceFallback=0):
        """Init function."""
        self.initOK = False

    def onInit(self):
        """onInit function."""
        pass

    def onAction(self, action):
        """Action function."""
        if action in (ACTION.val('PREVIOUS_MENU'), ACTION.val('BACK'), ACTION.val('MOUSE_RIGHT_CLICK'), ):
            self.close()

    def onClick(self, controlID):
        """Click trigger function."""
        pass

    def close(self):
        """Close function."""
        super(HelpDialog, self).close()
