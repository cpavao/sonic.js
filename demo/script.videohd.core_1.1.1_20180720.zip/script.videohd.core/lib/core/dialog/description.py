# -*- coding: utf-8 -*-
"""VideoHD more page."""
import xbmc
import xbmcgui
import xbmcaddon

from lib.static import *

from lib import g, ID, ACTION

__addon__ = xbmcaddon.Addon()
__addonpath__ = __addon__.getAddonInfo('path').decode('utf-8')
__language__ = __addon__.getLocalizedString

class DescriptionDialog(xbmcgui.WindowXMLDialog):

    """Bookmarks Dialog."""

    def __init__(self, strXMLname, strFallbackPath, strDefaultName, forceFallback=0, item=None):
        """Init function."""
        self.item = item

    def onInit(self):
        """onInit function."""
        self._initDescription()

    def _initDescription(self):
        title = self.item.getLabel()
        description = self.item.getProperty('description')

        self.getControl(ID.val('Description.Title.Label')).setLabel(title)
        self.getControl(ID.val('Description.Description.Textbox')).setText(description)

    def onAction(self, action):
        """Action function."""
        if action in (ACTION.val('PREVIOUS_MENU'), ACTION.val('BACK'), ):
            self.close()

    def onClick(self, controlID):
        """Click trigger function."""
        if controlID in (ID.val('Description.Back.Button'), ):
            self.close()

    def close(self):
        super(DescriptionDialog, self).close()
