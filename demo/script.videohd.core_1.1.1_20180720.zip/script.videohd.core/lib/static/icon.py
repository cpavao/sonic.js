import json
import xbmcaddon

from lib.static import *

__addon__ = xbmcaddon.Addon()
__addonpath__ = __addon__.getAddonInfo('path')

class Icon(object):
    def __init__(self):
        self.ic_mapping = json.load(open('{}/etc/device_icon.json'.format(__addonpath__)))
        print self.ic_mapping

    def get_icon(self, model):
        if model in self.ic_mapping:
            return 'nas_icon/{}_{}x{}.png'.format(self.ic_mapping[model].get('type_name'), DEFAULT_ICON_WIDTH, DEFAULT_ICON_HEIGHT)

        # ic_nas_0b_t1_100x100.png
        return 'nas_icon/{}_{}x{}.png'.format(DEFAULT_ICON_TYPE, DEFAULT_ICON_WIDTH, DEFAULT_ICON_HEIGHT)
