# -*- coding: utf-8 -*-
import os
import uuid
import inspect
import datetime

import subprocess
from ConfigParser import RawConfigParser
from distutils.version import LooseVersion
from threading import Thread

import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs

from utils.pathDecoder import pathDecoder
from lib.utils.bgtask import BackgroundTask
from lib.static import *

__addon__ = xbmcaddon.Addon()
__addonpath__ = __addon__.getAddonInfo('path')
__language__ = __addon__.getLocalizedString


class g(object):
    _instance = None

    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            cls._instance = super(g, cls).__new__(cls, *args, **kwargs)
            cls._instance.winId = xbmcgui.Window(10000)
            cls._instance.g = {}

        return cls._instance

    @classmethod
    def refresh(cls):
        cls._instance.g['addonVer'] = __addon__.getAddonInfo('version')

        # Add global var here.
        cls._instance.g['SortItem'] = dict()
        cls._instance.g['CurrentStatus'] = dict()
        cls._instance.g['TVShowInfoBg'] = list()  # TVShowInfo Background Thumbnail
        cls._instance.g['UpdatePlayercontrolExitLabel'] = False
        cls._instance.g['CollectionInfoTitle'] = None
        # cls._instance.g['UpdatePauseFocusPosition'] = False
        cls._instance.g['reloadPlaylist'] = False
        cls._instance.g['videoHDConfPath'] = '{}/etc/videohd.conf'.format(__addonpath__)

        cls.loadVideoHDConf()
        cls.getLocalHostIp()
        # cls.checkLocalHost()

        cls._instance.g['SortList'] = ['Movie', 'TvShow', 'HomeVideo', 'MusicVideo', 'KTV', 'Uncategory',
                                       'Folder', 'ShareVideo',
                                       'VideoCollection', 'SmartCollection',
                                       'VideoCollectionVideos', 'SmartCollectionVideos']

        cls._instance.g['FilterStatus'] = {'TvShow': {'year': list(), 'genre': list()},
                                           'Movie': {'year': list(), 'genre': list()}}

        cls._instance.g['QTSFWVersion'] = None

        cls._instance.g['OffsetMsg'] = None

        cls._instance.g['ThreadPool'] = list()
        cls._instance.g['BreakThread'] = False

        cls._instance.g['bgTask'] = BackgroundTask(10)

        cls.initSortFile()

        cls.getHiddenInfo()

    @classmethod
    def checkLocalEnv(cls):
        if os.path.exists('/usr/local/bin/qbus'):
            return 'linux_station'
        elif os.path.exists('/opt/bin/alicego'):
            return 'hd_station'
        else:
            return None

    @classmethod
    def updateThumbLocalPath(cls):
        from lib.api.videostation import VideoStationAPI

        prefix = VideoStationAPI().getLocalThumbPrefix().get('prefix')
        if cls.checkLocalEnv() in ('hd_station', ):
            VideoFilePrefix = '/share/{}'.format(prefix)
        else:
            VideoFilePrefix = '/share2/{}'.format(prefix)

        if os.path.exists(VideoFilePrefix):
            cls._instance.g['Thumbnail_Path'] = u'{0}/.system/thumbnail/'.format(VideoFilePrefix)
            cls._instance.g['TVShow_Thumbnail_Path'] = u'{0}/.system/video/'.format(VideoFilePrefix)

    @classmethod
    def getHiddenInfo(cls):
        try:
            # Get Skin ver
            skinPath = xbmcaddon.Addon('skin.videohd').getAddonInfo('path')
            xbmc.log('{}/.build_info'.format(skinPath))
            if os.path.exists('{}/.build_info'.format(skinPath)):
                with open('{}/.build_info'.format(skinPath), 'r') as skinfile:
                    cls.setHomeProperty('Global.Skin.Ver', skinfile.read().splitlines()[0])

            # Get Core ver
            xbmc.log('{}/.build_info'.format(__addonpath__))
            if os.path.exists('{}/.build_info'.format(__addonpath__)):
                with open('{}/.build_info'.format(__addonpath__), 'r') as corefile:
                    cls.setHomeProperty('Global.Core.Ver', corefile.read().splitlines()[0])

            # Get Client Id
            if os.path.exists('{}/.client_id'.format(__addonpath__)):
                with open('{}/.client_id'.format(__addonpath__), 'r') as clientfile:
                    cls._instance.g['client_id'] = clientfile.read().splitlines()[0]
            else:
                cls._instance.g['client_id'] = str(uuid.uuid4())
                with open('{}/.client_id'.format(__addonpath__), 'w+') as clientfile:
                    clientfile.write(cls._instance.g['client_id'])
        except:
            pass

    @classmethod
    def saveThread(cls, target=None):
        if target:
            cls._instance.g['ThreadPool'].append(target)
            target.start()

    @classmethod
    def destroyThreads(cls):
        cls._instance.g['BreakThread'] = True
        for target in cls._instance.g['ThreadPool']:
            target.join()

    @classmethod
    def countFileSize(cls, fileSize=0):
        if not fileSize:
            return ''

        sizeFormat = ''
        filesize = int(fileSize)

        if filesize < 1000:
            return '%i' % filesize + 'B'
        elif 1000 <= filesize < 1000000:
            sizeFormat = '%.2f' % (float(filesize) / 1000)
            sizeFormat += 'KB'
        elif 1000000 <= filesize < 1000000000:
            sizeFormat = '%.2f' % (float(filesize) / 1000000)
            sizeFormat += 'MB'
        elif 1000000000 <= filesize < 1000000000000:
            sizeFormat = '%.2f' % (float(filesize) / 1000000000)
            sizeFormat += 'GB'
        elif 1000000000000 <= b:
            sizeFormat = '%.2f' % (float(filesize) / 1000000000000)
            sizeFormat += 'TB'

        return sizeFormat

    @classmethod
    def prepareGlobalLoginMsg(cls):
        loginMsg = {'HostIP': '', 'HostPort': '8080', 'User': '', 'Passwd': '', 'RememberMe': False, 'EnableSSL': False}

        for key in loginMsg.keys():
            if key in ('RememberMe', 'EnableSSL', ):
                loginValue = cls.getHomeProperty('Global.Login.{}'.format(key))
                if not loginValue:
                    loginMsg[key] = False
                else:
                    loginMsg[key] = eval(loginValue) if type(loginValue) in (str, ) else loginValue
            else:
                loginMsg[key] = cls.getHomeProperty('Global.Login.{}'.format(key))

        return loginMsg

    @classmethod
    def loginCheck(cls, loginMsg=dict(), skipHit=False):
        from lib.api.qts import QtsAPI
        from lib.api.videostation import VideoStationAPI

        loginTag = 'login'

        if loginMsg:
            msg = loginMsg
            loginTag = 'loginCheck'
        else:
            globalLoginMsg = cls.prepareGlobalLoginMsg()

            # if globalLoginMsg.get('User') and globalLoginMsg.get('Passwd') and globalLoginMsg.get('HostIP') and globalLoginMsg.get('HostPort'):
            if not all (k in globalLoginMsg for k in ('User', 'Passwd', 'HostIP', 'HostPort', )):
                msg = globalLoginMsg
                loginTag = 'loginCheck'
            else:
                msg = cls.getVideoHDConfValue()

        # if not msg.get('User') or not msg.get('HostIP') or not msg.get('HostPort') or not msg.get('Passwd'):
        if not all (k in msg for k in ('User', 'Passwd', 'HostIP', 'HostPort', )):
            g.setHomeProperty('Global.LoginRequire', 'true')
            if msg.get('Passwd') in (' ', '', ):
                return {'result': False, 'msg': {'line1': __language__(62008)}}

            return {'result': False, 'msg': None}

        '''check conn and SSL'''
        if msg.get('EnableSSL'):
            check = QtsAPI().nasCheck(msg, True)
        else:
            check = QtsAPI().nasCheck(msg)

        if not check.get('result') and loginMsg:
            if check.get('code') in ('ssl.err', ):
                if msg.get('EnableSSL'):
                    if not g.showDialog('yesno', {'line1': __language__(62009)}, {'yes': __language__(60073), 'no': __language__(60072)}):
                        return {'result': False}
                    else:
                        # Update EnableSSL temporary here.
                        cls._instance.g['EnableSSL'] = True
                else:
                    return {'result': False, 'msg': {'line1': __language__(62005)}}
            else:
                return {'result': False, 'msg': {'line1': __language__(62005)}}

        '''check account / password'''
        ret = VideoStationAPI().userLogin(msg.get('User'), msg.get('Passwd'), loginTag, msg)
        if ret.get('code') in ('ok', ):
            pass
        else:
            g.setHomeProperty('Global.LoginRequire', 'true')
            print ret
            if ret.get('code') in ('login.err', ):
                return {'result': False, 'msg': {'line1': __language__(62008)}}
            elif ret.get('code') in ('conn.err', 'ssl.err', ):
                return {'result': False, 'msg': {'line1': __language__(62005)}}
            elif ret.get('code') in ('vs.notready.err', ):
                return {'result': False, 'msg': {'line1': __language__(62007)}}
            else:
                g.log_error(ret.get('msg'))
                return {'result': False}

        '''check firmware'''
        if LooseVersion(cls._instance.g['QTSFWVersion']) < LooseVersion(FW_JUDGE_VERSION):
            g.setHomeProperty('Global.LoginRequire', 'true')
            return {'result': False, 'msg': {'line1': __language__(62006)}}
        else:
            pass

        '''check videostation ver'''
        if LooseVersion(g().get('vs_ver')) < LooseVersion(VS_JUDGE_VERSION):
            g.setHomeProperty('Global.LoginRequire', 'true')
            return {'result': False, 'msg': {'line1': __language__(62006)}}
        else:
            pass

        if not loginMsg:
            g.updateVideoHDConf(msg)

        cls.clearHomeProperty('Global.LoginRequire')
        cls.checkLocalHost()
        return {'result': True}

    @classmethod
    def getLocalHostIp(cls):
        try:
            env = cls.checkLocalEnv()
            if env in ('linux_station', ):
                # Linux station environment.
                p = subprocess.Popen(args='sudo qbus get com.qnap.qts/qts_url | jq -M .result[0]', shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                urlString = eval(p.communicate()[0])
                cls._instance.g['NASIP'] = urlString.split('//')[1].split(':')[0]
            elif env in ('hd_station', ):
                # HD station environment.
                cls._instance.g['NASIP'] = cls.getIPAddress()
            else:
                cls._instance.g['NASIP'] = ''

            if not cls._instance.g.get('HostIP'):
                cls._instance.g['HostIP'] = cls._instance.g['NASIP']
        except Exception as err:
            print 'get local host exception: ', err
            raise

    @classmethod
    def checkLocalHost(cls):
        if cls.checkLocalEnv() in ('linux_station', 'hd_station', ):
            try:
                if cls._instance.g['HostIP'] in (cls._instance.g['NASIP'], ):
                    cls._instance.g['localhost'] = True
                else:
                    cls._instance.g['localhost'] = False
            except:
                cls._instance.g['localhost'] = False
        else:
            cls._instance.g['localhost'] = False

        if cls._instance.g['localhost']:
            cls.updateThumbLocalPath()

    @classmethod
    def getVideoHDConfValue(cls):
        return {
            'User': cls._instance.g['User'],
            'Passwd': cls._instance.g['Passwd'],
            'HostIP': cls._instance.g['HostIP'],
            'HostPort': cls._instance.g['HostPort'],
            'RememberMe': cls._instance.g['RememberMe'],
            'EnableSSL': cls._instance.g['EnableSSL']
        }

    @classmethod
    def loadVideoHDConf(cls):
        confFilePath = cls._instance.g['videoHDConfPath']
        defaultConf = {'HostIP': '', 'HostPort': '8080', 'User': '', 'Passwd': '', 'RememberMe': True, 'EnableSSL': False}

        # parsing error with omitted values : http://stackoverflow.com/questions/31029768/configparser-parsing-error-with-omitted-values
        c = RawConfigParser(allow_no_value=True)
        c.optionxform = str

        try:
            c.read(confFilePath)

            if c.has_section('Common'):
                for k, v in c.items('Common'):
                    if k in ('RememberMe', 'EnableSSL', ):
                        cls._instance.g[k] = eval(v)
                    else:
                        cls._instance.g[k] = v
            else:
                c.add_section('Common')

                for k, v in defaultConf.iteritems():
                    cls._instance.g[k] = v
                    c.set('Common', k, v)

                with open(confFilePath, 'wb') as configfile:
                    c.write(configfile)
        except Exception, e:
            xbmc.log(u'loadVideoHDConf Error: {0}'.format(str(e)), xbmc.LOGERROR)

    @classmethod
    def updateVideoHDConf(cls, updateMsg=dict()):
        confFilePath = cls._instance.g['videoHDConfPath']

        rememberMe = eval(updateMsg.get('RememberMe')) if type(updateMsg.get('RememberMe')) in (str, ) else updateMsg.get('RememberMe')

        c = RawConfigParser(allow_no_value=True)
        c.optionxform = str

        try:
            c.read(confFilePath)

            if not c.has_section('Common'):
                c.add_section('Common')

            for k, v in updateMsg.iteritems():
                cls._instance.g[k] = v

                if not rememberMe:
                    if k in ('User', 'HostIP', 'HostPort', 'Passwd', ):
                        c.set('Common', k, '')
                        continue
                    elif k in ('EnableSSL', ):
                        c.set('Common', k, 'False')
                        continue

                c.set('Common', k, v)

            with open(confFilePath, 'wb') as configfile:
                c.write(configfile)
        except Exception, e:
            xbmc.log(u'Update Error: {0}'.format(str(e)), xbmc.LOGERROR)

    @classmethod
    def init(cls):
        cls.refresh()
        return cls._instance.g

    def get(self, key):
        if key in self.g:
            return self.g[key]

        return None

    def set(self, key, value):
        self.g[key] = value

        return value

    @classmethod
    def getFilterStatus(cls, videoType, which):
        return cls._instance.g['FilterStatus'][videoType][which]

    @classmethod
    def saveFilterStatus(cls, videoType, which, data=list()):
        cls._instance.g['FilterStatus'][videoType][which] = data

    @classmethod
    def tvshowinfoBg(cls, thumb=None, action=None):
        if action in ('clear', ):
            cls._instance.g['TVShowInfoBg'] = list()

        if not thumb:
            return cls._instance.g['TVShowInfoBg']

        cls._instance.g['TVShowInfoBg'].append(thumb)

    @classmethod
    def updateSortList(cls, sortType):  # for classification Other1, 2, 3, ...
        cls._instance.g['SortList'] += [sortType]

    @classmethod
    def initSortMap(cls):
        # [name, dbtime, watch, air_date, create, duration, dimensions, filesize, color, rating, collect_create, classification]
        # 1: true ; 0: false
        for member in cls._instance.g['SortList']:
            if member in ('Movie', ):
                sortMap = [1,1,1,1,0,1,1,1,1,1,0,0]
            elif member in ('TvShow', ):
                sortMap = [1,1,1,1,0,0,0,0,0,0,0,0]
            elif member in ('SmartCollection', 'VideoCollection', ):
                sortMap = [1,0,0,0,0,0,0,0,0,0,1,0]
            elif member in ('Folder', 'ShareVideo', 'VideoCollectionVideos', 'SmartCollectionVideos', ):
                sortMap = [1,1,1,0,1,1,1,1,1,1,0,1]
            else:
                sortMap = [1,1,1,0,1,1,1,1,1,1,0,0]

            cls._instance.g['SortItem'][member] = sortMap

    @classmethod
    def getSortItem(cls, typeIdx):
        sortItem = list()

        for member in cls._instance.g['SortList']:
            if cls._instance.g['SortItem'][member][typeIdx]:
                sortItem += [member]

        return sortItem

    @classmethod
    def initSortFile(cls):
        confFilePath = cls._instance.g['videoHDConfPath']
        defaultConf = {'sortBy': 'name', 'orderBy': 'DESC'}

        c = RawConfigParser(allow_no_value=True)
        c.optionxform = str

        try:
            c.read(confFilePath)

            for videoType in cls._instance.g['SortList']:
                if c.has_section(videoType):
                    if not c.has_option(videoType, 'sortBy') or not c.has_option(videoType, 'orderBy'):
                        for k, v in defaultConf.iteritems():
                            c.set(videoType, k, v)

                        with open(confFilePath, 'wb') as configfile:
                            c.write(configfile)
                else:
                    c.add_section(videoType)

                    for k, v in defaultConf.iteritems():
                        c.set(videoType, k, v)

                    with open(confFilePath, 'wb') as configfile:
                        c.write(configfile)
        except Exception, e:
            xbmc.log(u'Error: {0}'.format(str(e)), xbmc.LOGERROR)

    @classmethod
    def initSortFile_old(cls, forOther=None):
        videohdFilePath = cls._instance.g['videoHDConfPath']
        videohdFileSize = os.stat(videohdFilePath).st_size

        if forOther:
            if cls.getConfigValue(videohdFilePath, forOther, 'sortBy') in ('None', ):
                cls.setSort(forOther, sort='name')
            if cls.getConfigValue(videohdFilePath, forOther, 'orderBy') in ('None', ):
                cls.setSort(forOther, order='DESC')

            return

        if not videohdFileSize:  # videohd.conf is empty
            for sorttype in g().get('SortList'):
                cls.setSort(sorttype, sort='name')
                cls.setSort(sorttype, order='DESC')
        else:
            c = RawConfigParser()
            c.optionxform = str
            c.read(videohdFilePath)

            sortingSections = c.sections()
            for sortItem in cls._instance.g['SortList']:
                if sortItem not in sortingSections:
                    cls.setConfigValue(videohdFilePath, sortItem, 'sortBy', 'name')
                    cls.setConfigValue(videohdFilePath, sortItem, 'orderBy', 'DESC')

    @classmethod
    def initSort(cls):
        videohdFilePath = cls._instance.g['videoHDConfPath']

        c = RawConfigParser()
        c.optionxform = str

        try:
            c.read(videohdFilePath)

            for sorttype in g().get('SortList'):
                if sorttype in ('SmartCollectionVideos', 'VideoCollectionVideos', ):
                    continue
                getSortOrder = dict((key, value) for key, value in c.items(sorttype))
                updateSortOrder = {sorttype: {'sortBy': getSortOrder['sortBy'], 'orderBy': getSortOrder['orderBy']}}
                cls.saveCurrentStatus(sorttype, updateSortOrder, 'sortBy')
                cls.saveCurrentStatus(sorttype, updateSortOrder, 'orderBy')
        except Exception, e:
            xbmc.log(u'Error: {0}'.format(str(e)), xbmc.LOGERROR)

    @classmethod
    def setSort(cls, sorttype, sort=None, order=None):
        if sort:
            cls.setConfigValue(cls._instance.g['videoHDConfPath'], sorttype, 'sortBy', sort)

        if order:
            cls.setConfigValue(cls._instance.g['videoHDConfPath'], sorttype, 'orderBy', order)

    @classmethod
    def getSort(cls, sorttype):
        videohdFilePath = cls._instance.g['videoHDConfPath']

        c = RawConfigParser()
        c.optionxform = str

        try:
            c.read(videohdFilePath)
            getSortOrder = dict((key, value) for key, value in c.items(sorttype))
            return getSortOrder
        except Exception, e:
            xbmc.log(u'Error: {0}'.format(str(e)), xbmc.LOGERROR)

    @classmethod
    def getSort_old(cls, sorttype=None):
        if not sorttype:
            for sorttype in g().get('SortList'):
                g().get('GetSort')[sorttype] = dict()
                g().get('GetSort')[sorttype]['sortValue'] = cls.getConfigValue(cls._instance.g['videoHDConfPath'], sorttype, 'sortBy')
                g().get('GetSort')[sorttype]['orderValue'] = cls.getConfigValue(cls._instance.g['videoHDConfPath'], sorttype, 'orderBy')
            '''
            sortContainer = dict()
            sortContainer['sortValue'] = cls.getConfigValue(cls._instance.g['videoHDConfPath'], subtype, 'sortBy')
            sortContainer['orderValue'] = cls.getConfigValue(cls._instance.g['videoHDConfPath'], subtype, 'orderBy')

            if sortContainer['sortValue'] in ('None', ) and sortContainer['orderValue'] in ('None', ):
                return None

            return sortContainer
            '''
            return cls._instance.g['GetSort']
        else:
            sortContainer = dict()
            sortContainer['sortValue'] = g().get('GetSort')[sorttype]['sortValue']
            sortContainer['orderValue'] = g().get('GetSort')[sorttype]['orderValue']

            return sortContainer

    @classmethod
    def initCurrentStatus(cls, which, data):
        cls._instance.g['CurrentStatus'][which] = data

    @classmethod
    def getInitCurrentStatus(cls):
        return cls._instance.g['CurrentStatus']

    @classmethod
    def saveCurrentStatus(cls, which, data=dict(), key=None, layer=None, albumId=None):
        if albumId:  # for collectioninfo
            if key:
                if type(key) in (list, ):
                    for k in key:
                        cls._instance.g['CurrentStatus'][which][albumId][k] = data[which][albumId][k]
                    return

                cls._instance.g['CurrentStatus'][which][albumId][key] = data[which][albumId][key]
                return

            cls._instance.g['CurrentStatus'][which][albumId] = data[which][albumId]
            return

        if layer:  # for Folder
            if key:
                if type(key) in (list, ):
                    for k in key:
                        cls._instance.g['CurrentStatus'][which][layer][k] = data[which][layer][k]
                    return

                cls._instance.g['CurrentStatus'][which][layer][key] = data[which][layer][key]
                return

            cls._instance.g['CurrentStatus'][which][layer] = data[which][layer]
            cls._instance.g['CurrentStatus'][which]['layerStack'] = data[which]['layerStack']
            cls._instance.g['CurrentStatus'][which]['currentPrefix'] = data[which]['currentPrefix']
            cls._instance.g['CurrentStatus'][which]['sortBy'] = data[which]['sortBy']
            cls._instance.g['CurrentStatus'][which]['orderBy'] = data[which]['orderBy']
            return

        if not key:
            cls._instance.g['CurrentStatus'][which] = data[which]
            return

        if type(key) in (list, ):
            for k in key:
                cls._instance.g['CurrentStatus'][which][k] = data[which][k]
            return

        cls._instance.g['CurrentStatus'][which][key] = data[which][key]

    @classmethod
    def getCurrentStatus(cls, which=None, key=None, layer=None, albumId=None):
        if layer:
            if layer in ('layerStack', ):
                return cls._instance.g['CurrentStatus'][which]['layerStack']

            if key:
                return cls._instance.g['CurrentStatus'][which][layer][key]

            return cls._instance.g['CurrentStatus'][which][layer]

        if not which:
            return cls._instance.g['CurrentStatus']

        if not key:
            if albumId:
                return cls._instance.g['CurrentStatus'][which][albumId]

            return cls._instance.g['CurrentStatus'][which]

        if albumId:
            return cls._instance.g['CurrentStatus'][which][albumId][key]

        return cls._instance.g['CurrentStatus'][which].get(key)

    @classmethod
    def setInfoData(cls, key, items=dict(), action=None):
        if 'InfoDataContainer' not in cls._instance.g:
            cls._instance.g['InfoDataContainer'] = dict()

        # default key: items, total, current, currentPage, sort, DESCASC
        if key not in cls._instance.g['InfoDataContainer']:
            cls._instance.g['InfoDataContainer'][key] = {'items': list(), 'total': None, 'currentItemLength': 0, 'currentPage': 0, 'sortBy': None, 'orderBy': None}

        for valueKey in items.keys():
            if valueKey in ('total', 'currentPage', ):
                cls._instance.g['InfoDataContainer'][key][valueKey] = items[valueKey]
            else:
                if action in ('init', ):
                    cls._instance.g['InfoDataContainer'][key][valueKey] = items[valueKey]
                else:
                    cls._instance.g['InfoDataContainer'][key][valueKey] += items[valueKey]

    @classmethod
    def getInfoData(cls, key):
        return cls._instance.g['InfoDataContainer'][key]

    @classmethod
    def settingProperty(cls, propertyContent=None, where=None, videoType=None):
        content = dict()
        for key in propertyContent.keys():
            if key in ('offset', ):
                content[key] = propertyContent[key]
            else:
                content[key] = cls.ensureUTF8(propertyContent[key])

        target = xbmcgui.ListItem(content.get('title'), content.get('subTitle'), '', content.get('thumbnail'))
        # target.setArt({'thumb': content.get('thumbnail')})

        target.setProperty('id', content.get('id'))
        target.setProperty('filename', content.get('filename'))
        target.setProperty('prefix', content.get('prefix'))
        target.setProperty('thumbnail', content.get('thumbnail'))
        target.setProperty('duration', content.get('duration'))
        target.setProperty('length', content.get('length'))
        target.setProperty('length.display', content.get('length'))

        '''video info'''
        target.setProperty('videoinfomask', content.get('videoinfomask'))
        target.setProperty('colorlevel', content.get('colorLevelInfo'))
        target.setProperty('rating', content.get('ratingInfo'))
        target.setProperty('classification', content.get('classification'))
        target.setProperty('videotag', content.get('tagInfo'))
        target.setProperty('description', content.get('description') if content.get('description') else '--')
        target.setProperty('filesize', content.get('filesizeInfo'))
        target.setProperty('resolution', content.get('dimensionsInfo'))
        # target.setProperty('transcoded', content.get('transcodedInfo'))
        target.setProperty('videocodec', content.get('videocodec'))
        target.setProperty('audiocodec', content.get('audiocodec'))
        target.setProperty('filetype', content.get('typeInfo'))
        target.setProperty('filepath', content.get('pathInfo'))
        target.setProperty('extIDBId', content.get('extIDBId'))
        target.setProperty('extIDBName', cls.getIDBNameMapping(content.get('extIDBId')))

        target.setContentLookup(False)
        target.setMimeType(mimetype=content.get('typeInfo'))

        if content.get('offset'):
            t_transfer = cls.timeTransfer(eval(content.get('offset')))
            s_time = cls.showTime(t_transfer)
            target.setProperty('offset', s_time)
            target.setProperty('offset_pure', content.get('offset'))
        else:
            target.setProperty('offset', cls.showTime(cls.timeTransfer()))
            target.setProperty('offset_pure', '0')

        if where in ('classification', ):
            target.setProperty('videoType', videoType)

            if videoType in ('1', '2', ):
                target.setProperty('poster', content.get('poster'))
                target.setProperty('rate', content.get('rate'))
                # target.setProperty('description', content.get('description'))
                target.setProperty('genre', content.get('genre'))
                target.setProperty('year', content.get('year'))
                target.setProperty('actors', content.get('actors'))

                if videoType in ('1', ):
                    target.setProperty('director', content.get('director'))
                    # target.setProperty('total.length', content.get('length'))
                    # target.setProperty('length', content.get('length'))
                elif videoType in ('2', ):
                    target.setProperty('TVShowName', content.get('title'))
                    target.setProperty('seasons', content.get('seasons'))
                    target.setProperty('creator', content.get('creator'))
                    target.setProperty('recently_play_id', content.get('recently_play_id'))
                    target.setProperty('recently_play_progress', content.get('recently_play_progress'))
                    target.setProperty('recently_play_season', content.get('recently_play_season'))
                    target.setProperty('recently_play_season_order', content.get('recently_play_season_order'))
        elif where in ('recently', 'history', 'collection', ):
            if where in ('collection', ):
                # target.setProperty('total', content.get('total'))
                target.setProperty('total.counts', content.get('total'))
                target.setProperty('collect.type', content.get('collectType'))

                target.setProperty('albumId', content.get('albumId'))
                target.setProperty('albumTitle', content.get('albumTitle'))
            elif where in ('recently', 'history', ):
                target.setProperty('type', content.get('type'))
                '''target.setProperty('position', content.get('position'))'''

                if where in ('recently', ):
                    pass
                    # target.setProperty('length', content.get('length'))
                elif where in ('history', ):
                    if target.getProperty('offset') in (content.get('length'), ):
                        lengthOffset = __language__(60021)
                    else:
                        lengthOffset = '{0} / {1}'.format(target.getProperty('offset'), content.get('length'))
                    target.setProperty('length.display', lengthOffset)
        elif where in ('folder', ):
            target.setProperty('folder.type', content.get('MediaType'))
            target.setProperty('isMediafolder', content.get('isMediafolder'))
        elif where in ('tvshowinfo', ):
            target.setProperty('total.length', content.get('length'))
            target.setProperty('season', content.get('season'))
            target.setProperty('episode', content.get('episode'))
            target.setProperty('bookmark.offset', target.getProperty('offset'))
            '''
            target.setProperty('season.episode', __language__(60022) % (
                content.get('season'),
                content.get('episode')
            ))

            target.setProperty('season', content.get('season'))
            target.setProperty('episode', content.get('episode'))

            target.setProperty('rate', content.get('rate'))
            target.setProperty('description', content.get('description'))
            target.setProperty('genre', content.get('genre'))
            target.setProperty('year', content.get('year'))
            target.setProperty('actors', content.get('actors'))
            '''
        elif where in ('collectioninfo', ):
            pass

        return target

    @classmethod
    def timeTransfer(cls, time=0):
        timeContainer = dict()
        timeContainer['hour'] = int(time // 3600) if time // 3600 else 0
        timeContainer['minute'] = int((time - (3600 * timeContainer['hour'])) // 60) if (time - (3600 * timeContainer['hour'])) // 60 else 0
        timeContainer['second'] = int(time % 60) if time % 60 else 0

        return timeContainer

    @classmethod
    def showTime(self, timeContent=None):
        hour, minute, second = ('00', '00', '00')

        try:
            if 'hour' in timeContent:
                # showTime = u'{}'.format(timeContent.get('hour'))
                if len(str(timeContent.get('hour'))) < 2:
                    hour = '0{}'.format(timeContent.get('hour'))
                else:
                    hour = timeContent.get('hour')

            if 'minute' in timeContent:
                if len(str(timeContent.get('minute'))) < 2:
                    minute = '0{}'.format(timeContent.get('minute'))
                else:
                    minute = timeContent.get('minute')

            if 'second' in timeContent:
                if len(str(timeContent.get('second'))) < 2:
                    second = '0{}'.format(timeContent.get('second'))
                else:
                    second = timeContent.get('second')
        except:
            pass

        return __language__(60023) % (hour, minute, second)

    @classmethod
    def sizeConverter(cls, byteSize):
        from hurry.filesize import size, alternative
        return size(byteSize if type(byteSize) in (int, ) else int(byteSize), system=alternative)

    @classmethod
    def judgeFile(cls, path):
        if not os.path.exists(path):
            return False
        elif os.path.getsize(path) in (0, ):
            return False

        return True

    @classmethod
    def getFuncName(cls):
        return inspect.getouterframes(inspect.currentframe(), 2)[1][3]

    @classmethod
    def getImageLocalPath(cls, thumbType=None, objId=None, posterPath=None, firstVideoId=None):
        if thumbType in ('poster', 'episode', ):
            thumbId = '3'
        elif thumbType in ('large', 'tvshow.poster', ):
            thumbId = None
        elif thumbType in ('median', ):
            thumbId = '1'
        elif thumbType in ('small', ):
            thumbId = '2'

        if cls._instance.g.get('localhost'):
            image = pathDecoder().decode(objId, thumbId)

            if thumbType in ('tvshow.poster', ):
                path = u'{0}{1}'.format(g().get('TVShow_Thumbnail_Path'), image.split('/').pop())
            else:
                path = u'{0}{1}'.format(g().get('Thumbnail_Path'), image)

            if cls.judgeFile(path):
                return r'{0}'.format(path)
            else:
                if firstVideoId and thumbType in ('tvshow.poster', ):
                    thumb = cls.getImageLocalPath('median', firstVideoId)
                    if thumb in (u'', ):
                        return u'empty_poster.png'
                    else:
                        return thumb
                elif thumbType in ('poster', ):
                    thumb = cls.getImageLocalPath('median', objId)
                    if thumb in (u'', ):
                        return u'empty_poster.png'
                    else:
                        return thumb

                return u''
        else:
            thumbUrl = '{0}/video/api/thumb.php?m=display&t=video&f={1}&sid={2}'
            postUrl = '{0}/video/api/thumb.php?m=display&t={1}&f={2}&sid={3}'

            if thumbType in ('poster', 'tvshow.poster', ):
                target = 'tv' if thumbType in ('tvshow.poster', ) else 'poster'

                if posterPath:
                    return postUrl.format(cls.urlPrefix(), target, posterPath, cls._instance.g['sid'])
                else:
                    if firstVideoId and thumbType in ('tvshow.poster', ):
                        return thumbUrl.format(cls.urlPrefix(), firstVideoId, cls._instance.g['sid'])

                    return thumbUrl.format(cls.urlPrefix(), objId, cls._instance.g['sid'])
            else:
                if objId:
                    return thumbUrl.format(cls.urlPrefix(), objId, cls._instance.g['sid'])
                else:
                    return u''

    @classmethod
    def ensureUnicode(cls, v):
        if isinstance(v, str):
            v = v.decode('utf-8')

        return unicode(v)

    @classmethod
    def ensureUTF8(cls, v):
        return cls.ensureUnicode(v).encode('utf-8')

    @classmethod
    def fullPath(cls, listitem):
        from lib.api.videostation import VideoStationAPI
        if not listitem.getProperty('prefix') or not listitem.getProperty('filename'):
            return None

        prefix = cls.ensureUnicode(listitem.getProperty('prefix'))
        filename = cls.ensureUnicode(listitem.getProperty('filename'))

        if cls._instance.g['localhost']:
            if os.path.exists('/opt/bin/alicego'):
                return u'/share/{0}{1}'.format(prefix, filename)
            else:
                return u'/share2/{0}{1}'.format(prefix, filename)

        # return u'smb://{0}:{1}@{2}/{3}{4}'.format(g().get('User'), g().get('Passwd'), g().get('HostIP'), prefix, filename)
        return VideoStationAPI().genConvertUrl(listitem.getProperty('id'))

    @classmethod
    def log_error(cls, msg):
        xbmc.log('[VideoHD] {0}'.format(msg if type(msg) in (str, ) else str(msg)), xbmc.LOGERROR)

    @classmethod
    def log_debug(cls, file_name=None, class_name=None, function_name=None, line=None, msg=None):
        if not os.path.exists(u'{}/debug'.format(__addonpath__)):
            return

        if type(msg) not in (str, unicode, ):
            msg = str(msg)

        if class_name:
            xbmc.log(u'\033[1;32;40m file:{0} class:{1} func:{2} line:{3} msg:\033[1;33;40m{4} \033[0m'.format(file_name, class_name, function_name, line, cls.ensureUnicode(msg)).encode('utf-8'), xbmc.LOGNOTICE)
            # xbmc.log(u'\033[1;32;40m [{0}:{1}()] {2} \033[0m'.format(class_name, function_name, cls.ensureUnicode(msg)).encode('utf-8'), xbmc.LOGNOTICE)
        else:
            xbmc.log(u'\033[1;32;40m file:{0} func:{1} line:{2} msg:\033[1;33;40m{3} \033[0m'.format(file_name, function_name, line, cls.ensureUnicode(msg)).encode('utf-8'), xbmc.LOGNOTICE)
            # xbmc.log(u'\033[1;32;40m @2 [{0}] {1} \033[0m'.format(function_name, cls.ensureUnicode(msg)).encode('utf-8'), xbmc.LOGNOTICE)

    @classmethod
    def urlPrefix(cls, data=dict()):
        if data:
            protocol = 'https' if data.get('EnableSSL') else 'http'
            return u'{0}://{1}:{2}'.format(protocol, data.get('HostIP'), data.get('HostPort'))

        protocol = 'https' if cls._instance.g['EnableSSL'] else 'http'
        return u'{0}://{1}:{2}'.format(protocol, cls._instance.g['HostIP'], cls._instance.g['HostPort'])

    @classmethod
    def showDialog(cls, dialogType='ok', strMsg=dict(), buttonMsg=dict(), dialogTitle=None, selectList=None):
        if dialogType == 'ok':
            return xbmcgui.Dialog().ok(
                __language__(60000 if dialogTitle is None else dialogTitle),
                strMsg['line1'] if 'line1' in strMsg else '',
                strMsg['line2'] if 'line2' in strMsg else '',
                strMsg['line3'] if 'line3' in strMsg else ''
            )
        elif dialogType == 'yesno':
            return xbmcgui.Dialog().yesno(
                __language__(60000 if dialogTitle is None else dialogTitle),
                strMsg['line1'] if 'line1' in strMsg else '',
                strMsg['line2'] if 'line2' in strMsg else '',
                strMsg['line3'] if 'line3' in strMsg else '',
                buttonMsg['yes'] if 'yes' in buttonMsg else __language__(60072),
                buttonMsg['no'] if 'no' in buttonMsg else __language__(60073)
            )
        elif dialogType == 'select':
            cls.setHomeProperty('select.resume', 'True')
            ret = xbmcgui.Dialog().select(
                __language__(60000 if dialogTitle is None else dialogTitle),
                selectList
            )
            cls.clearHomeProperty('select.resume')

            return ret
        elif dialogType == 'notification':
            return xbmcgui.Dialog().notification(
                __language__(60000 if dialogTitle is None else dialogTitle),
                strMsg['line1'] if 'line1' in strMsg else '',
                strMsg['icon'] if 'icon' in strMsg else xbmcgui.NOTIFICATION_INFO,
                strMsg['time'] if 'time' in strMsg else 5000,
                strMsg['sound'] if 'sound' in strMsg else True
            )

    @classmethod
    def secToTimeFormat(cls, sec):
        if type(sec) not in (int, ):
            sec = int(float(sec))

        hour = sec / 3600
        minute = sec / 60 - hour * 60
        realSec = sec - hour * 3600 - minute * 60

        if hour > 0:
            if realSec < 10:
                realSec = '0{0}'.format(realSec)
            if minute < 10:
                minute = '0{0}'.format(minute)
            return '{0}:{1}:{2}'.format(hour, minute, realSec)
        elif minute > 0:
            if realSec < 10:
                realSec = '0{0}'.format(realSec)
            return '{0}:{1}'.format(minute, realSec)
        else:
            if realSec < 10:
                realSec = '0{0}'.format(realSec)
            return '00:{0}'.format(realSec)

    @classmethod
    def paginateInfo(self, count, total):
        paginate = [i for i in range(0, total, count)]
        return len(paginate)

    @classmethod
    def fmtToDate(cls, timestamp):
        if type(timestamp) not in (float, ):
            timestamp = float(timestamp)

        date = datetime.datetime.fromtimestamp(timestamp)
        return date.strftime('%Y-%m-%d %H:%M')

    @classmethod
    def encode(cls, unicode_str):
        return unicode_str.encode('utf-8')

    @classmethod
    def getConfigValue(cls, path, section, option, def_val=None):
        # parsing error with omitted values : http://stackoverflow.com/questions/31029768/configparser-parsing-error-with-omitted-values
        c = RawConfigParser(allow_no_value=True)

        c.optionxform = str
        c.read(path)

        if c.has_section(section) and c.has_option(section, option):
            return c.get(section, option)

        return def_val

    @classmethod
    def setConfigValue(cls, path, section, option, value=None):
        # parsing error with omitted values : http://stackoverflow.com/questions/31029768/configparser-parsing-error-with-omitted-values
        c = RawConfigParser(allow_no_value=True)

        c.optionxform = str
        c.read(path)

        if not c.has_section(section):
            c.add_section(section)

        c.set(section, option, value)

        with open(path, 'wb') as configfile:
            c.write(configfile)

    @classmethod
    def setWaitingMask(cls, window=None, state=None, focusId=None, msg=__language__(60028)):
        """Set waiting mask.

        Args:
            window (WindowXML/WindowXMLDialog): curren windown object
            state (str): init/on/off
            focusId (int): button control ID of Specified focus control after close waiting mask.
            msg (str): message when waiting mask is on.
        Returns:
            int: return focusId
        """
        if window:
            cls._instance.g['currenWin'] = window
        else:
            window = cls._instance.g['currenWin']

        if state in ('off', 'init', ):
            window.getControl(ID.val('Global.Waiting.Mask.Group')).setVisible(False)
            window.getControl(ID.val('Global.Empty.Button')).setVisible(False)
            window.getControl(ID.val('Global.Waiting.Mask.Label')).setLabel('')

            if state in ('off', ):
                if focusId:
                    window.setFocusId(focusId)
        else:
            window.getControl(ID.val('Global.Waiting.Mask.Label')).setLabel(msg)
            xbmc.sleep(200)

            window.getControl(ID.val('Global.Empty.Button')).setVisible(True)
            window.getControl(ID.val('Global.Waiting.Mask.Group')).setVisible(True)

            window.setFocusId(ID.val('Global.Empty.Button'))

        return focusId

    @classmethod
    def updateIPAddress(cls, window):
        window.getControl(ID.val('Global.IP.Label')).setLabel(cls.getIPAddress())

    @classmethod
    def updateModelName(cls, window):
        window.getControl(ID.val('Global.Machine.Label')).setLabel(cls._instance.g['Server_Name'])

    @classmethod
    def getIPAddress(cls):
        gwCheck = cls.getConfigValue(
            QTS_ULINUX_PATH, 'Network', 'Default GW Device', 'eth0')

        cmd = u'/opt/bin/alicego "/sbin/br_util --list_if | grep {0} | cut -d \'=\' -f 2"'.format(gwCheck)
        bashcmd = ['bash', '-c', cmd]
        result = subprocess.Popen(bashcmd, stdout=subprocess.PIPE)

        br0Check = result.communicate()[0].splitlines()
        if len(br0Check) > 1 and br0Check[1]:
            br0Content = br0Check[1].split(':')[1].strip()

            if br0Content in ('br0', ):
                gwCheck = br0Content

        p = subprocess.Popen(
            args='/sbin/ifconfig {} | grep "inet addr" | cut -f 2 -d \':\' | cut -f 1 -d \' \''.format(
                gwCheck),
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        ).communicate()[0].splitlines()

        return p[0]

    @classmethod
    def getViewType(cls, view):
        if view in ('Movie', 'TvShow', 'MusicVideo', 'HomeVideo', 'KTV', 'Uncategory', 'Other1', 'Other2', 'Other3', 'Other4', 'Other5', 'Other6', 'Other7', 'Other8', 'Other9', 'Other10', 'Other11', 'Other12', 'Other13', 'Other14', 'Other15', 'Other16', ):
            return 'Classification'
        elif view in ('RecentlyImported', 'RecentlyWatched', 'ShareVideo', 'Folder'):
            return 'Management'
        elif view in ('VideoCollection', 'SmartCollection', ):
            return 'Collection'
        elif view in ('SmartCollectionVideos', 'VideoCollectionVideos', ):
            return 'CollectionInfo'
        else:
            return None

    @classmethod
    def getCurrenViewLanguageMapping(cls):
        languageMapping = {
            'Uncategory': __language__(60015),
            'Movie': __language__(60010),
            'TvShow': __language__(60011),
            'MusicVideo': __language__(60012),
            'HomeVideo': __language__(60013),
            'KTV': __language__(60014),
            'RecentlyImported': __language__(60005),
            'RecentlyWatched': __language__(60004),
            'ShareVideo': __language__(60006),
            'Folder': __language__(60007),
            'VideoCollection': __language__(60008),
            'SmartCollection': __language__(60009),
            'VideoCollectionVideos': __language__(60008),
            'SmartCollectionVideos': __language__(60009)}

        currentView = cls.getHomeProperty('Browse.CurrentView')
        if currentView in languageMapping:
            return languageMapping[cls.getHomeProperty('Browse.CurrentView')]
        else:
            return cls.getHomeProperty('Browse.Classification.{}'.format(currentView))

    @classmethod
    def getIDBNameMapping(cls, extIDBId):
        iDBNameMapping = {
            'tvdb': u'TheTVDB',
            'tmdbtv': u'TMDb',
            'imdb': u'IMDb',
            'tmdb': u'TMDb',
            'atmoviescraper': u'開眼電影網'
        }

        if not extIDBId or extIDBId in ('None', ):
            return '--'

        idbId = extIDBId.split(':')[0]
        if idbId not in iDBNameMapping:
            return idbId
        else:
            return iDBNameMapping[idbId]

    @classmethod
    def setDownloadSubtitleFile(cls, name):
        from lib.api.videostation import VideoStationAPI

        # Download subtitle file in tmp folder.
        srtPath = u'{}/tmp/{}.srt'.format(__addonpath__, cls.ensureUnicode(name))
        f = xbmcvfs.File(srtPath, 'w')
        f.write(VideoStationAPI().getSubtitle(cls._instance.g['player'].getCurrentPlayItem().getProperty('id'), name))

        cls.setHomeProperty('Player.subtitle', name)
        cls._instance.g['player'].setSubtitles(cls.ensureUTF8(srtPath))
        VideoStationAPI().setPlayProgress(cls._instance.g['player'].getCurrentPlayItem().getProperty('id'))

    @classmethod
    def setHomeProperty(cls, key, value):
        cls._instance.winId.setProperty(key, value)

    @classmethod
    def getHomeProperty(cls, key):
        try:
            return cls._instance.winId.getProperty(key)
        except:
            return None

    @classmethod
    def clearHomeProperty(cls, key):
        cls._instance.winId.clearProperty(key)

    @classmethod
    def clearTmpSrtDir(cls):
        filelist = [f for f in os.listdir('{0}/tmp/'.format(__addonpath__)) if f.endswith(".srt")]
        for f in filelist:
            os.remove('{0}/tmp/{1}'.format(__addonpath__, f))

    @classmethod
    def stopVideoHD(cls, shutdown=True):
        cls.clearHomeProperty('Main.ShowSettingsControl')

        cls._instance.g['bgTask'].destroy()

        if shutdown:
            cls.clearTmpSrtDir()
            cls.setHomeProperty('VideoHD.Status', 'shutdown')
            xbmc.executebuiltin('Quit')

        cls.destroyThreads()

class ID(object):

    keymapping = {
        # Global Control
        'Global.Waiting.Mask.Group': 10990,
        'Global.Waiting.Mask.Label': 10991,
        'Global.Empty.Button': 10992,

        # Home Page
        'Home.Help.Button': 20102,
        'Home.Exit.Button': 20103,
        'Home.Classification.Fixedlist': 20104,
        'Home.Poster.Wraplist': 20105,
        'Home.Thumbnail.Wraplist': 20106,
        'Home.Classification.Button': 20107,
        'Home.Management.Panel': 20108,
        'Home.Collection.Panel': 20109,
        'Home.Account.Button': 20110,
        'Home.Settings.Button': 20111,
        'Home.Login.Button': 20112,
        'Home.PlayerSetting.Button': 20113,
        'Home.InterfaceSetting.Button': 20114,
        'Home.SettingsMask.Button': 20115,
        'Home.Toolbar.Grouplist': 20116,
        'Home.Settings.Grouplist': 20117,

        # Browse Page
        'Browse.Item.Label': 20203,
        'Browse.SubMenu.Label': 20209,
        'Browse.Sidemenu.Button': 20201,
        'Browse.More.Button': 20204,
        'Browse.Home.Button': 20205,
        'Browse.Help.Button': 20206,
        'Browse.Exit.Button': 20207,
        'Browse.Classification.Movie.Button': 40101,
        'Browse.Classification.TvShow.Button': 40102,
        'Browse.Classification.MusicVideo.Button': 40103,
        'Browse.Classification.HomeVideo.Button': 40104,
        'Browse.Classification.KTV.Button': 40105,
        'Browse.Classification.Uncategory.Button': 40106,
        'Browse.Classification.Other1.Button': 40107,
        'Browse.Classification.Other2.Button': 40108,
        'Browse.Classification.Other3.Button': 40109,
        'Browse.Classification.Other4.Button': 40110,
        'Browse.Classification.Other5.Button': 40111,
        'Browse.Classification.Other6.Button': 40112,
        'Browse.Classification.Other7.Button': 40113,
        'Browse.Classification.Other8.Button': 40114,
        'Browse.Classification.Other9.Button': 40115,
        'Browse.Classification.Other10.Button': 40116,
        'Browse.Classification.Other11.Button': 40117,
        'Browse.Classification.Other12.Button': 40118,
        'Browse.Classification.Other13.Button': 40119,
        'Browse.Classification.Other14.Button': 40120,
        'Browse.Classification.Other15.Button': 40121,
        'Browse.Classification.Other16.Button': 40122,

        'Browse.ResetFilterStatus.Button': 20217,
        'Browse.PreviousFolder.Button': 20218,
        'Browse.Poster.Panel': 20211,
        'Browse.Thumbnail.Panel': 20212,
        'Browse.Collection.Panel': 20213,
        'Browse.Folder.Panel': 20214,

        'Browse.More.Refresh.Button': 40501,
        'Browse.More.Sorting.Button': 40502,
        'Browse.More.Filter.Button': 40503,

        # Folder Page
        'Folder.Layer1.Button': 40201,
        'Folder.Layer2.Button': 40202,
        'Folder.Layer3.Button': 40203,
        'Folder.Layer4.Button': 40204,
        'Folder.Layer5.Button': 40205,
        'Folder.Layer6.Button': 40206,

        # Sidemenu Dialog
        'Sidemenu.Movie.Button': 41101,
        'Sidemenu.TvShow.Button': 41102,
        'Sidemenu.MusicVideo.Button': 41103,
        'Sidemenu.HomeVideo.Button': 41104,
        'Sidemenu.KTV.Button': 41105,
        'Sidemenu.Uncategory.Button': 41106,
        'Sidemenu.Other1.Button': 41107,
        'Sidemenu.Other2.Button': 41108,
        'Sidemenu.Other3.Button': 41109,
        'Sidemenu.Other4.Button': 41110,
        'Sidemenu.Other5.Button': 41111,
        'Sidemenu.Other6.Button': 41112,
        'Sidemenu.Other7.Button': 41113,
        'Sidemenu.Other8.Button': 41114,
        'Sidemenu.Other9.Button': 41115,
        'Sidemenu.Other10.Button': 41116,
        'Sidemenu.Other11.Button': 41117,
        'Sidemenu.Other12.Button': 41118,
        'Sidemenu.Other13.Button': 41119,
        'Sidemenu.Other14.Button': 41120,
        'Sidemenu.Other15.Button': 41121,
        'Sidemenu.Other16.Button': 41122,
        'Sidemenu.RecentlyImported.Button': 41201,
        'Sidemenu.RecentlyWatched.Button': 41202,
        'Sidemenu.ShareVideo.Button': 41203,
        'Sidemenu.Folder.Button': 41204,
        'Sidemenu.VideoCollection.Button': 41301,
        'Sidemenu.SmartCollection.Button': 41302,

        # Playercontrol Dialog
        'Playercontrol.Mask.Button': 30201,
        'Playercontrol.Playlist.Fixedlist': 30202,
        'Playercontrol.Exit.Button': 30203,
        'Playercontrol.Exit.Label': 30204,
        'Playercontrol.Bookmarks.Button': 40301,
        'Playercontrol.ShowSubtitles.Button': 40302,
        'Playercontrol.Settings.Button': 40303,
        'Playercontrol.Rewind.Button': 40401,
        'Playercontrol.PlayPause.Button': 40402,
        'Playercontrol.FastForward.Button': 40403,
        'Playercontrol.Progress.Slider': 30206,
        'Playercontrol.Settings.Panel': 30210,
        'Playercontrol.ResumeCheck.Grouplist': 30211,
        'Playercontrol.Resume.Button': 40801,
        'Playercontrol.Restart.Button': 40802,
        'Playercontrol.NextNotify.Count.Label': 30212,
        'Playercontrol.NextNotify.Grouplist': 30213,
        'Playercontrol.NextNotify.Back.Button': 40901,
        'Playercontrol.NextNotify.More.Button': 40902,
        'Playercontrol.Subtitles.Enable.Button': 41001,
        'Playercontrol.Subtitles.Toggle.Button': 41002,
        'Playercontrol.Subtitles.OnlineSubtitle.Button': 41003,
        'Playercontrol.Subtitles.Import.Button': 41004,
        'Playercontrol.Subtitles.OnlineSearch.Button': 41005,

        # Bookmarks Dialog
        'Bookmarks.Exit.Button': 30301,
        'Bookmarks.Panel': 30303,

        # Movieinfo
        'Movieinfo.Playlist.Fixedlist': 30402,
        'Movieinfo.Back.Button': 30401,
        'Movieinfo.Play.Button': 30405,
        'Movieinfo.Description.Button': 30406,
        'Movieinfo.Play.Label': 30407,

        # Movieinfo Description
        'Description.Back.Button': 31001,
        'Description.Title.Label': 31002,
        'Description.Description.Textbox': 31003,

        # TVShowinfo
        'TVShowInfo.Info.Fixedlist': 30501,
        'TVShowInfo.Poster.Button': 30502,
        'TVShowInfo.Seasonlist.Fixedlist': 30503,
        'TVShowInfo.Back.Button': 30504,
        'TVShowInfo.Description.Button': 30505,
        'TVShowInfo.TVShowlist.Panel': 30506,
        'TVShowInfo.PlayButton.Label': 30507,

        # Sorting Dialog
        'Sorting.Name.Button': 40601,
        'Sorting.Classification.Button': 40602,
        'Sorting.DBTime.Button': 40603,
        'Sorting.Watch.Button': 40604,
        'Sorting.Air_Date.Button': 40605,
        'Sorting.Create.Button': 40606,
        'Sorting.Duration.Button': 40607,
        'Sorting.Dimensions.Button': 40608,
        'Sorting.Filesize.Button': 40609,
        'Sorting.Color.Button': 40610,
        'Sorting.Rating.Button': 40611,
        'Sorting.CreateDate.Button': 40612,

        # Filter Dialog
        'Filter.Year.Up.Button': 30701,
        'Filter.Year.Down.Button': 30702,
        'Filter.Year.Panel': 30703,
        'Filter.Genre.Up.Button': 30704,
        'Filter.Genre.Down.Button': 30705,
        'Filter.Genre.Panel': 30706,

        # Login Dialog
        'Login.HostIP.Button': 30901,
        'Login.User.Button': 30902,
        'Login.Passwd.Button': 30903,
        'Login.HostPort.Button': 30904,
        'Login.RememberMe.Radiobutton': 30905,
        'Login.EnableSSL.Radiobutton': 30906,
        'Login.Cancel.Button': 30907,
        'Login.LoginCheck.Button': 30908,
        'Login.Search.Button': 30909,

        # Videoinfo
        'VideoInfo.Back.Button': 31101,
        'VideoInfo.Color.Image': 31102,
        'VideoInfo.Rating.Image': 31103,
        'VideoInfo.Tag.Panel': 31104,
        'VideoInfo.Play.Button': 31105,
        'VideoInfo.Videolist.Panel': 31106,
        'VideoInfo.BackTitle.Label': 31107,
        'VideoInfo.Play.Label': 31108,

        # Subtitles
        'Subtitles.Back.Button': 31201,
        'Subtitles.Back.Label': 31202,
        'Subtitles.Enable.Button': 31204,
        'Subtitle.List.Panel': 31206,
        'Subtitle.Search.Button': 31208,
        'Subtitle.SearchResult.Panel': 31210,

        # Finder
        'Finder.NasList.Panel': 31301,
        'Finder.Refresh.Button': 31302,
        'Finder.NotFound.Refresh.Button': 31306,
        'Finder.NotFound.Back.Button': 31307,
        'Finder.Searching.Back.Button': 31308,
    }

    @classmethod
    def groupID(cls, prefix):
        groupKey = [key for key in cls.keymapping.keys() if prefix in key]
        return [cls.keymapping[key] for key in groupKey]

    @classmethod
    def val(cls, text):
        if text in cls.keymapping:
            return cls.keymapping[text]
        else:
            return None

    @classmethod
    def key(cls, targetId):
        for key, value in cls.keymapping.items():
            if targetId in (value, ):
                return key


class ACTION(object):

    keymapping = {
        'PREVIOUS_MENU': 10,
        'INFO': 11,
        'LEFT': 1,
        'RIGHT': 2,
        'UP': 3,
        'DOWN': 4,
        'PAGEDOWN': 6,
        'SELECT': 7,
        'BACK': 92,
        'CONTEX_MENU': 117,
        'HOME': 215,  # Red button.
        'HELP_BUTTON': 217,  # Yellow button
        'EXIT_BUTTON': 218,  # Blue button
        'MOUSE_LEFT_CLICK': 100,
        'MOUSE_RIGHT_CLICK': 101,
        'MOUSE_WHEEL_UP': 104,
        'MOUSE_WHEEL_DOWN': 105,
        'MOUSE_DRAG': 106,
        'MOUSE_MOVE': 107,
        'MOUSE_WHEEL_CLICK': 102,
        'UNIVERSAL': 999,
    }

    @classmethod
    def val(cls, text):
        if text in cls.keymapping:
            return cls.keymapping[text]
        else:
            return None

    @classmethod
    def groupID(cls, prefix):
        groupKey = [key for key in cls.keymapping.keys() if prefix in key]
        return [cls.keymapping[key] for key in groupKey]
