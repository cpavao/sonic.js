# -*- coding: utf-8 -*-
"""VideoStation API."""
import base64
import urllib
import traceback

import requests

from lib import g
from lib.utils.httpRequest import HTTPRequest
from lib.static import *

class VideoStationAPI(HTTPRequest):

    """VideoStation API Class."""
    def __init__(self):
        self.testing = True

    def _url(self, which, data=dict()):
        return u'{0}/video/api/{1}.php'.format(g.urlPrefix(), which)

    def updateUserEnv(self, action='login'):
        ret = self.request('GET', self._url('user'), params={}, action=action)

        if ret.get('r'):
            data = ret.get('d')

            try:
                if data.get('status') in (1, ):
                    g().set('usr_home', data.get('usr_home'))
            except Exception:
                g.log_error(ret)
                g.log_error(traceback.format_exc())

    def userLogin(self, account, passwd, action='login', data=dict()):
        u"""登入VideoStation, 並取得sid."""
        try:
            ret = self.request('GET', self._url('user', data), params={'a': 'login', 'u': account, 'p': base64.b64encode(passwd)}, action=action)

            if ret.get('r'):
                data = ret.get('d')

                if data.get('status') in (1, ):
                    g().set('sid', data.get('sid'))
                    g().set('usr_home', data.get('usr_home'))
                    g().set('vs_ver', data.get('appVersion'))
                    g().set('QTSFWVersion', data.get('builtinFirmwareVersion'))
                else:
                    return {'code': 'login.err'}

                return {'code': 'ok'}
            else:
                if ret.get('httpcode') in (VIDEOSTATION_DISABLE, VIDEOSTATION_UNINSTALL, ):
                    return {'code': 'vs.notready.err'}

                g.log_error('[userLogin] ({}): {}'.format(ret.get('httpcode'), ret.get('e')))
                return {'code': 'unknwon.err'}
        except requests.ConnectionError as e:
            if 'ssl' in str(e):
                return {'code': 'ssl.err', 'msg': 'SSL require error.'}
            return {'code': 'conn.err', 'msg': 'Connection error.'}
        except requests.exceptions.Timeout as e:
            return {'code': 'timeout.err', 'msg': 'requests timeout'}
        except Exception:
            return {'code': 'except.err', 'msg': traceback.format_exc()}

    def initClassifyListPanel(self):
        resp = {'subtypelist': list(), 'counts': 0}

        ret = self.request('GET', self._url('utility'), params={'a': 'get_full_subtype_list', 'sid': g().get('sid')})

        if ret.get('r'):
            data = ret.get('d')

            if data.get('subtypelist'):
                resp['subtypelist'] = data.get('subtypelist')
                resp['counts'] = len(data.get('subtypelist'))
        else:
            g.log_error(ret.get('e'))

        return resp

    def getLocalThumbPrefix(self):
        resp = {'prefix': 'CACHEDEV1_DATA'}

        ret = self.request('GET', self._url('utility'), params={'a': 'get_af', 'sid': g().get('sid')})

        if ret.get('r'):
            data = ret.get('d')
            if data.get('DataList'):
                try:
                    shareInfo = data.get('DataList')[0]['FileItem'].get('prefix')
                    resp['prefix'] = shareInfo.split('/')[2]
                except Exception as err:
                    g.log_error(str(err))
        else:
            g.log_error(ret.get('e'))

        return resp

    def getTVShowInfo(self, showMsg=dict()):
        resp = {'tvshows': None, 'total': 0}
        payload = {'orderBy': 'ASC', 'sortBy': 'tv_episodeOrder', 'pages': 1, 'counts': BROWSE_STATIC_COUNT, 'home': 3, 'videoType': 2, 'sid': g().get('sid')}

        payload.update(showMsg)
        ret = self.getShareVideos(payload)
        if not ret.get('videos'):
            return None

        resp['tvshows'] = ret.get('videos')
        resp['total'] = ret.get('total')

        return resp

    def getTVShowsCount(self, options=dict()):
        resp = {'total': 0}

        ret = self.request('GET', self._url('list'), params={'t': 'TV_shows', 's': 'name', 'sd': 'DESC', 'p': '1', 'c': '500', 'sid': g().get('sid')})

        g.log_debug(msg=ret)
        if ret.get('r'):
            data = ret.get('d')
            resp['total'] = data.get('showCount') if 'showCount' in data else 0
        else:
            g.log_error(ret.get('e'))

        return resp.get('total')

    def getTVShows(self, classificationTVShowsMsg=dict()):
        resp = {'videos': None, 'total': 0}

        totalTVShows = self.getTVShowsCount()

        ret = self.request('GET', self._url('list'), params={'t': 'TV_shows', 's': classificationTVShowsMsg.get('sortBy') if 'sortBy' in classificationTVShowsMsg else 'name', 'sd': classificationTVShowsMsg.get('orderBy') if 'orderBy' in classificationTVShowsMsg else 'DESC', 'p': classificationTVShowsMsg.get('pages'), 'c': classificationTVShowsMsg.get('counts'), 'sid': g().get('sid'), 'year': classificationTVShowsMsg.get('year'), 'genre': classificationTVShowsMsg.get('genre')})

        if ret.get('r'):
            data = ret.get('d')
            if data.get('DataList'):
                resp['videos'] = data.get('DataList')
                '''
                if 'pages' in options and options['pages'] > 1:
                    resp['total'] = totalFiles
                else:
                    resp['total'] = data.get('showCount') if 'showCount' in data else 0
                '''
                resp['total'] = totalTVShows
        else:
            g.log_error(ret.get('e'))

        return resp

    def getClassification(self, classificationMsg=dict()):
        if classificationMsg.get('videoType') in ('2', ):
            resp = self.getTVShows(classificationMsg)
            #if not resp.get('videos'):
            #    return None

            return resp

        payload = {'sortBy': classificationMsg.get('sortBy') if 'sortBy' in classificationMsg else 'name',
                   'orderBy': classificationMsg.get('orderBy') if 'orderBy' in classificationMsg else 'DESC',
                   'home': 3,
                   'videoType': classificationMsg.get('videoType'),
                   'pages': classificationMsg.get('pages'),
                   'counts': classificationMsg.get('counts'),
                   'genre': classificationMsg.get('genre'),
                   'year': classificationMsg.get('year')}

        resp = self.getShareVideos(payload)
        #if not resp.get('videos'):
        #    return None

        return resp

    def getRecently(self, recentlyMsg=dict()):
        payload = {'sortBy': 'dbtime', 'orderBy': 'DESC', 'pages': recentlyMsg.get('pages'), 'counts': recentlyMsg.get('counts'), 'home': 0, 'sid': g().get('sid')}
        resp = self.getShareVideos(payload)
        #if not resp.get('videos'):
        #    return None

        return resp

    def getHistory(self, historyMsg=dict()):
        '''
        payload = {'sortBy': 'watch', 'orderBy': 'DESC', 'pages': historyMsg.get('pages'), 'counts': historyMsg.get('counts'), 'view': historyMsg.get('view') if 'view' in historyMsg else '1', 'sid': g().get('sid')}
        '''
        payload = {'sortBy': 'watch',
                   'orderBy': 'DESC',
                   'pages': historyMsg.get('pages'),
                   'counts': historyMsg.get('counts'),
                   'sid': g().get('sid')}
        resp = self.getShareVideos(payload)
        #if not resp.get('videos'):
        #    return None

        return resp

    def getCollectionInfo(self, collectioninfoMsg=dict()):
        collectioninfoMsg.update({'sid': g().get('sid')})

        resp = self.getShareVideos(collectioninfoMsg)
        #if not resp.get('videos'):
        #    return None

        return resp

    def getNewestItem(self, options=dict()):
        if 'videoType' in options:
            payload = {'sortBy': 'create', 'orderBy': 'DESC', 'pages': 1, 'counts': 1, 'home': 3, 'json': 1,
                       'videoType': options.get('videoType'), 'sid': g().get('sid')}
        else:
            payload = {'sortBy': 'create', 'orderBy': 'DESC', 'pages': 1, 'counts': 1, 'json': 1,
                       'mediaType': options.get('mediaType'), 'sid': g().get('sid')}

        resp = self.getShareVideos(payload)
        if not resp.get('videos'):
            return None

        getIdKeyword = 'id' if 'videoType' in options else 'first_video'
        resp = g.getPosterLocalPath(resp['videos'][0]['FileItem'].get(getIdKeyword), options.get('videoType'))

        return resp

    def delPlayProgress(self, mediaId):
        return self.request('POST', self._url('video'), data={'a': 'del_play_progress', 'f': mediaId})

    def setPlayProgress(self, mediaId, offset=-1):
        if offset < 0:
            try:
                offset = int(g().get('player').getTime())
            except:
                offset = 0

        return self.request('POST', self._url('video'), data={
            'a': 'save_play_progress',
            'ss': offset,
            'f': mediaId,
            'filename': g.getHomeProperty('Player.Subtitle')
        })

    def getPlayProgress(self, mediaId=None):
        offset = 0
        options = {'orderBy': 'DESC', 'mediaId': mediaId, 'sid': g().get('sid')}
        resp = {'offset': 0, 'subtitles': u''}

        ret = self.request('GET', self._url('video'), params={
            'json': 1,
            'a': 'recall_play_progress',
            'sd': options['orderBy'] if 'orderBy' in options else 'DESC',
            'f': options['mediaId'] if 'mediaId' in options else None
        })

        g.log_debug(msg=ret)
        if ret.get('r'):
            data = ret.get('d')
            if data['recall'][0].get('progress'):
                resp['offset'] = eval(data['recall'][0].get('progress'))
            if data['recall'][1].get('subtitle'):
                resp['subtitle'] = data['recall'][1].get('subtitle')

        return resp

    def getShareVideosCount(self, options=dict()):
        resp = {'total': 0}

        ret = self.request('GET', self._url('list'), params={
            't': 'videos', 'p': 1, 'c': 1,
            'd': options['date'] if 'date' in options else None,
            's': options['sortBy'] if 'sortBy' in options else 'dbtime',
            'h': options['home'] if 'home' in options else 0,
            'vt': options['videoType'] if 'videoType' in options else None,
            'genre': options['genre'] if 'genre' in options else None,
            'year': options['year'] if 'year' in options else None,
        })

        g.log_debug(msg=ret)
        if ret.get('r'):
            data = ret.get('d')
            resp['total'] = data.get('videoCount') if 'videoCount' in data else 0

        return resp

    def getShareVideos(self, options=dict()):
        u"""取得共用影片列表."""
        resp = {'videos': None, 'total': 0}

        # Get share videos counts here.
        totalFiles = self.getShareVideosCount(options).get('total')

        ret = self.request('GET', self._url('list'), params={
            't': options['mediaType'] if 'mediaType' in options else 'videos',
            'h': options['home'] if 'home' in options else 0,
            'p': options['pages'] if 'pages' in options else 1,
            'c': options['counts'] if 'counts' in options else totalFiles,
            's': options['sortBy'] if 'sortBy' in options else 'name',
            'sd': options['orderBy'] if 'orderBy' in options else 'DESC',
            'vt': options['videoType'] if 'videoType' in options else None,
            'd': options['date'] if 'date' in options else None,
            'a': options['albumId'] if 'albumId' in options else None,
            'e': options['tvId'] if 'tvId' in options else None,
            'sn': options['season'] if 'season' in options else None,
            'w': options['view'] if 'view' in options else None,
            'genre': options['genre'] if 'genre' in options else None,
            'year': options['year'] if 'year' in options else None,
        })

        if ret.get('r'):
            data = ret.get('d')
            if data.get('DataList'):
                resp['videos'] = data.get('DataList')

                if 'pages' in options and options['pages'] > 1:
                    resp['total'] = totalFiles
                else:
                    resp['total'] = data.get('videoCount') if 'videoCount' in data else 0
        else:
            g.log_error(ret.get('e'))

        return resp

    def getIMDBInfo(self, options=dict()):
        u"""取得電影IMDB資訊.

        Parameters:
            a: get_imdb_info
            v: videoId

        Example:
            http://ip:8080/video/api/utility.php?sid=8739c520a6e3797616e64d8661bf60f8&a=get_imdb_info&v=cJinsP
        """
        ret = self.request('GET', self._url('utility'), params={
            'a': 'get_imdb_info', 'v': options.get('fileId') if 'fileId' in options else None})

        if ret.get('r'):
            data = ret.get('d')
            return data.get('info')[0].get('FileItem')
        else:
            g.log_error(ret.get('e'))

        return None

    def getFolderItems(self, options=dict()):
        u"""取得資料夾瀏覽影片列表."""
        resp = {'datas': None, 'counts': 0}

        self.updateUserEnv()

        ret = self.request('GET', self._url('list'), params={
            't': 'folderItems',
            'dir': options['dir'] if 'dir' in options else None,
            'sd': options['orderBy'] if 'orderBy' in options else 'DESC',
            's': options['sortBy'] if 'sortBy' in options else 'name',
            'p': options['pages'] if 'pages' in options else None,
            'c': options['counts'] if 'counts' in options else None,
            'h': options['home'] if 'home' in options else 0
        })

        if ret.get('r'):
            data = ret.get('d')

            if data.get('DataList'):
                resp['datas'] = data.get('DataList')

                folders = int(data.get('folderCount')) if data.get('folderCount') else 0
                videos = int(data.get('videoCount')) if data.get('videoCount') else 0
                resp['counts'] = folders + videos

            if g().get('usr_home') in ('TRUE', ) and options.get('dir') in (None, ) and 'home' not in options:
                resp['datas'].append({'FileItem': {'cPictureTitle': 'home', 'MediaType': 'folder', 'prefix': None, 'id': None}})
                resp['datas'].append({'FileItem': {'cPictureTitle': '.Qsync', 'MediaType': 'folder', 'prefix': None, 'id': None}})
                resp['counts'] += 2
        else:
            g.log_error(ret.get('e'))

        return resp

    def getCollections(self, collectionMsg=dict()):
        u"""取得蒐藏列表."""
        resp = {'collections': list(), 'counts': 0}

        options = {'albumType': collectionMsg.get('albumType'), 'sortBy': collectionMsg.get('sortBy'), 'orderBy': collectionMsg.get('orderBy'),
                   'pages': collectionMsg.get('pages'), 'counts': collectionMsg.get('counts'), 'sid': g().get('sid')}

        ret = self.request('GET', self._url('list'), params={
            't': options['albumType'] if 'albumType' in options else 'albums',
            'sd': options['orderBy'] if 'orderBy' in options else 'ASC',
            'p': options['pages'] if 'pages' in options else 1,
            'c': options['counts'] if 'counts' in options else None,
            's': options['sortBy'] if 'sortBy' in options else 'name'
        })

        if ret.get('r'):
            data = ret.get('d')

            if data.get('DataList'):
                resp['collections'] = data.get('DataList')
                resp['counts'] = len(data.get('DataList'))
        else:
            g.log_error(ret.get('e'))

        return resp

    def getBookmarks(self, fileId):
        u"""取得書籤資訊.

        Example:
            http://localhost:8080/video/api/video.php?a=get_bookmark&f=PHfur0&json=1
        """
        resp = {'bookmarks': list(), 'counts': 0}

        ret = self.request('GET', self._url('video'), params={
            'a': 'get_bookmark',
            'f': fileId
        })

        if ret.get('r'):
            data = ret.get('d')

            resp['bookmarks'] = data.get('bookmarks')
            resp['counts'] = len(data.get('bookmarks'))
        else:
            g.log_error(ret.get('e'))

        return resp

    def getFilterItems(self, subtype):
        u"""取得可篩選項目."""
        resp = {'filters': dict()}

        ret = self.request(
            'GET',
            self._url('list'),
            params={'t': 'movie-v' if subtype in ('movies', ) else 'TV-v'}
        )

        if ret.get('r'):
            data = ret.get('d')
            resp['filters'] = data.get('DataList')
        else:
            g.log_error(ret.get('e'))

        return resp

    def getCaptionExist(self, mediaId):
        resp = {'captions': {'same_folder': list()}}
        ret = self.request(
            'GET',
            self._url('video'),
            params={'a': 'captionexist', 'f': mediaId, 'vt': 'srt'})

        if ret.get('r'):
            data = ret.get('d', {'captions': list()})
            for d in data.get('captions'):
                caption = d.get('caption')
                if 'type' in caption:
                    if caption.get('type') in ('same_folder', ):
                        resp['captions']['same_folder'].append(caption.get('file_name'))
                    else:
                        resp['captions'][caption['type']] = caption.get('file_name')

        return resp

    def getSubtitleSearchResult(self, videoId):
        resp = {'captions': dict()}

        ret = self.request(
            'GET',
            self._url('video'),
            params={'a': 'search_caption', 'f': videoId})

        if ret.get('r'):
            data = ret.get('d')
            if data.get('captions'):
                resp['captions'] = data.get('captions')

        return resp

    def downloadSubtitle(self, videoId, item):
        '''http://192.168.82.40:8080/video/api/video.php?a=download_caption&f=XdstLd&url=eNoNy9EKgjAUANAfartaTl2PgmBgT5IQ0cPapi3G7thdBX59nfdzmy7d_ZlzPAIYzzHaQO9Hdtlb4phWsAEMfoNHZYCSZio6-KSFlVLXhRYtkDMsTa_5RPtZ7Pp2q9V5HK59bAbUo4LFefu_pRSiaGR1qPi6_QCeZSc2&json=1'''

        ret = self.request(
            'GET',
            self._url('video'),
            params={'a': 'download_caption', 'f': videoId, 'url': item.getProperty('url')})

        if ret.get('r'):
            return True

        return False

    def genSubtitleUrl(self, videoId, subtitleType):
        '''if g().get('localhost'):
            if subtitleType in ('import', ):
                return u'/share2/{0}.@__thumb/{1}.u.srt'.format(g.ensureUnicode(listitem.getProperty('prefix')), g.ensureUnicode(listitem.getProperty('filename')))
            else:
                return u'/share2/{0}.@__thumb/{1}.srt'.format(g.ensureUnicode(listitem.getProperty('prefix')), g.ensureUnicode(listitem.getProperty('filename')))'''

        return u'{0}?a=caption&f={1}&sid={2}&vt=srt&e=UTF-8&filename={3}'.format(
            self._url('video'),
            videoId,
            g().get('sid'),
            urllib.quote(subtitleType)
        )

    def getSubtitle(self, videoId, subtitleType):
        return self.request(
            'GET',
            self._url('video'),
            params={'a': 'caption', 'f': videoId, 'vt': 'srt', 'e': 'UTF-8', 'filename': subtitleType},
            action='pure_content')

    def checkThumbUrl(self, mediaId, thumbtype='video', mode='display', size='default'):
        if self.request('GET', self._url('thumb'), params={'m': mode, 't': thumbtype, 'f': mediaId, 's': size})['r']:
            return True

        return False

    def genConvertUrl(self, fileId):
        u"""建立影片轉檔連結."""
        return u'{0}?a=display&f={1}&sid={2}&s=&ac=&ss='.format(
            self._url('video'),
            fileId,
            g().get('sid')
        )
