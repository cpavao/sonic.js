# -*- coding: utf-8 -*-
"""QTScgi API."""
import requests
import traceback

from lib import g
from lib.utils.httpRequest import HTTPRequest

class QtsAPI(HTTPRequest):
    """QTScgi API Class."""
    def _url(self, which, data=dict()):
        return u'{0}/cgi-bin/{1}.cgi'.format(g.urlPrefix(data), which)

    def request(self, method, url, data=None, params=None, verify=None):
        # From is videostation or mediahd
        if verify in (None, ):
            if 'https' in url:
                verify = False
            else:
                verify = True

        try:
            r = self._execute[method](url, data=data, params=params, verify=verify, timeout=5)
        except requests.ConnectionError as e:
            if 'ssl' in str(e):
                return {'code': 'ssl.err', 'msg': 'SSL require error.'}
            return {'code': 'conn.err', 'msg': 'Connection error.'}
        except requests.exceptions.Timeout as e:
            return {'code': 'timeout.err', 'msg': 'requests timeout'}
        except Exception:
            return {'code': 'except.err', 'msg': traceback.format_exc()}

        if r.ok:
            return {'code': 'ok'}
        else:
            print url
            print g.ensureUTF8(r.text)
            return {'code': 'http.err'}

    def nasCheck(self, data=dict(), verify=None):
        resp = self.request('GET', self._url('authLogin', data), verify=verify)

        if resp.get('code') in ('ok', ):
            return {'result': True}
        else:
            # g.log_error('QTS CGI Error: [{0}] -> {1}'.format(resp.get('code'), resp.get('msg')))
            return {'result': False, 'code': resp.get('code')}
