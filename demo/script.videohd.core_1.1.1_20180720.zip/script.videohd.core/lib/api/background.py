# -*- coding: utf-8 -*-
import random

import xbmc
import xbmcgui
import xbmcaddon

from lib import g
from lib.api.videostation import VideoStationAPI
from lib.static import *

__addon__ = xbmcaddon.Addon()
__language__ = __addon__.getLocalizedString


class BackgroundHandler(object):
    def __init__(self):
        # self.currentStatus = dict()

        self.classificationMapping = {'0': {'string': __language__(60015), 'classificationType': 'others', 'subtypeName': 'Uncategorized'},
                                      '1': {'string': __language__(60010), 'classificationType': 'movies', 'subtypeName': 'Movies'},
                                      '2': {'string': __language__(60011), 'classificationType': 'tvshows', 'subtypeName': 'TV Shows'},
                                      '3': {'string': __language__(60012), 'classificationType': 'musicvideos', 'subtypeName': 'Music Videos'},
                                      '4': {'string': __language__(60013), 'classificationType': 'homevideos', 'subtypeName': 'Home Videos'},
                                      '5': {'string': __language__(60014), 'classificationType': 'ktv', 'subtypeName': 'KTV'}}

    def prepareProperty(self, which, byWhat, plainData, msg=None):
        target = None
        propertyContainer = dict()

        # byFile or byNoneFile
        if byWhat in ('byFile', ):
            # for player
            propertyContainer['filename'] = plainData['FileItem'].get('cFilename')
            propertyContainer['prefix'] = plainData['FileItem'].get('prefix')
            propertyContainer['offset'] = plainData['FileItem'].get('progress')
            propertyContainer['duration'] = plainData['FileItem'].get('Duration')
            propertyContainer['extIDBId'] = plainData['FileItem'].get('extIDBId')

            # videoinfo
            if plainData['FileItem'].get('mask'):
                propertyContainer['colorLevelInfo'] = plainData['FileItem'].get('ColorLevel')

                if not plainData['FileItem'].get('rating') or plainData['FileItem'].get('rating') in ('0', ):
                    rating = '0'
                else:
                    rating = str(int(plainData['FileItem'].get('rating')) / 20)
                propertyContainer['ratingInfo'] = rating

                propertyContainer['videoinfomask'] = plainData['FileItem'].get('mask')
                propertyContainer['tagInfo'] = plainData['FileItem'].get('keywords')
                propertyContainer['filesizeInfo'] = g.countFileSize(plainData['FileItem'].get('iFileSize'))
                propertyContainer['dimensionsInfo'] = plainData['FileItem'].get('Dimensions')
                propertyContainer['videocodec'] = plainData['FileItem'].get('vcodec')
                propertyContainer['audiocodec'] = plainData['FileItem'].get('acodec')
                propertyContainer['typeInfo'] = plainData['FileItem'].get('mime')
                propertyContainer['pathInfo'] = '{0}{1}'.format(g.ensureUTF8(plainData['FileItem'].get('prefix')),
                                                                g.ensureUTF8(plainData['FileItem'].get('cFilename')))

            # common
            propertyContainer['description'] = plainData['FileItem'].get('extOutline') if plainData['FileItem'].get('extOutline') else '--'
            propertyContainer['id'] = plainData['FileItem'].get('id')

            # id, cPictureTitle, first_video and tv_name also for collectioninfo
            getIdKeyword, titleName = ('id', 'cPictureTitle') if 'mask' in plainData['FileItem'] else ('first_video', 'tv_name')
            propertyContainer['title'] = plainData['FileItem'].get(titleName)
            propertyContainer['thumbnail'] = g.getImageLocalPath('median', plainData['FileItem'].get(getIdKeyword), plainData['FileItem'].get('PosterPath'))

            if which in ('recently', 'history', 'share', ):
                playLength = g.timeTransfer(eval(plainData['FileItem'].get('Duration')))
                resp_showTime = g.showTime(playLength)
                propertyContainer['length'] = resp_showTime if resp_showTime else 'N/A'

                # the mask tag which to judge media type. mask = 2 for tvshow
                mediaType = 'tvshow' if plainData['FileItem'].get('mask') in ('2', ) else 'movie'
                propertyContainer['type'] = mediaType
            elif which in ('classification', ):
                getIdKeyword, titleName = ('tv_id', 'tv_name') if msg.get('videoType') in ('2', ) else ('id', 'cPictureTitle')

                propertyContainer['title'] = plainData['FileItem'].get(titleName)
                propertyContainer['type'] = plainData['FileItem'].get('mask') if msg.get('videoType') not in ('2', ) else '2'
                propertyContainer['id'] = plainData['FileItem'].get(getIdKeyword)

                if titleName not in ('tv_name', ):
                    playLength = g.timeTransfer(eval(plainData['FileItem'].get('Duration')))
                    resp_showTime = g.showTime(playLength)
                    propertyContainer['length'] = resp_showTime if resp_showTime else 'N/A'

                '''
                if msg.get('videoType') not in ('2', ):
                    propertyContainer['duration'] = plainData['FileItem'].get('Duration')
                '''
                if msg.get('videoType') in ('1', ):
                    pictureType = 'poster'
                elif msg.get('videoType') in ('2', ):
                    pictureType = 'tvshow.poster'
                else:
                    pictureType = 'median'

                if msg.get('videoType') in ('1', '2', ):
                    propertyContainer['rate'] = '{0}/10'.format(plainData['FileItem'].get('extRating')) if plainData['FileItem'].get('extRating') else '--'
                    propertyContainer['genre'] = plainData['FileItem'].get('extGenre') if plainData['FileItem'].get('extGenre') else '--'
                    propertyContainer['year'] = plainData['FileItem'].get('extYear') if plainData['FileItem'].get('extYear') not in ('0', None, ) else '--'

                    # preparing the property of poster
                    propertyContainer['poster'] = g.getImageLocalPath(pictureType, plainData['FileItem'].get(getIdKeyword), plainData['FileItem'].get('PosterPath'), plainData['FileItem'].get('first_video'))

                    if msg.get('videoType') not in ('1', ):
                        seasons = str(plainData['FileItem'].get('season_list'))
                        propertyContainer['seasons'] = seasons

                        rate = plainData['FileItem'].get('extRating')
                        propertyContainer['rate'] = str('--' if not rate else eval(rate))

                        propertyContainer['actors'] = plainData['FileItem'].get('extActors') if plainData['FileItem'].get('extActors') else '--'
                        propertyContainer['creator'] = plainData['FileItem'].get('extCreators') if plainData['FileItem'].get('extCreators') else '--'

                        propertyContainer['recently_play_id'] = plainData['FileItem'].get('recently_play_id')
                        propertyContainer['recently_play_progress'] = plainData['FileItem'].get('recently_play_progress')
                        propertyContainer['recently_play_season'] = plainData['FileItem'].get('recently_play_season')
                        propertyContainer['recently_play_season_order'] = plainData['FileItem'].get('recently_play_season_order')

                # preparing the property of thumbnail
                getPictureKeyword = 'first_video' if msg.get('videoType') in ('2', ) else 'id'
                thumb = g.getImageLocalPath('median', plainData['FileItem'].get(getPictureKeyword), plainData['FileItem'].get('PosterPath'))
                propertyContainer['thumbnail'] = thumb

            elif which in ('tvshowinfo', ):
                propertyContainer['id'] = plainData['FileItem'].get('id')  # episode id
                propertyContainer['filename'] = plainData['FileItem'].get('cFilename')
                propertyContainer['prefix'] = plainData['FileItem'].get('prefix')
                # propertyContainer['duration'] = plainData['FileItem'].get('Duration')

                season = plainData['FileItem'].get('extSeason')
                episode = plainData['FileItem'].get('extEpisodeOrder')
                episodeName = plainData['FileItem'].get('cPictureTitle')  # episode name
                propertyContainer['title'] = g.ensureUTF8(__language__(60022) % (season, episode, episodeName))
                # propertyContainer['title'] = '{0} {1} {2}'.format(season, episode, episodeName)

                propertyContainer['season'] = plainData['FileItem'].get('extSeason')
                propertyContainer['episode'] = plainData['FileItem'].get('extEpisodeOrder')

                thumb = g.getImageLocalPath('median', plainData['FileItem'].get('id'), plainData['FileItem'].get('PosterPath'))
                propertyContainer['thumbnail'] = thumb

                playLength = g.timeTransfer(eval(plainData['FileItem'].get('Duration')))
                resp_showTime = g.showTime(playLength)
                propertyContainer['length'] = resp_showTime if resp_showTime else 'N/A'
            elif which in ('collectioninfo', ):
                playLength = g.timeTransfer(eval(plainData['FileItem'].get('Duration')))
                resp_showTime = g.showTime(playLength)
                propertyContainer['length'] = resp_showTime if resp_showTime else 'N/A'
        else:
            if which in ('collection', ):
                # lock : public=false, shared=false ; public : public=true, shared=true ; group : public=false, shared=true
                public = True if 'true' in plainData['FileItem'].get('public') else False
                shared = True if 'true' in plainData['FileItem'].get('shared') else False
                if public and shared:
                    c_type = 'public'
                elif not public and shared:
                    c_type = 'group'
                elif not public and not shared:
                    c_type = 'lock'

                propertyContainer['collectType'] = c_type
                propertyContainer['title'] = plainData['FileItem'].get('cAlbumTitle')

                collectionThumbnail = g.getImageLocalPath('median', plainData['FileItem'].get('iAlbumCover'), plainData['FileItem'].get('PosterPath'))
                propertyContainer['thumbnail'] = '' if collectionThumbnail in ('empty_thumbnail.png', ) else collectionThumbnail

                propertyContainer['albumId'] = plainData['FileItem'].get('iVideoAlbumId')
                propertyContainer['albumTitle'] = plainData['FileItem'].get('cAlbumTitle')

                propertyContainer['total'] = __language__(60020) % (plainData['FileItem'].get('VideoCount'))
            elif which in ('folder', ):
                propertyContainer['title'] = plainData['FileItem'].get('cPictureTitle')
                propertyContainer['thumbnail'] = 'icon_folder.png'
                propertyContainer['id'] = plainData['FileItem'].get('id')
                propertyContainer['MediaType'] = plainData['FileItem'].get('MediaType')
                propertyContainer['prefix'] = plainData['FileItem'].get('prefix')
                propertyContainer['isMediafolder'] = plainData['FileItem'].get('isMediafolder')
            elif which in ('subtype', ):
                getSubtypeId = g.ensureUTF8(plainData['subtype'].get('id'))
                getSubtypeName = g.ensureUTF8(plainData['subtype'].get('name'))

                # g.initSort(getSubtypeName)

                if eval(getSubtypeId) > 5:
                    self.classificationMapping[getSubtypeId] = {'string': getSubtypeName, 'classificationType': 'others', 'subtypeName': getSubtypeName}
                '''
                if eval(getSubtypeId) < 6:
                    sortContainer = g.getSort(getSubtypeName)
                    self.currentStatus[getSubtypeId] = {'currentPage': 1, 'currentItemLength': 0,
                                                        'sortBy': sortContainer['sortValue'], 'orderBy': sortContainer['orderValue']}
                '''
                # self.currentStatus[getSubtypeId] = {'currentPage': 1, 'currentItemLength': 0,
                #                                     'sortBy': g.getSort(getSubtypeName)['sortValue'], 'orderBy': g.getSort(getSubtypeName)['orderValue']}

                focusMediaType = self.classificationMapping[getSubtypeId]['string']
                target = xbmcgui.ListItem(focusMediaType, '', '', '')
                target.setProperty('vt', getSubtypeId)
                target.setProperty('subtypeName', getSubtypeName)

                return target

        target = g.settingProperty(propertyContainer, which, msg.get('videoType') if msg else None)

        return target

    def IMDBInfo(self, movieId):
        resp = VideoStationAPI().getIMDBInfo({'fileId': movieId})
        if not resp:
            return None

        return {'director': resp.get('Director'), 'actors': resp.get('Actor')}

    def shareVideoBackgroundData(self, shareMsg=dict()):
        listitems = list()
        container = {'items': None}

        resp = VideoStationAPI().getShareVideos(shareMsg)
        if not resp.get('videos'):
            return None

        for shareItem in resp.get('videos'):
            target = self.prepareProperty('share', 'byFile', shareItem)
            listitems.append(target)

        container['items'] = listitems
        container['total'] = resp.get('total')

        return container

    def recentlyBackgroundData(self, recentlyMsg=dict()):
        listitems = list()
        container = {'items': None}

        resp = VideoStationAPI().getRecently(recentlyMsg)
        if not resp.get('videos'):
            return None

        for recentlyItem in resp.get('videos'):
            target = self.prepareProperty('recently', 'byFile', recentlyItem)
            listitems.append(target)

        container['items'] = listitems
        container['total'] = resp.get('total')

        return container

    def historyBackgroundData(self, historyMsg=dict()):
        listitems = list()
        container = {'items': None}

        resp = VideoStationAPI().getHistory(historyMsg)
        if not resp.get('videos'):
            return None

        for historyItem in resp.get('videos'):
            if not historyItem.get('FileItem').get('progress'):
                break

            target = self.prepareProperty('history', 'byFile', historyItem)
            listitems.append(target)

        container['items'] = listitems
        container['total'] = resp.get('total')

        return container

    def collectioninfoBackgroundData(self, collectioninfoMsg=dict()):
        listitems = list()
        container = {'items': None}

        resp = VideoStationAPI().getCollectionInfo(collectioninfoMsg)
        if not resp.get('videos'):
            return None

        for content in resp.get('videos'):
            target = self.prepareProperty('collectioninfo', 'byFile', content)
            listitems.append(target)

        container['items'] = listitems
        container['total'] = resp.get('total')

        return container

    def collectionBackgroundData(self, collectionMsg=dict()):
        listitems = list()
        container = {'items': None, 'albumTitle': list(), 'counts': None}
        container[collectionMsg.get('albumType')] = list()

        # resp = VideoStationAPI().getCollections({'albumType': collectionMsg.get('albumType')})
        resp = VideoStationAPI().getCollections(collectionMsg)
        if not resp.get('collections'):
            return None

        for collect in resp.get('collections'):
            container.get(collectionMsg.get('albumType')).append(collect['FileItem'].get('iVideoAlbumId'))
            container.get('albumTitle').append(collect['FileItem'].get('cAlbumTitle'))

            target = self.prepareProperty('collection', 'byNoneFile', collect)
            listitems.append(target)

        container['items'] = listitems
        container['counts'] = resp.get('counts')

        '''temporary method that is for getting collection total, 20170119'''
        payload = {'albumType': collectionMsg['albumType'], 'pages': '1', 'counts': 10000}

        ret = VideoStationAPI().getCollections(payload)
        if not ret.get('collections'):
            return None

        container['total'] = ret.get('counts')

        return container

    def classificationSubtype(self):
        listitems = list()
        container = {'items': None}

        resp = VideoStationAPI().initClassifyListPanel()
        if not resp.get('subtypelist'):
            return None

        for subtype in resp.get('subtypelist'):
            target = self.prepareProperty('subtype', 'byNoneFile', subtype)
            listitems.append(target)

        container['pure_items'] = resp.get('subtypelist')
        container['items'] = listitems
        container['total'] = resp.get('counts')
        # container['currentStatus'] = self.currentStatus
        container['classificationMapping'] = self.classificationMapping

        # container['focusTail'] = resp.get('counts') - 1  # temporary variable

        return container

    def classificationBackgroundData(self, classificationMsg=dict()):
        listitems = list()
        container = {'items': None}

        resp = VideoStationAPI().getClassification(classificationMsg)
        if not resp.get('videos'):
            return None

        for item in resp.get('videos'):
            target = self.prepareProperty('classification', 'byFile', item, classificationMsg)
            listitems.append(target)

        container['items'] = listitems
        container['total'] = resp.get('total')

        return container

    def tvshowinfoBackgroundData(self, tvshowinfoMsg=dict()):
        listitems = list()
        container = {'items': None, 'episode_list': list()}

        resp = VideoStationAPI().getTVShowInfo(tvshowinfoMsg)
        if not resp:
            return None

        for tvshow in resp.get('tvshows'):
            target = self.prepareProperty('tvshowinfo', 'byFile', tvshow)
            listitems.append(target)
            container['episode_list'].append(tvshow['FileItem'].get('extEpisodeOrder'))

        thumbBg = random.choice(listitems)
        g.tvshowinfoBg(thumbBg.getProperty('thumbnail'))

        container['items'] = listitems
        container['total'] = resp.get('total')
        container['pages'] = tvshowinfoMsg.get('pages')

        return container

    def folderBackgroundData(self, folderMsg=dict()):
        listitems = list()
        container = {'items': None}

        resp = VideoStationAPI().getFolderItems(folderMsg)
        if not resp.get('datas'):
            return None

        for folderItem in resp.get('datas'):
            target = self.prepareProperty('folder', 'byNoneFile', folderItem)
            listitems.append(target)

        container['items'] = listitems
        container['total'] = resp.get('counts')
        container['totalPage'] = g.paginateInfo(BROWSE_VIDEO_COUNT, resp.get('counts'))

        return container

    def subtitleBackgroundData(self, videoId):
        listitems = list()
        resp = VideoStationAPI().getCaptionExist(videoId)

        captions = resp.get('captions')
        if captions:
            for s_name in captions.get('same_folder'):
                l = xbmcgui.ListItem(s_name)
                l.setProperty('name', s_name)
                listitems.append(l)

            if 'download' in captions:
                l = xbmcgui.ListItem(__language__(60063))
                l.setProperty('name', 'download')
                listitems.append(l)

            if 'import' in captions:
                l = xbmcgui.ListItem(__language__(60064))
                l.setProperty('name', 'import')
                listitems.append(l)

        return listitems
